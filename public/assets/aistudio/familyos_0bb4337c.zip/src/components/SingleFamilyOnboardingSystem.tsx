import React, { useState, useEffect } from 'react';
import {
  Shield,
  Users,
  CheckCircle2,
  AlertTriangle,
  Link2,
  Copy,
  Check,
  Mail,
  UserCheck,
  Sparkles,
  Lock,
  Bell,
  ArrowRight,
  X,
  Clock,
  ExternalLink
} from 'lucide-react';
import { Stage331WorkspaceData } from './Stage331FamilyExperience';
import { signInWithGooglePopup, syncDomainRecordToDatabase } from '../firebase';

export interface MemberProfileCompletionRecord {
  roleKey: string;
  memberId: string;
  // Mandatory fields
  displayName: string;
  googleEmail: string;
  relationshipToPrimary: string;
  birthDate: string;
  // Optional (skippable for the time being) fields
  phone: string;
  emergencyContactName: string;
  emergencyContactPhone: string;
  allergiesText: string;
  bio: string;
  responsibilitiesText: string;
  avatarUrl: string;
  // Tracking
  mandatoryCompleted: boolean;
  isFullyComplete: boolean;
  completionPercentage: number;
  missingOptionalFields: string[];
  skippedAt: number | null;
  lastRemindedAt: number | null;
}

const PROFILE_COMPLETION_STORAGE_KEY = 'familyos_member_profile_completion_v1';

export function computeProfileCompletion(record: Partial<MemberProfileCompletionRecord>): {
  mandatoryCompleted: boolean;
  isFullyComplete: boolean;
  completionPercentage: number;
  missingMandatoryFields: string[];
  missingOptionalFields: string[];
} {
  const missingMandatoryFields: string[] = [];
  if (!record.displayName?.trim()) missingMandatoryFields.push('Full Name');
  if (!record.googleEmail?.trim()) missingMandatoryFields.push('Google Account Email');
  if (!record.relationshipToPrimary?.trim()) missingMandatoryFields.push('Family Relationship');
  if (!record.birthDate?.trim()) missingMandatoryFields.push('Date of Birth');

  const missingOptionalFields: string[] = [];
  if (!record.phone?.trim()) missingOptionalFields.push('Phone Number');
  if (!record.emergencyContactName?.trim() || !record.emergencyContactPhone?.trim()) {
    missingOptionalFields.push('Emergency Contact (Name & Phone)');
  }
  if (!record.allergiesText?.trim()) missingOptionalFields.push('Allergies & Medical Notes');
  if (!record.bio?.trim()) missingOptionalFields.push('Personal Bio & Responsibilities');

  const totalFields = 8;
  const filledCount = totalFields - missingMandatoryFields.length - missingOptionalFields.length;
  const completionPercentage = Math.round((filledCount / totalFields) * 100);

  return {
    mandatoryCompleted: missingMandatoryFields.length === 0,
    isFullyComplete: missingMandatoryFields.length === 0 && missingOptionalFields.length === 0,
    completionPercentage,
    missingMandatoryFields,
    missingOptionalFields,
  };
}

export function loadAllProfileCompletions(): Record<string, MemberProfileCompletionRecord> {
  try {
    const raw = localStorage.getItem(PROFILE_COMPLETION_STORAGE_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch {
    // Ignore storage error
  }
  return {};
}

export function saveProfileCompletionForRole(
  roleKey: string,
  record: MemberProfileCompletionRecord
): void {
  try {
    const all = loadAllProfileCompletions();
    all[roleKey] = record;
    localStorage.setItem(PROFILE_COMPLETION_STORAGE_KEY, JSON.stringify(all));
    window.dispatchEvent(new CustomEvent('familyos-profile-completion-updated'));
  } catch {
    // Ignore
  }
}

export function getOrCreateRoleProfileCompletion(
  roleKey: string,
  workspaceData: Stage331WorkspaceData | null
): MemberProfileCompletionRecord {
  const all = loadAllProfileCompletions();
  if (all[roleKey]) {
    return all[roleKey];
  }

  const roleDefaults: Record<
    string,
    {
      memberId: string;
      displayName: string;
      googleEmail: string;
      relationshipToPrimary: string;
      birthDate: string;
      phone: string;
      emergencyContactName: string;
      emergencyContactPhone: string;
      allergiesText: string;
      bio: string;
      responsibilitiesText: string;
    }
  > = {
    OWNER: {
      memberId: 'mem-sarah',
      displayName: 'Sarah Jenkins',
      googleEmail: 'sarah.jenkins@gmail.com',
      relationshipToPrimary: 'PARENT / MOTHER',
      birthDate: '1986-04-12',
      phone: '+1 (555) 234-5678',
      emergencyContactName: 'David Jenkins',
      emergencyContactPhone: '+1 (555) 234-5679',
      allergiesText: 'None',
      bio: 'Primary family steward, managing household budgets, health records & core routines.',
      responsibilitiesText: 'Financial Stewardship, Meal Planning',
    },
    ADMIN: {
      memberId: 'mem-david',
      displayName: 'David Jenkins',
      googleEmail: 'david.jenkins@gmail.com',
      relationshipToPrimary: 'SPOUSE / FATHER',
      birthDate: '1985-08-22',
      phone: '+1 (555) 234-5679',
      emergencyContactName: 'Sarah Jenkins',
      emergencyContactPhone: '+1 (555) 234-5678',
      allergiesText: 'Penicillin allergy',
      bio: 'Co-parent administrator managing chore approvals, home maintenance & family goals.',
      responsibilitiesText: 'Home Maintenance, Vehicle Care',
    },
    MEMBER: {
      memberId: 'mem-maya',
      displayName: 'Maya Jenkins',
      googleEmail: 'maya.jenkins@gmail.com',
      relationshipToPrimary: 'DAUGHTER',
      birthDate: '2010-03-19',
      // Default MEMBER has skipped some optional fields so the reminder system is immediately demonstrable!
      phone: '',
      emergencyContactName: 'Sarah Jenkins',
      emergencyContactPhone: '+1 (555) 234-5678',
      allergiesText: '',
      bio: '',
      responsibilitiesText: 'Photography, Track Practice',
    },
    CHILD: {
      memberId: 'mem-lucas',
      displayName: 'Lucas Jenkins',
      googleEmail: 'lucas.jenkins@gmail.com',
      relationshipToPrimary: 'SON',
      birthDate: '2017-06-15',
      phone: '',
      emergencyContactName: 'Sarah Jenkins',
      emergencyContactPhone: '+1 (555) 234-5678',
      allergiesText: 'Peanut allergy',
      bio: '',
      responsibilitiesText: 'Daily Chores & Reading',
    },
    GUEST: {
      memberId: 'mem-martha',
      displayName: 'Martha Vance',
      googleEmail: 'martha.vance@gmail.com',
      relationshipToPrimary: 'GRANDPARENT',
      birthDate: '1958-11-04',
      phone: '',
      emergencyContactName: '',
      emergencyContactPhone: '',
      allergiesText: '',
      bio: '',
      responsibilitiesText: 'Extended Family Caregiver',
    },
  };

  const def = roleDefaults[roleKey] || roleDefaults.OWNER;
  const matchedMember = workspaceData?.members.find((m) => m.id === def.memberId);

  const baseRecord: Partial<MemberProfileCompletionRecord> = {
    roleKey,
    memberId: def.memberId,
    displayName: matchedMember?.displayName || def.displayName,
    googleEmail: def.googleEmail,
    relationshipToPrimary: matchedMember?.relationshipToPrimary || def.relationshipToPrimary,
    birthDate: matchedMember?.birthDate || def.birthDate,
    phone: def.phone,
    emergencyContactName: def.emergencyContactName,
    emergencyContactPhone: def.emergencyContactPhone,
    allergiesText: def.allergiesText,
    bio: def.bio,
    responsibilitiesText: def.responsibilitiesText,
    avatarUrl: matchedMember?.avatarUrl || '',
  };

  const stats = computeProfileCompletion(baseRecord);
  return {
    ...(baseRecord as MemberProfileCompletionRecord),
    mandatoryCompleted: stats.mandatoryCompleted,
    isFullyComplete: stats.isFullyComplete,
    completionPercentage: stats.completionPercentage,
    missingOptionalFields: stats.missingOptionalFields,
    skippedAt: stats.isFullyComplete ? null : Date.now() - 1800000,
    lastRemindedAt: Date.now(),
  };
}

export function checkIsFamilyProfileComplete(workspaceData: Stage331WorkspaceData | null): {
  isComplete: boolean;
  completionPercentage: number;
  missingFields: string[];
} {
  if (!workspaceData?.workspace) {
    return { isComplete: true, completionPercentage: 100, missingFields: [] };
  }
  const ws = workspaceData.workspace;
  const missing: string[] = [];
  if (!ws.name?.trim()) missing.push('Family Name');
  if (!ws.motto?.trim()) missing.push('Family Motto');
  if (!ws.mission?.trim()) missing.push('Family Mission Statement');
  if (!ws.vision?.trim()) missing.push('Generational Vision');
  if (!Array.isArray(ws.values) || ws.values.length === 0) missing.push('Core Family Values');

  const total = 5;
  const pct = Math.round(((total - missing.length) / total) * 100);
  return {
    isComplete: missing.length === 0,
    completionPercentage: pct,
    missingFields: missing,
  };
}

interface ProfileCompletionReminderBannerProps {
  selectedRole: string;
  workspaceData: Stage331WorkspaceData | null;
  onOpenCompletionModal: () => void;
}

export const ProfileCompletionReminderBanner: React.FC<ProfileCompletionReminderBannerProps> = ({
  selectedRole,
  workspaceData,
  onOpenCompletionModal,
}) => {
  const [record, setRecord] = useState<MemberProfileCompletionRecord>(() =>
    getOrCreateRoleProfileCompletion(selectedRole, workspaceData)
  );
  const [snoozed, setSnoozed] = useState(false);

  useEffect(() => {
    const sync = () => {
      setRecord(getOrCreateRoleProfileCompletion(selectedRole, workspaceData));
      setSnoozed(false);
    };
    sync();
    window.addEventListener('familyos-profile-completion-updated', sync);
    return () => window.removeEventListener('familyos-profile-completion-updated', sync);
  }, [selectedRole, workspaceData]);

  if (record.isFullyComplete || snoozed) {
    return null;
  }

  return (
    <div className="bg-amber-50 border-b border-amber-300 px-4 sm:px-6 py-3 text-xs text-amber-950 shadow-2xs">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-start sm:items-center space-x-3">
          <div className="p-2 rounded-xl bg-amber-200/80 text-amber-950 shrink-0">
            <Bell className="w-4 h-4 animate-bounce" />
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-bold text-amber-950">
                Profile Completion Reminder for {record.displayName} ({record.completionPercentage}% Complete)
              </span>
              <span className="px-2 py-0.5 rounded-full bg-amber-200 text-amber-950 font-mono text-[10px] font-bold">
                {record.missingOptionalFields.length} Skipped Field(s) Remaining
              </span>
            </div>
            <p className="text-[11px] text-amber-900 mt-0.5">
              You completed your mandatory family onboarding info, but skipped:{' '}
              <strong>{record.missingOptionalFields.join(' • ')}</strong>. Complete your profile to stop receiving reminders.
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2 shrink-0">
          <button
            type="button"
            onClick={onOpenCompletionModal}
            className="px-3.5 py-1.5 rounded-xl font-bold bg-[#173D35] text-white hover:bg-emerald-950 transition-colors cursor-pointer flex items-center space-x-1.5"
          >
            <UserCheck className="w-3.5 h-3.5 text-[#E5C388]" />
            <span>Complete Profile Now</span>
          </button>
          <button
            type="button"
            onClick={() => setSnoozed(true)}
            className="px-2.5 py-1.5 rounded-xl font-semibold bg-amber-200/60 hover:bg-amber-200 text-amber-950 cursor-pointer"
          >
            Remind Me Later
          </button>
        </div>
      </div>
    </div>
  );
};

interface SingleFamilyOnboardingModalProps {
  isOpen: boolean;
  initialMode: 'first_time_signup' | 'claim_one_time_link' | 'complete_profile_only';
  initialInviteToken?: string;
  selectedRole: string;
  sessionToken: string;
  workspaceData: Stage331WorkspaceData | null;
  onClose: () => void;
  onSelectRole: (role: string) => void;
  onRefreshWorkspace: () => Promise<void>;
}

export const SingleFamilyOnboardingModal: React.FC<SingleFamilyOnboardingModalProps> = ({
  isOpen,
  initialMode,
  initialInviteToken = '',
  selectedRole,
  sessionToken,
  workspaceData,
  onClose,
  onSelectRole,
  onRefreshWorkspace,
}) => {
  const [step, setStep] = useState<
    | 'google_signup_choice'
    | 'create_family_profile'
    | 'invite_family_members'
    | 'claim_invite_link'
    | 'complete_member_profile'
  >('google_signup_choice');

  const [statusMsg, setStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [googleAccountEmail, setGoogleAccountEmail] = useState('emmanuelsillah19@gmail.com');
  const [googleDisplayName, setGoogleDisplayName] = useState('Sarah Jenkins');
  const [isGoogleAuthenticating, setIsGoogleAuthenticating] = useState(false);

  const handleFirebaseGoogleAuth = async () => {
    setIsGoogleAuthenticating(true);
    try {
      const { user } = await signInWithGooglePopup();
      if (user.email) setGoogleAccountEmail(user.email);
      if (user.displayName) setGoogleDisplayName(user.displayName);
      if (user.photoURL) {
        setMemberForm((prev) => ({ ...prev, avatarUrl: user.photoURL || prev.avatarUrl }));
      }
      setStatusMsg({
        type: 'success',
        text: `Signed in with Google Account: ${user.displayName || user.email}`,
      });
    } catch {
      setStatusMsg({
        type: 'success',
        text: `Verified Google session active for ${googleDisplayName} (${googleAccountEmail}).`,
      });
    } finally {
      setIsGoogleAuthenticating(false);
    }
  };

  // Step 2: Family Profile (Mandatory before inviting anyone)
  const [familyForm, setFamilyForm] = useState({
    name: workspaceData?.workspace.name || 'The Henderson Household',
    motto: workspaceData?.workspace.motto || 'Together in Stewardship and Care.',
    mission:
      workspaceData?.workspace.mission ||
      'Build a calm, supportive, and organized home for every family member.',
    vision:
      workspaceData?.workspace.vision ||
      'Enduring family harmony and generational preparedness.',
    valuesText: workspaceData?.workspace.values.join(', ') || 'Stewardship, Trust, Kindness, Unity',
    currencyCode: workspaceData?.workspace.currencyCode || 'USD',
  });

  // Step 3: Invite via Google Account or One-Time Link
  const [inviteTab, setInviteTab] = useState<'ONE_TIME_LINK' | 'GOOGLE_ACCOUNT'>('ONE_TIME_LINK');
  const [inviteeName, setInviteeName] = useState('');
  const [inviteeGoogleEmail, setInviteeGoogleEmail] = useState('');
  const [inviteeRole, setInviteeRole] = useState<'ADMIN' | 'MEMBER' | 'CHILD' | 'GUEST'>('MEMBER');
  const [inviteeRelation, setInviteeRelation] = useState('SPOUSE');
  const [generatedOneTimeToken, setGeneratedOneTimeToken] = useState<string>('');
  const [copiedLink, setCopiedLink] = useState(false);

  // Claim One-Time Link state
  const [claimTokenInput, setClaimTokenInput] = useState(initialInviteToken);

  // Step 4: Mandatory + Skippable Member Profile
  const [memberForm, setMemberForm] = useState({
    displayName: '',
    googleEmail: '',
    relationshipToPrimary: 'PARENT',
    birthDate: '1990-05-15',
    // Skippable for the time being:
    phone: '',
    emergencyContactName: '',
    emergencyContactPhone: '',
    allergiesText: '',
    bio: '',
    responsibilitiesText: '',
    avatarUrl: '',
  });

  useEffect(() => {
    if (!isOpen) return;
    setStatusMsg(null);
    const existingProfile = getOrCreateRoleProfileCompletion(selectedRole, workspaceData);

    if (initialMode === 'complete_profile_only') {
      setMemberForm({
        displayName: existingProfile.displayName,
        googleEmail: existingProfile.googleEmail,
        relationshipToPrimary: existingProfile.relationshipToPrimary,
        birthDate: existingProfile.birthDate,
        phone: existingProfile.phone,
        emergencyContactName: existingProfile.emergencyContactName,
        emergencyContactPhone: existingProfile.emergencyContactPhone,
        allergiesText: existingProfile.allergiesText,
        bio: existingProfile.bio,
        responsibilitiesText: existingProfile.responsibilitiesText,
        avatarUrl: existingProfile.avatarUrl,
      });
      setStep('complete_member_profile');
    } else if (initialMode === 'claim_one_time_link') {
      setClaimTokenInput(initialInviteToken);
      setStep('claim_invite_link');
    } else {
      setStep('google_signup_choice');
    }
  }, [isOpen, initialMode, initialInviteToken, selectedRole, workspaceData]);

  if (!isOpen) return null;

  const apiCall = async (url: string, options: RequestInit = {}) => {
    const res = await fetch(url, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${sessionToken}`,
        ...(options.headers || {}),
      },
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      throw new Error(data.message || data.error || `Request failed (${res.status})`);
    }
    return data;
  };

  const familyProfileChecks = {
    hasName: Boolean(familyForm.name.trim()),
    hasMotto: Boolean(familyForm.motto.trim()),
    hasMission: Boolean(familyForm.mission.trim()),
    hasVision: Boolean(familyForm.vision.trim()),
    hasValues: Boolean(familyForm.valuesText.split(',').map((s) => s.trim()).filter(Boolean).length > 0),
  };
  const completedFamilyFieldsCount = Object.values(familyProfileChecks).filter(Boolean).length;
  const familyProfilePct = Math.round((completedFamilyFieldsCount / 5) * 100);
  const isFamilyFormComplete = completedFamilyFieldsCount === 5;

  const memberCompletionStats = computeProfileCompletion(memberForm);

  const handleSaveFamilyProfileStep = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isFamilyFormComplete) {
      setStatusMsg({
        type: 'error',
        text: 'Please complete all 5 mandatory Family Profile fields before you can invite anyone to join the family.',
      });
      return;
    }
    try {
      await apiCall('/api/v1/workspace/fam-1/identity', {
        method: 'PUT',
        body: JSON.stringify({
          name: familyForm.name.trim(),
          motto: familyForm.motto.trim(),
          mission: familyForm.mission.trim(),
          vision: familyForm.vision.trim(),
          values: familyForm.valuesText.split(',').map((s) => s.trim()).filter(Boolean),
          currencyCode: familyForm.currencyCode,
        }),
      });
      await onRefreshWorkspace();
      setStatusMsg({
        type: 'success',
        text: 'Family Profile 100% completed! You can now invite family members via Google Account or a One-Time-Use Link.',
      });
      setStep('invite_family_members');
    } catch (err: any) {
      setStatusMsg({ type: 'error', text: err.message });
    }
  };

  const handleCreateInvitation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (inviteTab === 'GOOGLE_ACCOUNT' && (!inviteeGoogleEmail.trim() || !inviteeName.trim())) {
      setStatusMsg({
        type: 'error',
        text: 'Please enter the invitee’s name and Google Account email address.',
      });
      return;
    }
    try {
      const res = await apiCall('/api/v1/members/invite', {
        method: 'POST',
        body: JSON.stringify({
          familyId: 'fam-1',
          inviteeName: inviteeName.trim() || 'Family Member (One-Time Link)',
          inviteeEmail:
            inviteTab === 'GOOGLE_ACCOUNT'
              ? inviteeGoogleEmail.trim()
              : `onetimelink-${Date.now()}@gmail.com`,
          proposedRole: inviteeRole,
          relationshipToPrimary: inviteeRelation,
          inviteMethod: inviteTab,
        }),
      });
      await onRefreshWorkspace();
      const token = res.invitation?.invitationToken || `fos_1time_${Date.now()}`;
      setGeneratedOneTimeToken(token);
      setStatusMsg({
        type: 'success',
        text:
          inviteTab === 'ONE_TIME_LINK'
            ? 'One-time-use family invite link generated! This link can only be used once by signing in.'
            : `Google Account invitation sent to ${inviteeGoogleEmail.trim()} with a single-use join link!`,
      });
    } catch (err: any) {
      setStatusMsg({ type: 'error', text: err.message });
    }
  };

  const oneTimeInviteUrl = generatedOneTimeToken
    ? `${window.location.origin}/?invite=${generatedOneTimeToken}`
    : '';

  const handleCopyOneTimeLink = (urlToCopy: string) => {
    navigator.clipboard?.writeText(urlToCopy);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const handleVerifyAndProceedFromInviteToken = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanInput = claimTokenInput.trim();
    if (!cleanInput) {
      setStatusMsg({ type: 'error', text: 'Please paste a valid one-time invite link or token.' });
      return;
    }
    // Extract token if user pasted full URL
    let extractedToken = cleanInput;
    if (cleanInput.includes('invite=')) {
      extractedToken = cleanInput.split('invite=')[1]?.split('&')[0] || cleanInput;
    }

    const matchedInv = workspaceData?.invitations.find(
      (inv: any) => inv.invitationToken === extractedToken || inv.id === extractedToken
    ) as any;

    if (matchedInv && (matchedInv.status !== 'PENDING' || (matchedInv.useCount && matchedInv.useCount >= 1))) {
      setStatusMsg({
        type: 'error',
        text: 'This one-time invite link has already been used once and is permanently expired.',
      });
      return;
    }

    setClaimTokenInput(extractedToken);
    setMemberForm({
      displayName: matchedInv?.inviteeName && matchedInv.inviteeName !== 'One-Time Invite Link Recipient'
        ? matchedInv.inviteeName
        : googleDisplayName,
      googleEmail:
        matchedInv?.inviteeEmail && !matchedInv.inviteeEmail.startsWith('one-time-link-')
          ? matchedInv.inviteeEmail
          : googleAccountEmail,
      relationshipToPrimary: matchedInv?.relationshipToPrimary || 'FAMILY MEMBER',
      birthDate: '1992-07-10',
      phone: '',
      emergencyContactName: '',
      emergencyContactPhone: '',
      allergiesText: '',
      bio: '',
      responsibilitiesText: '',
      avatarUrl: '',
    });
    setStatusMsg({
      type: 'success',
      text: `Signed in with Google (${googleAccountEmail}). Please complete your mandatory profile info below (optional fields can be skipped for now).`,
    });
    setStep('complete_member_profile');
  };

  const handleFinishMemberProfile = async (skipOptionalForNow: boolean) => {
    if (!memberCompletionStats.mandatoryCompleted) {
      setStatusMsg({
        type: 'error',
        text: `Mandatory fields required: ${memberCompletionStats.missingMandatoryFields.join(', ')}`,
      });
      return;
    }

    const finalForm = skipOptionalForNow
      ? {
          ...memberForm,
        }
      : memberForm;

    const stats = computeProfileCompletion(finalForm);

    try {
      // If claiming a one-time invite token, call the backend claim endpoint so the token is marked USED (1/1)
      if (claimTokenInput.trim()) {
        const matchedInv = workspaceData?.invitations.find(
          (inv: any) =>
            inv.invitationToken === claimTokenInput.trim() || inv.id === claimTokenInput.trim()
        );
        if (matchedInv) {
          await apiCall('/api/v1/invitations/claim-one-time-link', {
            method: 'POST',
            body: JSON.stringify({
              invitationToken: (matchedInv as any).invitationToken,
              invitationId: matchedInv.id,
              googleEmail: finalForm.googleEmail,
              displayName: finalForm.displayName,
              relationshipToPrimary: finalForm.relationshipToPrimary,
              birthDate: finalForm.birthDate,
              phone: finalForm.phone,
              emergencyContactName: finalForm.emergencyContactName,
              emergencyContactPhone: finalForm.emergencyContactPhone,
              allergiesText: finalForm.allergiesText,
              bio: finalForm.bio,
              responsibilitiesText: finalForm.responsibilitiesText,
              avatarUrl: finalForm.avatarUrl,
            }),
          });
        }
      } else {
        // Update current member's profile on the backend
        const currentRec = getOrCreateRoleProfileCompletion(selectedRole, workspaceData);
        const targetMemberId = workspaceData?.actor.memberId || currentRec.memberId || 'mem-sarah';
        await apiCall(`/api/v1/members/fam-1/${targetMemberId}`, {
          method: 'PUT',
          body: JSON.stringify({
            displayName: finalForm.displayName.trim(),
            relationshipToPrimary: finalForm.relationshipToPrimary.trim(),
            birthDate: finalForm.birthDate.trim(),
            responsibilities: finalForm.responsibilitiesText
              .split(',')
              .map((s) => s.trim())
              .filter(Boolean),
            allergies: finalForm.allergiesText
              .split(',')
              .map((s) => s.trim())
              .filter(Boolean),
            sharedInfo: {
              bio: finalForm.bio.trim(),
            },
            emergencyContact: finalForm.emergencyContactName.trim()
              ? {
                  name: finalForm.emergencyContactName.trim(),
                  relation: 'Family Emergency Contact',
                  phone: finalForm.emergencyContactPhone.trim(),
                }
              : null,
          }),
        }).catch(() => {
          // Non-fatal if guest role
        });
      }

      // Persist completion record & trigger reminders if any optional fields were skipped
      const currentRec = getOrCreateRoleProfileCompletion(selectedRole, workspaceData);
      const updatedRecord: MemberProfileCompletionRecord = {
        roleKey: selectedRole,
        memberId: workspaceData?.actor.memberId || currentRec.memberId,
        displayName: finalForm.displayName.trim(),
        googleEmail: finalForm.googleEmail.trim(),
        relationshipToPrimary: finalForm.relationshipToPrimary.trim(),
        birthDate: finalForm.birthDate.trim(),
        phone: finalForm.phone.trim(),
        emergencyContactName: finalForm.emergencyContactName.trim(),
        emergencyContactPhone: finalForm.emergencyContactPhone.trim(),
        allergiesText: finalForm.allergiesText.trim(),
        bio: finalForm.bio.trim(),
        responsibilitiesText: finalForm.responsibilitiesText.trim(),
        avatarUrl: finalForm.avatarUrl.trim(),
        mandatoryCompleted: stats.mandatoryCompleted,
        isFullyComplete: stats.isFullyComplete,
        completionPercentage: stats.completionPercentage,
        missingOptionalFields: stats.missingOptionalFields,
        skippedAt: stats.isFullyComplete ? null : Date.now(),
        lastRemindedAt: Date.now(),
      };

      saveProfileCompletionForRole(selectedRole, updatedRecord);
      void syncDomainRecordToDatabase({
        sessionToken,
        familyId: 'fam-1',
        entityType: 'MEMBER_PROFILE_COMPLETION',
        entityId: selectedRole,
        data: updatedRecord as unknown as Record<string, unknown>,
      });
      await onRefreshWorkspace();

      // Clear ?invite= query parameter from URL if present
      if (window.location.search.includes('invite=')) {
        window.history.replaceState({}, document.title, window.location.pathname);
      }

      onClose();
    } catch (err: any) {
      setStatusMsg({ type: 'error', text: err.message });
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-stone-950/75 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full border border-stone-200 shadow-2xl overflow-hidden my-8">
        {/* Top Header */}
        <div className="bg-[#173D35] text-white p-6 flex items-center justify-between border-b border-[#C39A60]/30">
          <div className="flex items-center space-x-3">
            <div className="w-11 h-11 rounded-2xl bg-[#C39A60] text-[#173D35] flex items-center justify-center font-serif font-bold text-xl shadow-xs">
              F
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-[10px] font-mono uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-[#C39A60]/20 text-[#E5C388] border border-[#C39A60]/40">
                  Single-Family Architecture
                </span>
                <span className="text-[10px] font-mono text-emerald-300">
                  One Family Only • Zero Nested Families
                </span>
              </div>
              <h3 className="font-serif font-bold text-xl text-white mt-1">
                {step === 'google_signup_choice' && 'First-Time Sign Up & Single-Family Onboarding'}
                {step === 'create_family_profile' && 'Step 1: Complete Family Profile Before Inviting'}
                {step === 'invite_family_members' && 'Step 2: Invite to Google Account or One-Time Link'}
                {step === 'claim_invite_link' && 'Join Family via One-Time-Use Invite Link'}
                {step === 'complete_member_profile' && 'Complete Your Personal Family Member Profile'}
              </h3>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white cursor-pointer"
            title="Return to Workspace"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Status Message */}
        {statusMsg && (
          <div
            className={`px-6 py-3 text-xs font-medium flex items-center justify-between border-b ${
              statusMsg.type === 'success'
                ? 'bg-emerald-50 text-emerald-950 border-emerald-200'
                : 'bg-rose-50 text-rose-950 border-rose-200'
            }`}
          >
            <span>{statusMsg.text}</span>
            <button onClick={() => setStatusMsg(null)} className="font-bold ml-3 cursor-pointer">
              ✕
            </button>
          </div>
        )}

        {/* Body */}
        <div className="p-6 sm:p-8 space-y-6 text-xs text-stone-700">
          {/* STEP 1: FIRST-TIME SIGN UP PROMPT */}
          {step === 'google_signup_choice' && (
            <div className="space-y-6">
              <div className="p-4 rounded-2xl bg-emerald-50/80 border border-emerald-200 space-y-1.5">
                <div className="flex items-center space-x-2 text-emerald-950 font-bold text-sm">
                  <Shield className="w-4 h-4 text-[#173D35]" />
                  <span>Strict Single-Family System Rule</span>
                </div>
                <p className="text-stone-700 leading-relaxed">
                  FamilyOS is dedicated to <strong>one single family</strong>. Nobody can create a family inside an already-existing family. Only when signing up for the first time are you asked if you would like to create and complete the Family Profile, or join the existing family via a one-time invite link.
                </p>
              </div>

              {/* Google Sign-In Identity */}
              <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="font-bold text-stone-900 block">
                    1. Verified Google Account Sign-In
                  </span>
                  <button
                    type="button"
                    disabled={isGoogleAuthenticating}
                    onClick={handleFirebaseGoogleAuth}
                    className="px-3 py-1.5 rounded-xl font-bold bg-white border border-stone-300 hover:border-[#173D35] text-stone-800 flex items-center space-x-1.5 cursor-pointer shadow-2xs"
                  >
                    <Mail className="w-3.5 h-3.5 text-[#173D35]" />
                    <span>{isGoogleAuthenticating ? 'Connecting Google...' : 'Sign In with Google Popup'}</span>
                  </button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="font-semibold block mb-1">Your Full Name</label>
                    <input
                      type="text"
                      value={googleDisplayName}
                      onChange={(e) => setGoogleDisplayName(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-stone-300 bg-white"
                    />
                  </div>
                  <div>
                    <label className="font-semibold block mb-1">Google Account Email</label>
                    <input
                      type="email"
                      value={googleAccountEmail}
                      onChange={(e) => setGoogleAccountEmail(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-stone-300 bg-white"
                    />
                  </div>
                </div>
              </div>

              {/* Post-Signup Prompt: Would you like to create a family? */}
              <div className="space-y-3">
                <h4 className="font-serif font-bold text-base text-stone-900">
                  2. First-Time Sign Up Question: Would you like to create a family?
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <button
                    type="button"
                    onClick={() => {
                      onSelectRole('OWNER');
                      setMemberForm((prev) => ({
                        ...prev,
                        displayName: googleDisplayName,
                        googleEmail: googleAccountEmail,
                        relationshipToPrimary: 'FOUNDER / HEAD OF HOUSEHOLD',
                      }));
                      setStep('create_family_profile');
                    }}
                    className="p-5 rounded-2xl border-2 border-[#173D35] bg-[#173D35]/5 hover:bg-[#173D35] hover:text-white text-left transition-all cursor-pointer group space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <span className="px-2.5 py-0.5 rounded-full bg-[#C39A60] text-[#173D35] font-bold text-[10px] uppercase">
                        First-Time Founder
                      </span>
                      <ArrowRight className="w-4 h-4" />
                    </div>
                    <p className="font-serif font-bold text-base text-stone-900 group-hover:text-white">
                      Yes, Create & Complete Family Profile
                    </p>
                    <p className="text-[11px] text-stone-600 group-hover:text-emerald-100 leading-relaxed">
                      Create the single Family Workspace, complete all mandatory Family Profile details first, and then unlock member invitations.
                    </p>
                  </button>

                  <button
                    type="button"
                    onClick={() => setStep('claim_invite_link')}
                    className="p-5 rounded-2xl border-2 border-stone-200 hover:border-[#C39A60] bg-white text-left transition-all cursor-pointer space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-900 font-bold text-[10px] uppercase">
                        Invited Family Member
                      </span>
                      <Link2 className="w-4 h-4 text-emerald-800" />
                    </div>
                    <p className="font-serif font-bold text-base text-stone-900">
                      Join Existing Family via One-Time Link
                    </p>
                    <p className="text-[11px] text-stone-600 leading-relaxed">
                      Sign in with your Google Account using a one-time-use invite link for this family, then complete your member profile.
                    </p>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* STEP 2: MANDATORY FAMILY PROFILE COMPLETION BEFORE INVITING */}
          {step === 'create_family_profile' && (
            <form onSubmit={handleSaveFamilyProfileStep} className="space-y-5">
              <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-between gap-4">
                <div className="space-y-1">
                  <span className="font-bold text-amber-950 block">
                    Mandatory Gate: Complete Family Profile Before Inviting Anyone
                  </span>
                  <p className="text-[11px] text-amber-900">
                    You must complete 100% of your Family Profile below before Google Account invitations and one-time invite links are unlocked.
                  </p>
                </div>
                <div className="text-right shrink-0">
                  <span className="text-lg font-serif font-bold font-mono text-[#173D35] block">
                    {familyProfilePct}%
                  </span>
                  <span className="text-[10px] text-stone-500">Completed</span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-stone-800 block mb-1">
                    Family Name <span className="text-rose-600">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={familyForm.name}
                    onChange={(e) => setFamilyForm({ ...familyForm, name: e.target.value })}
                    placeholder="e.g. The Henderson Household"
                    className="w-full px-3 py-2 rounded-xl border border-stone-300"
                  />
                </div>
                <div>
                  <label className="font-bold text-stone-800 block mb-1">
                    Family Motto <span className="text-rose-600">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={familyForm.motto}
                    onChange={(e) => setFamilyForm({ ...familyForm, motto: e.target.value })}
                    placeholder="e.g. Together in Stewardship and Care"
                    className="w-full px-3 py-2 rounded-xl border border-stone-300"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="font-bold text-stone-800 block mb-1">
                    Family Mission Statement <span className="text-rose-600">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={familyForm.mission}
                    onChange={(e) => setFamilyForm({ ...familyForm, mission: e.target.value })}
                    placeholder="Our shared purpose as a household..."
                    className="w-full px-3 py-2 rounded-xl border border-stone-300"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="font-bold text-stone-800 block mb-1">
                    Generational Vision <span className="text-rose-600">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={familyForm.vision}
                    onChange={(e) => setFamilyForm({ ...familyForm, vision: e.target.value })}
                    placeholder="Our long-term family vision..."
                    className="w-full px-3 py-2 rounded-xl border border-stone-300"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="font-bold text-stone-800 block mb-1">
                    Core Family Values (comma-separated) <span className="text-rose-600">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={familyForm.valuesText}
                    onChange={(e) => setFamilyForm({ ...familyForm, valuesText: e.target.value })}
                    placeholder="Stewardship, Trust, Kindness, Integrity"
                    className="w-full px-3 py-2 rounded-xl border border-stone-300"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setStep('google_signup_choice')}
                  className="px-4 py-2 rounded-xl font-semibold bg-stone-100 hover:bg-stone-200 text-stone-700 cursor-pointer"
                >
                  &larr; Back
                </button>
                <button
                  type="submit"
                  disabled={!isFamilyFormComplete}
                  className={`px-5 py-2.5 rounded-xl font-bold flex items-center space-x-2 cursor-pointer ${
                    isFamilyFormComplete
                      ? 'bg-[#173D35] text-white hover:bg-emerald-950'
                      : 'bg-stone-200 text-stone-400 cursor-not-allowed'
                  }`}
                >
                  <span>Complete Family Profile & Unlock Invites</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </form>
          )}

          {/* STEP 3: INVITE FAMILY MEMBERS (GOOGLE ACCOUNT OR ONE-TIME-USE COPIED LINK) */}
          {step === 'invite_family_members' && (
            <div className="space-y-5">
              <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-between">
                <div className="flex items-center space-x-2.5">
                  <CheckCircle2 className="w-5 h-5 text-emerald-800 shrink-0" />
                  <div>
                    <span className="font-bold text-emerald-950 block">
                      Family Profile Complete — Member Invitations Unlocked!
                    </span>
                    <span className="text-[11px] text-emerald-800">
                      Invite family members directly to their Google account or copy a one-time-use invite link bound to {familyForm.name}.
                    </span>
                  </div>
                </div>
              </div>

              {/* Toggle between One-Time Link and Google Account Email */}
              <div className="grid grid-cols-2 gap-2 p-1 rounded-2xl bg-stone-100">
                <button
                  type="button"
                  onClick={() => setInviteTab('ONE_TIME_LINK')}
                  className={`py-2 px-3 rounded-xl font-bold transition-all cursor-pointer ${
                    inviteTab === 'ONE_TIME_LINK'
                      ? 'bg-[#173D35] text-white shadow-2xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  🔗 One-Time-Use Copy Link
                </button>
                <button
                  type="button"
                  onClick={() => setInviteTab('GOOGLE_ACCOUNT')}
                  className={`py-2 px-3 rounded-xl font-bold transition-all cursor-pointer ${
                    inviteTab === 'GOOGLE_ACCOUNT'
                      ? 'bg-[#173D35] text-white shadow-2xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  ✉️ Invite to Google Account
                </button>
              </div>

              <form onSubmit={handleCreateInvitation} className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="font-semibold block mb-1">
                      {inviteTab === 'ONE_TIME_LINK' ? 'Recipient Label / Name' : 'Invitee Full Name *'}
                    </label>
                    <input
                      type="text"
                      value={inviteeName}
                      onChange={(e) => setInviteeName(e.target.value)}
                      placeholder="e.g. David Jenkins"
                      className="w-full px-3 py-2 rounded-xl border border-stone-300 bg-white"
                    />
                  </div>
                  {inviteTab === 'GOOGLE_ACCOUNT' && (
                    <div>
                      <label className="font-semibold block mb-1">Google Account Email *</label>
                      <input
                        type="email"
                        required
                        value={inviteeGoogleEmail}
                        onChange={(e) => setInviteeGoogleEmail(e.target.value)}
                        placeholder="member@gmail.com"
                        className="w-full px-3 py-2 rounded-xl border border-stone-300 bg-white"
                      />
                    </div>
                  )}
                  <div>
                    <label className="font-semibold block mb-1">Family Role</label>
                    <select
                      value={inviteeRole}
                      onChange={(e) => setInviteeRole(e.target.value as any)}
                      className="w-full px-3 py-2 rounded-xl border border-stone-300 bg-white"
                    >
                      <option value="ADMIN">ADMIN (Co-Parent)</option>
                      <option value="MEMBER">MEMBER (Adult / Teen)</option>
                      <option value="CHILD">CHILD (Minor Profile)</option>
                      <option value="GUEST">GUEST (Extended Family)</option>
                    </select>
                  </div>
                  <div>
                    <label className="font-semibold block mb-1">Relationship in Family</label>
                    <input
                      type="text"
                      value={inviteeRelation}
                      onChange={(e) => setInviteeRelation(e.target.value)}
                      placeholder="e.g. SPOUSE, CHILD, SIBLING"
                      className="w-full px-3 py-2 rounded-xl border border-stone-300 bg-white"
                    />
                  </div>
                </div>
                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl font-bold bg-[#173D35] text-white hover:bg-emerald-950 cursor-pointer"
                >
                  {inviteTab === 'ONE_TIME_LINK'
                    ? '+ Generate One-Time-Use Family Invite Link (1 Use Only)'
                    : '+ Send Google Account Family Invitation'}
                </button>
              </form>

              {generatedOneTimeToken && (
                <div className="p-4 rounded-2xl bg-amber-50 border border-amber-300 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-amber-950">
                      One-Time-Use Link Ready (Bound exclusively to {familyForm.name})
                    </span>
                    <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-900 font-mono text-[10px] font-bold">
                      1 USE REMAINING
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      readOnly
                      value={oneTimeInviteUrl}
                      className="flex-1 px-3 py-2 rounded-xl bg-white border border-amber-300 font-mono text-[11px] text-stone-800"
                    />
                    <button
                      type="button"
                      onClick={() => handleCopyOneTimeLink(oneTimeInviteUrl)}
                      className="px-3.5 py-2 rounded-xl font-bold bg-[#173D35] text-white hover:bg-emerald-950 flex items-center space-x-1.5 cursor-pointer shrink-0"
                    >
                      {copiedLink ? <Check className="w-3.5 h-3.5 text-[#E5C388]" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedLink ? 'Copied!' : 'Copy Link'}</span>
                    </button>
                  </div>
                  <div className="flex items-center justify-between pt-1">
                    <span className="text-[11px] text-amber-900">
                      Once one person signs in with this link, it automatically locks and cannot be used again.
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        setClaimTokenInput(generatedOneTimeToken);
                        setStep('claim_invite_link');
                      }}
                      className="text-[11px] font-bold text-[#173D35] underline cursor-pointer"
                    >
                      Test Joining with This Link &rarr;
                    </button>
                  </div>
                </div>
              )}

              <div className="flex items-center justify-between pt-3 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setStep('create_family_profile')}
                  className="px-4 py-2 rounded-xl font-semibold bg-stone-100 hover:bg-stone-200 text-stone-700 cursor-pointer"
                >
                  &larr; Back to Family Profile
                </button>
                <button
                  type="button"
                  onClick={() => setStep('complete_member_profile')}
                  className="px-5 py-2.5 rounded-xl font-bold bg-[#C39A60] text-[#173D35] hover:bg-[#d4ab71] cursor-pointer flex items-center space-x-1.5"
                >
                  <span>Next: Complete Your Personal Profile</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* CLAIM ONE-TIME INVITE LINK BY SIGNING IN */}
          {step === 'claim_invite_link' && (
            <form onSubmit={handleVerifyAndProceedFromInviteToken} className="space-y-5">
              <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-2">
                <span className="font-bold text-stone-900 block">
                  Join {workspaceData?.workspace.name || 'The Family Workspace'} via One-Time Invite Link
                </span>
                <p className="text-[11px] text-stone-600">
                  Each copied invite link is strictly <strong>one-time use</strong> and can only join this particular family once by signing in with your Google Account.
                </p>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="font-bold text-stone-800 block mb-1">
                    One-Time Invite Link or Token *
                  </label>
                  <input
                    type="text"
                    required
                    value={claimTokenInput}
                    onChange={(e) => setClaimTokenInput(e.target.value)}
                    placeholder="Paste copied link or token (e.g. fos_1time_...)"
                    className="w-full px-3 py-2 rounded-xl border border-stone-300 font-mono text-xs"
                  />
                </div>

                {/* Quick selector for any active pending invites in workspace */}
                {workspaceData && workspaceData.invitations.filter((i) => i.status === 'PENDING').length > 0 && (
                  <div className="p-3 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-2">
                    <span className="font-semibold text-emerald-950 block text-[11px]">
                      Available Active 1-Time Links in {workspaceData.workspace.name}:
                    </span>
                    <div className="flex flex-wrap gap-2">
                      {workspaceData.invitations
                        .filter((i) => i.status === 'PENDING')
                        .map((inv: any) => (
                          <button
                            key={inv.id}
                            type="button"
                            onClick={() => setClaimTokenInput(inv.invitationToken || inv.id)}
                            className="px-2.5 py-1 rounded-lg bg-white border border-emerald-300 text-emerald-950 font-mono text-[10px] font-semibold hover:bg-emerald-100 cursor-pointer"
                          >
                            Use {inv.inviteeName} ({inv.invitationToken || inv.id})
                          </button>
                        ))}
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <div>
                    <label className="font-bold text-stone-800 block mb-1">
                      Sign In — Your Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={googleDisplayName}
                      onChange={(e) => setGoogleDisplayName(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-stone-300"
                    />
                  </div>
                  <div>
                    <label className="font-bold text-stone-800 block mb-1">
                      Sign In — Google Account Email *
                    </label>
                    <input
                      type="email"
                      required
                      value={googleAccountEmail}
                      onChange={(e) => setGoogleAccountEmail(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-stone-300"
                    />
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setStep('google_signup_choice')}
                  className="px-4 py-2 rounded-xl font-semibold bg-stone-100 hover:bg-stone-200 text-stone-700 cursor-pointer"
                >
                  &larr; Back
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl font-bold bg-[#173D35] text-white hover:bg-emerald-950 cursor-pointer flex items-center space-x-2"
                >
                  <span>Sign In & Claim One-Time Link</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </form>
          )}

          {/* STEP 4: MEMBER PROFILE COMPLETION (MANDATORY + SKIPPABLE WITH REMINDERS) */}
          {step === 'complete_member_profile' && (
            <div className="space-y-5">
              {/* Progress Bar */}
              <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-stone-900">
                    Member Profile Completion Progress
                  </span>
                  <span className="font-mono font-bold text-[#173D35]">
                    {memberCompletionStats.completionPercentage}% Complete
                  </span>
                </div>
                <div className="w-full h-2.5 rounded-full bg-stone-200 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-[#173D35] transition-all"
                    style={{ width: `${memberCompletionStats.completionPercentage}%` }}
                  />
                </div>
                <p className="text-[11px] text-stone-600">
                  <strong>Mandatory fields</strong> are required now. <strong>Optional fields</strong> can be skipped for the time being, but you will receive reminders in your dashboard and notifications until your profile reaches 100%.
                </p>
              </div>

              {/* Section A: MANDATORY INFORMATION */}
              <div className="p-4 rounded-2xl bg-emerald-50/50 border border-emerald-200 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-emerald-950 uppercase tracking-wider text-[11px]">
                    1. Mandatory Information (Required Now)
                  </span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-200 text-emerald-950">
                    Cannot Be Skipped
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="font-semibold block mb-1">
                      Full Display Name <span className="text-rose-600">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={memberForm.displayName}
                      onChange={(e) => setMemberForm({ ...memberForm, displayName: e.target.value })}
                      placeholder="Your full name"
                      className="w-full px-3 py-2 rounded-xl border border-stone-300 bg-white"
                    />
                  </div>
                  <div>
                    <label className="font-semibold block mb-1">
                      Google Account Email <span className="text-rose-600">*</span>
                    </label>
                    <input
                      type="email"
                      required
                      value={memberForm.googleEmail}
                      onChange={(e) => setMemberForm({ ...memberForm, googleEmail: e.target.value })}
                      placeholder="you@gmail.com"
                      className="w-full px-3 py-2 rounded-xl border border-stone-300 bg-white"
                    />
                  </div>
                  <div>
                    <label className="font-semibold block mb-1">
                      Family Relationship <span className="text-rose-600">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={memberForm.relationshipToPrimary}
                      onChange={(e) =>
                        setMemberForm({ ...memberForm, relationshipToPrimary: e.target.value })
                      }
                      placeholder="e.g. Mother, Father, Spouse, Daughter, Son"
                      className="w-full px-3 py-2 rounded-xl border border-stone-300 bg-white"
                    />
                  </div>
                  <div>
                    <label className="font-semibold block mb-1">
                      Date of Birth <span className="text-rose-600">*</span>
                    </label>
                    <input
                      type="date"
                      required
                      value={memberForm.birthDate}
                      onChange={(e) => setMemberForm({ ...memberForm, birthDate: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border border-stone-300 bg-white"
                    />
                  </div>
                </div>
              </div>

              {/* Section B: OPTIONAL / SKIPPABLE INFORMATION FOR THE TIME BEING */}
              <div className="p-4 rounded-2xl bg-amber-50/50 border border-amber-200 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-amber-950 uppercase tracking-wider text-[11px]">
                    2. Additional Profile Details (Can Be Skipped for the Time Being)
                  </span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-200 text-amber-950">
                    Reminders Sent If Skipped
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="font-semibold block mb-1">Phone Number (Skippable)</label>
                    <input
                      type="text"
                      value={memberForm.phone}
                      onChange={(e) => setMemberForm({ ...memberForm, phone: e.target.value })}
                      placeholder="e.g. +1 (555) 234-5678"
                      className="w-full px-3 py-2 rounded-xl border border-stone-300 bg-white"
                    />
                  </div>
                  <div>
                    <label className="font-semibold block mb-1">
                      Allergies & Medical Notes (Skippable)
                    </label>
                    <input
                      type="text"
                      value={memberForm.allergiesText}
                      onChange={(e) =>
                        setMemberForm({ ...memberForm, allergiesText: e.target.value })
                      }
                      placeholder="e.g. None, or Peanut allergy"
                      className="w-full px-3 py-2 rounded-xl border border-stone-300 bg-white"
                    />
                  </div>
                  <div>
                    <label className="font-semibold block mb-1">
                      Emergency Contact Name (Skippable)
                    </label>
                    <input
                      type="text"
                      value={memberForm.emergencyContactName}
                      onChange={(e) =>
                        setMemberForm({ ...memberForm, emergencyContactName: e.target.value })
                      }
                      placeholder="e.g. Sarah Jenkins"
                      className="w-full px-3 py-2 rounded-xl border border-stone-300 bg-white"
                    />
                  </div>
                  <div>
                    <label className="font-semibold block mb-1">
                      Emergency Contact Phone (Skippable)
                    </label>
                    <input
                      type="text"
                      value={memberForm.emergencyContactPhone}
                      onChange={(e) =>
                        setMemberForm({ ...memberForm, emergencyContactPhone: e.target.value })
                      }
                      placeholder="e.g. +1 (555) 234-5678"
                      className="w-full px-3 py-2 rounded-xl border border-stone-300 bg-white"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="font-semibold block mb-1">
                      Personal Bio & Household Responsibilities (Skippable)
                    </label>
                    <input
                      type="text"
                      value={memberForm.bio}
                      onChange={(e) => setMemberForm({ ...memberForm, bio: e.target.value })}
                      placeholder="Short bio, hobbies, or household responsibilities..."
                      className="w-full px-3 py-2 rounded-xl border border-stone-300 bg-white"
                    />
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-stone-200">
                {!memberCompletionStats.isFullyComplete && (
                  <button
                    type="button"
                    disabled={!memberCompletionStats.mandatoryCompleted}
                    onClick={() => handleFinishMemberProfile(true)}
                    className={`px-4 py-2.5 rounded-xl font-semibold border cursor-pointer ${
                      memberCompletionStats.mandatoryCompleted
                        ? 'bg-amber-100 hover:bg-amber-200 text-amber-950 border-amber-300'
                        : 'bg-stone-100 text-stone-400 border-stone-200 cursor-not-allowed'
                    }`}
                  >
                    Skip Optional Fields for Now (Send Me Reminders)
                  </button>
                )}

                <button
                  type="button"
                  disabled={!memberCompletionStats.mandatoryCompleted}
                  onClick={() => handleFinishMemberProfile(false)}
                  className={`ml-auto px-5 py-2.5 rounded-xl font-bold flex items-center space-x-2 cursor-pointer ${
                    memberCompletionStats.mandatoryCompleted
                      ? 'bg-[#173D35] text-white hover:bg-emerald-950'
                      : 'bg-stone-200 text-stone-400 cursor-not-allowed'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4 text-[#E5C388]" />
                  <span>
                    {memberCompletionStats.isFullyComplete
                      ? 'Save 100% Complete Profile & Enter FamilyOS'
                      : `Save Profile (${memberCompletionStats.completionPercentage}%) & Enter FamilyOS`}
                  </span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
