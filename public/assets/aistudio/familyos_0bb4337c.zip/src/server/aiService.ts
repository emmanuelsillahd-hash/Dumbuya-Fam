import { GoogleGenAI } from '@google/genai';

const genAI = new GoogleGenAI(process.env.GEMINI_API_KEY || '');

export async function generatePlanningContent(prompt: string, model: string = 'gemini-3.8-flash') {
  const modelInstance = genAI.getGenerativeModel({ model: model });
  const result = await modelInstance.generateContent(prompt);
  return result.response.text();
}
