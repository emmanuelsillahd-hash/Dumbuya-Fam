package com.familyos.core.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * The 16 canonical FamilyOS navigation destinations.
 */
enum class FamilyOSDestination(
    val route: String,
    val title: String,
    val icon: ImageVector,
    val isCoreTab: Boolean = false // Appears in phone bottom bar
) {
    OVERVIEW("overview", "Overview", Icons.Default.Home, isCoreTab = true),
    FAMILY("family", "The Family", Icons.Default.People, isCoreTab = true),
    GOALS_PROJECTS("goals_projects", "Goals & Projects", Icons.Default.CheckCircle, isCoreTab = true),
    HOUSEHOLD("household", "Household", Icons.Default.Kitchen, isCoreTab = true),
    FINANCE("finance", "Finance", Icons.Default.AccountBalance, isCoreTab = true),
    
    // Extended Family Modules
    SPIRITUAL_GROWTH("spiritual_growth", "Spiritual Growth", Icons.Default.MenuBook),
    PERSONAL_DEV("personal_development", "Personal Development", Icons.Default.TrendingUp),
    COUPLES_PREP("couples_prep", "Couples Preparation", Icons.Default.Favorite),
    PARENTING("parenting", "Parenting & Children", Icons.Default.ChildCare),
    HEALTH_FITNESS("health_fitness", "Health & Fitness", Icons.Default.FavoriteBorder),
    FAMILY_SAFETY("family_safety", "Family Safety", Icons.Default.HealthAndSafety),
    INVESTMENTS("investments", "Investments", Icons.Default.ShowChart),
    
    // Core Cross-Cutting Systems
    CALENDAR("calendar", "Calendar", Icons.Default.CalendarMonth),
    DOCUMENTS("documents", "Documents", Icons.Default.Folder),
    REPORTS("reports", "Reports & Insights", Icons.Default.BarChart),
    SETTINGS("settings", "Settings", Icons.Default.Settings);

    companion object {
        fun fromRoute(route: String?): FamilyOSDestination {
            return entries.find { it.route == route } ?: OVERVIEW
        }
    }
}
