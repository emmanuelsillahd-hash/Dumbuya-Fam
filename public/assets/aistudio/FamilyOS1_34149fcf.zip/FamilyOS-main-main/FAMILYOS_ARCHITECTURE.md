# FAMILYOS — TECHNICAL ARCHITECTURE SPECIFICATION
**Version**: 1.0.0 (Stage 0 Baseline)  
**System**: Android Native (Jetpack Compose / Clean Architecture) & Cloud Services  

---

## 1. Platform & Environment Specification

### 1.1 Android SDK & Target Configurations
- **minSdkVersion**: `26` (Android 8.0 Oreo)
  - *Justification*: Provides 96.5%+ global Android active device coverage while giving native Java 8/time API support (`java.time.Instant`), notification channels, hardware-backed Keystore, modern biometric authentication APIs (`BiometricPrompt`), and robust WorkManager background job reliability without multidex overhead.
- **targetSdkVersion**: `35` (Android 15)
  - *Justification*: Required for Google Play Store compliance (Play Console requires targeting Android 14 API 34 minimum, moving to Android 15 API 35 for latest submissions), full predictive back gestures, Edge-to-Edge window enforcement, and strict foreground service type declarations.
- **compileSdkVersion**: `35`
- **Kotlin Version**: `2.0.21` (with Compose Compiler Gradle Plugin)
- **Android Gradle Plugin (AGP)**: `8.7.2`
- **Gradle Version**: `8.9`
- **JVM Target**: `Java 17`

---

## 2. Technology Stack & Library Version Matrix (Verified Mutually Compatible)

| Layer / Concern | Technology Selection | Version | Justification & Compatibility |
|---|---|---|---|
| **Build Tooling** | Android Gradle Plugin (AGP) | `8.7.2` | Current production stable release; requires Gradle 8.9+ and JDK 17. |
| **Build Engine** | Gradle Wrapper | `8.9` | Official compatible build engine for AGP 8.7.2. |
| **Language** | Kotlin & Compose Plugin | `2.0.21` | Modern Kotlin K2 compiler with native Compose compiler plugin. |
| **UI Toolkit** | Jetpack Compose (BOM) | `2024.10.01` | Pure declarative UI, zero legacy XML overhead, adaptive layouts for tablets/foldables. |
| **Design System** | Material 3 Components | `1.3.1` | Modern Material You theming customized with FamilyOS Warm Forest & Gold palette. |
| **Navigation** | Navigation Compose | `2.8.3` | Type-safe navigation with Kotlinx Serialization 1.7.3. |
| **Architecture** | Lifecycle & ViewModel | `2.8.7` | Predictable unidirectional data flow (UDF), ViewModel state preservation. |
| **Asynchrony** | Coroutines & Flow | `1.9.0` | Reactive streaming, backpressure handling, cancellation hierarchy. |
| **Local Database** | Room SQLite ORM | `2.6.1` | Type-safe SQL, FTS5 full-text search, compile-time query verification, Room Flow streams. |
| **Key-Value Store** | Jetpack DataStore (Preferences) | `1.1.1` | Thread-safe, asynchronous replacement for SharedPreferences. |
| **Background Tasks**| WorkManager | `2.9.1` | Guaranteed background execution for offline synchronization, data cleanup. |
| **Cloud Services** | Firebase Android SDK (BOM) | `33.5.1` | High-availability Auth, Firestore real-time sync, Storage for attachments, App Check. |
| **Database Encryption**| SQLCipher Android | `4.5.5` | `net.zetetic:sqlcipher-android:4.5.5` for 256-bit AES database encryption. |
| **Security & Crypto**| AndroidX Security Crypto | `1.1.0-alpha06` | Hardware-backed MasterKey via Android Keystore, EncryptedSharedPreferences. |
| **Biometrics** | AndroidX Biometric | `1.2.0-alpha05` | Standardized Face & Fingerprint authentication dialogs (local convenience unlock only). |
| **Play Billing** | Google Play Billing Library | `7.1.1` | Compliant in-app subscription and digital purchase management. |
| **JSON Serialization**| Kotlinx Serialization | `1.7.3` | Ultra-fast reflection-free JSON parsing for network payloads and Room type converters. |
| **Testing** | JUnit 4/5, MockK, Turbine | `1.13.13` / `1.2.0` | Comprehensive unit tests, Flow testing via Turbine, state-restoration tests. |

---

## 3. Clean Architecture & Layered Boundaries

```
+-----------------------------------------------------------------------------------------+
|                                    PRESENTATION LAYER                                    |
|   Composables (Screens, Custom Components, Theme) <--> ViewModels (StateFlow, Intents)  |
|   State: UiState<T> (Loading, Success, Empty, Error) | One-time Events: Channel / Flow   |
+-----------------------------------------------------------------------------------------+
                                             |
                                             v
+-----------------------------------------------------------------------------------------+
|                                      DOMAIN LAYER                                        |
|   Use Cases / Interactors (Single Responsibility: e.g. CalculateAvailableCashFlowUseCase) |
|   Domain Models (Immutable pure Kotlin models: Money, FamilyTree, MealPlan)              |
|   Repository Interfaces (Strict abstract contracts)                                      |
+-----------------------------------------------------------------------------------------+
                                             |
                                             v
+-----------------------------------------------------------------------------------------+
|                                       DATA LAYER                                         |
|   Repository Implementations (Offline-First source of truth coordinator)                |
|   - Reads Room Dao first -> returns Flow<List<DomainModel>>                             |
|   - Dispatches mutations to Room Dao + writes to SyncQueueEntity                         |
|   - Triggers SyncWorker to reconcile with Remote DataSource                             |
+-----------------------------------------------------------------------------------------+
                 |                                                         |
                 v                                                         v
+----------------------------------+                     +----------------------------------+
|          LOCAL DATA SOURCE       |                     |        REMOTE DATA SOURCE        |
| - Room Database (SQLite + FTS5)  |                     | - Firebase Firestore Client SDK  |
| - Encrypted DataStore            |                     | - Firebase Storage (Attachments) |
| - Android Keystore Cryptography  |                     | - Cloud Functions (Gemini Proxy) |
+----------------------------------+                     +----------------------------------+
```

---

## 4. Decoupled Identity, Membership, Guardian & Permission Model

A critical architectural requirement in FamilyOS is separating five distinct concepts:
1. **Authenticated User Account (`UserAccount`)**: Owned exclusively by the identity provider (Firebase Auth). Stores NO passwords, hashes, or auth secrets.
2. **Family Membership (`FamilyMembership`)**: Connects an authenticated user account to a specific family workspace with a verified role.
3. **Family Member Profile (`FamilyMember`)**: The household human representation (name, birthday, dietary rules, milestones). Can exist independently without an account (crucial for minor children, dependents, or elderly family members).
4. **Guardian Relationship (`GuardianRelationship`)**: Explicit legal/parental stewardship mapping which adult accounts supervise which minor profiles.
5. **Permission Assignment (`PermissionAssignment`)**: Verified server-side capabilities (not client-side UI toggles).

```
+--------------------------------------------------------+
|                      UserAccount                       |
| - id: UUID (Internal unique reference)                 |
| - authenticationProvider: FIREBASE_GOOGLE | EMAIL_PASS |
| - providerUserId: String (Stable Auth UID from IdP)    |
| - email: String                                        |
| - displayName: String?                                 |
| - profilePictureUri: String?                           |
| - preferredLanguage: String                            |
| - accountStatus: ACTIVE | SUSPENDED | PENDING_DELETION |
| - createdAt: Long (epoch millis)                       |
| - updatedAt: Long (epoch millis)                       |
+--------------------------------------------------------+
                           |
                           | 1..* (An account can hold memberships in multiple families)
                           v
+--------------------------------------------------------+
|                    FamilyMembership                    |
| - id: UUID                                             |
| - familyId: UUID (FK -> FamilyWorkspace)               |
| - userAccountId: UUID (FK -> UserAccount)              |
| - memberProfileId: UUID (FK -> FamilyMember)           |
| - role: OWNER | ADMIN | MEMBER | GUEST                 |
| - status: ACTIVE | INVITED | REVOKED                   |
| - joinedAt: Long                                       |
+--------------------------------------------------------+
                           |
                           | 1..1
                           v
+--------------------------------------------------------+
|                      FamilyMember                      |
| - id: UUID (Primary Key)                               |
| - familyId: UUID (Foreign Key -> FamilyWorkspace)      |
| - displayName: String                                  |
| - relationshipToPrimary: SELF | SPOUSE | CHILD | ...   |
| - birthDate: Long?                                     |
| - avatarUrl: String?                                   |
| - dietaryPreferences: List<String>                     |
| - allergies: List<String>                              |
| - isRestrictedProfile: Boolean                         |
| - createdAt: Long                                      |
| - updatedAt: Long                                      |
+--------------------------------------------------------+
                           ^
                           | 0..* Supervised by Guardians
+--------------------------------------------------------+
|                  GuardianRelationship                  |
| - id: UUID                                             |
| - familyId: UUID (FK)                                  |
| - guardianMemberId: UUID (FK -> FamilyMember)          |
| - minorMemberId: UUID (FK -> FamilyMember)             |
| - relationshipType: PARENT | LEGAL_GUARDIAN            |
| - isEmergencyContact: Boolean                          |
| - canManageHealthRecords: Boolean                      |
| - createdAt: Long                                      |
+--------------------------------------------------------+
```

### Architectural Enforcement Rules:
1. **No Password Storage**: Zero password hashes or plain secrets are stored in the local SQLite database. Firebase Auth handles all credential verification.
2. **Biometrics as Device Protection**: Local biometric unlock (Fingerprint/Face) is strictly an on-device gate for app access convenience and does not replace server-authoritative Firebase token refresh.
3. **Child Profiles Without Accounts**: Minor children have a `FamilyMember` profile and a `GuardianRelationship` entity. A child profile is NOT an authenticated account. Guardian-managed devices provide pin-protected access to view assigned chores and achievements.
4. **Server-Side Authorization**: Permissions are validated on Firebase Cloud Functions / Firestore security rules. Client UI visibility is purely ergonomics, not a security boundary.

---

## 5. Dependency Injection Topology

Using standard Hilt scoping:
- `@Singleton`: Room Database, DataStore, Network Client, WorkManager Scheduler, Encryption Engine.
- `@ViewModelScoped`: Repositories, Domain Use Cases, Navigation Coordinators.
- `@ActivityRetainedScoped`: Workspace Context Manager (keeps active `currentFamilyId` stable across rotations).

---

## 6. Backend Integration & Secure Gemini AI Gateway

### 6.1 Direct SDK vs Proxy Strategy
Direct client-side Gemini API calls are strictly forbidden in production because:
1. Android APK decompilation can expose embedded API keys.
2. Direct API keys prevent centralized household rate-limiting and quota enforcement.
3. Client-side prompts cannot safely sanitize family privacy data before transit.

### 6.2 FamilyOS AI Gateway Architecture:
```
[Android Jetpack Compose] 
       | (HTTPS Bearer Token Auth)
       v
[Cloud Run / Firebase Cloud Functions: /api/ai/*]
       | 
       +---> 1. Validate Firebase JWT & verify Family Membership
       +---> 2. Apply rate-limiting & parental consent check
       +---> 3. Strip PII (names replaced with tokenized placeholders: Member_A, Member_B)
       +---> 4. Call @google/genai SDK (Gemini 2.5 Flash / Pro)
       +---> 5. Enforce structured JSON Schema response
       v
[Android Client Receives Structured Draft]
       v
[Human Approval Screen (User edits, approves or discards)]
       v
[Committed to Local Room DB & Sync Queue]
```
