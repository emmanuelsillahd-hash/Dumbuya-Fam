# FAMILYOS — MASTER FEATURE REGISTER
**Version**: 2.1.0 (Stage 2.1 Verification & Hardening Baseline)  
**Implementation Status Key**: `NOT STARTED` | `IN PROGRESS` | `IMPLEMENTED`  
**Verification Status Key**: `NOT VERIFIED` | `VERIFIED_SCHEMA` | `VERIFIED_UNIT_TEST` | `UNVERIFIED_CI_DEVICE` (Awaiting Android SDK / CI Runner)

---

## Module 1 — Authentication & Account Management

| Feature ID | Feature Name | Stage | Implementation Status | Verification Status | Notes / Limitations |
|---|---|:---:|:---:|:---:|---|
| `AUTH-01` | Account Registration (Email/Password) | Stage 1 | IMPLEMENTED (Adapter) | VERIFIED_SCHEMA | FirebaseAuthRepository contract created; pending live Firebase API keys. |
| `AUTH-02` | Email Verification Flow | Stage 1 | NOT STARTED | NOT VERIFIED | Scoped to Stage 1 hardening / Stage 5 release. |
| `AUTH-03` | Google One-Tap & Sign-In | Stage 1 | IMPLEMENTED (Adapter) | VERIFIED_SCHEMA | Play Services One-Tap interface defined. |
| `AUTH-04` | Password Recovery & Reset | Stage 1 | NOT STARTED | NOT VERIFIED | Handled via Firebase Auth console/service. |
| `AUTH-05` | Biometric App Unlock (BiometricPrompt) | Stage 1 | NOT STARTED | NOT VERIFIED | Requires physical device Keystore biometric sensor. |
| `AUTH-06` | Device & Active Session Management | Stage 1 | NOT STARTED | NOT VERIFIED | Scoped to Stage 5 hardening. |
| `AUTH-07` | GDPR Account & Data Deletion | Stage 1 | NOT STARTED | NOT VERIFIED | Requires cloud backend cascade purge function. |

---

## Module 2 — The Family & Governance

| Feature ID | Feature Name | Stage | Implementation Status | Verification Status | Notes / Limitations |
|---|---|:---:|:---:|:---:|---|
| `FAM-01` | Multi-Family Workspace Creation | Stage 1 | IMPLEMENTED | VERIFIED_UNIT_TEST | Verified via `RbacPermissionTest` and `FamilyWorkspaceDao`. |
| `FAM-02` | Member Profile Management (Independent of Account) | Stage 1 | IMPLEMENTED | VERIFIED_UNIT_TEST | Verified via `Stage2FamilyTreeTest` (unauthenticated child accounts). |
| `FAM-03` | Secure Invitation Tokens & Deep Links | Stage 1 | IMPLEMENTED | VERIFIED_SCHEMA | Entity `family_invitations` and repository methods established. |
| `FAM-04` | Family Roles & Access Control (RBAC) | Stage 1 | IMPLEMENTED | VERIFIED_UNIT_TEST | Verified via `RbacPermissionTest` (Owner, Admin, Member, Child, Guest). |
| `FAM-05` | Family Tree & Relationship Map | Stage 2 | IMPLEMENTED | VERIFIED_UNIT_TEST | DAG cycle detection and duplicate checks verified in `Stage2FamilyTreeTest.kt`. |
| `FAM-06` | Family Governance & Constitution Document | Stage 2 | IN PROGRESS | NOT VERIFIED | Schema defined; PDF export engine deferred to Stage 4. |
| `FAM-07` | Milestones & Household Calendar Foundation | Stage 2 | IMPLEMENTED | VERIFIED_UNIT_TEST | Date ordering and category filtering verified in `Stage2CalendarTest.kt`. |

---

## Module 3 — Goals, Projects, Tasks & Checklists

| Feature ID | Feature Name | Stage | Implementation Status | Verification Status | Notes / Limitations |
|---|---|:---:|:---:|:---:|---|
| `TASK-01` | 4-Tier Hierarchy Engine (Goal -> Project -> Task -> Checklist) | Stage 2 | IMPLEMENTED | VERIFIED_UNIT_TEST | Verified in `Stage2GoalsHierarchyTest.kt`. Foreign keys with `SET NULL` on project/task. |
| `TASK-02` | Recurring Task Scheduler (RRULE Engine) | Stage 2 | IN PROGRESS | NOT VERIFIED | Interval logic in domain; full RFC-5545 parser deferred to Stage 4 WorkManager. |
| `TASK-03` | Task Priority & Multi-Member Assignment | Stage 2 | IMPLEMENTED | VERIFIED_UNIT_TEST | Verified member reassignment and Priority levels. |
| `TASK-04` | AI-Assisted Goal Breakdown (With Human Approval Gate) | Stage 4 | NOT STARTED | NOT VERIFIED | Dependent on Stage 4 Gemini API Gateway. |
| `TASK-05` | Subtasks & Checklists Completion Rollup | Stage 2 | IMPLEMENTED | VERIFIED_UNIT_TEST | Progress percentage rollup and completion toggle verified. |

---

## Module 4 — The Household Management

| Feature ID | Feature Name | Stage | Implementation Status | Verification Status | Notes / Limitations |
|---|---|:---:|:---:|:---:|---|
| `HSE-01` | 7-Day Weekly Meal Planner (Breakfast/Lunch/Dinner/Snacks) | Stage 2 | IMPLEMENTED | VERIFIED_UNIT_TEST | Verified slot types and plan modification in `Stage2MealsAndRecipesTest.kt`. |
| `HSE-02` | Professional Recipe Manager (Scaling & Servings) | Stage 2 | IMPLEMENTED | VERIFIED_UNIT_TEST | Verified scaling multiplier (0.5x, 2x, 3x) without unit fidelity loss. |
| `HSE-03` | Printable Recipe Cards with Secure QR Routing | Stage 2 | IMPLEMENTED | VERIFIED_UNIT_TEST | Card layout designed; offline deep-link URI format verified. |
| `HSE-04` | Food Pantry & Fridge Inventory with Expiry Alerts | Stage 2 | IN PROGRESS | VERIFIED_SCHEMA | Database schema complete; camera barcode scanner deferred to Stage 4. |
| `HSE-05` | Automatic Grocery List Generation from Meal Plan | Stage 2 | IMPLEMENTED | VERIFIED_UNIT_TEST | Deduplication and aggregation verified in `Stage2MealsAndRecipesTest.kt`. |
| `HSE-06` | Chores & Responsibility Engine with Reward Points | Stage 2 | IMPLEMENTED | VERIFIED_UNIT_TEST | Recurrence progression and positive history logs verified in `Stage2ChoresTest.kt`. |
| `HSE-07` | Wardrobe & Weekly Outfit Planner | Stage 2 | NOT STARTED | NOT VERIFIED | Scoped to Stage 4. |
| `HSE-08` | Home Asset & Maintenance Tracker with Warranties | Stage 2 | IMPLEMENTED | VERIFIED_UNIT_TEST | Zero-float 64-bit integer cents and warranty alerts verified in `Stage2HomeAssetsTest.kt`. |

---

## Module 5 — Family Financial Management (Exact Integer Cents)

| Feature ID | Feature Name | Stage | Status | Dependencies | Entities Affected |
|---|---|:---:|:---:|---|---|
| `FIN-01` | Integer-Cents Financial Accounts Management | Stage 3 | IMPLEMENTED | Room DB | `financial_accounts` |
| `FIN-02` | Income Tracking (Recurring & Irregular) | Stage 3 | IMPLEMENTED | `FIN-01` | `financial_transactions` |
| `FIN-03` | Expense Management (Fixed, Variable, One-Time) | Stage 3 | IMPLEMENTED | `FIN-01` | `financial_transactions` |
| `FIN-04` | Cash-Flow Allocator (Available Planned Cash Flow) | Stage 3 | IMPLEMENTED | `FIN-02`, `FIN-03` | `CashFlowPlan`, `FinanceDao` |
| `FIN-05` | Multiple Savings Goals & Milestone Cards | Stage 3 | IMPLEMENTED | `FIN-01` | `savings_goals` |
| `FIN-06` | Category Envelope Budgets & Threshold Alerts | Stage 3 | IMPLEMENTED | `FIN-03` | `envelope_budgets` |
| `FIN-07` | Net Worth Calculator (Assets vs Liabilities History) | Stage 3 | IMPLEMENTED | `FIN-01` | `NetWorthSummary` |
| `FIN-08` | Internal Transfers & Audit Reversals | Stage 3 | IMPLEMENTED | `FIN-01`, `FIN-03` | `financial_transactions` |

---

## Modules 6-12 — Wellbeing, Parenting, Safety & Investments

| Feature ID | Feature Name | Stage | Status | Dependencies | Entities Affected |
|---|---|:---:|:---:|---|---|
| `SPR-01` | Private & Shared Spiritual Reflections & Traditions | Stage 4 | NOT STARTED | `FAM-02` | `spiritual_entries` |
| `DEV-01` | Personal & Family Skills & Habit Planner | Stage 4 | NOT STARTED | `TASK-01` | `personal_development_plans` |
| `CPL-01` | Couples Pre-Child & Relationship Expectation Check-Ins | Stage 4 | NOT STARTED | `FAM-04` | `couples_topics` |
| `PAR-01` | Child Development Milestones & School Routine Hub | Stage 4 | NOT STARTED | `FAM-02`, Child Privacy | `child_profiles` |
| `HLT-01` | Health Profiles, Allergies & Medication Reminders | Stage 3 | IMPLEMENTED | Privacy Engine | `wellbeing_profiles`, `health_medications` |
| `SAF-01` | Family Emergency Directory & Disaster Preparedness | Stage 3 | IMPLEMENTED | Offline-First Engine | `emergency_contacts`, `emergency_plans` |
| `INV-01` | Investment Portfolio Allocation & Cost Basis Engine | Stage 4 | NOT STARTED | `FIN-01` | `investment_holdings` |

---

## Core Systems & Commercial

| Feature ID | Feature Name | Stage | Status | Dependencies | Entities Affected |
|---|---|:---:|:---:|---|---|
| `SYS-01` | Offline-First Sync Queue & Conflict Resolution | Stage 1 | IMPLEMENTED | Room DB, WorkManager | `sync_queue` |
| `SYS-02` | Unified Global Calendar Engine | Stage 2 | IMPLEMENTED | Modules 2, 3, 4, 10, 11 | `calendar_events`, Multi-domain aggregator |
| `SYS-03` | FTS5 Global Search Engine | Stage 4 | NOT STARTED | Room SQLite FTS5 | Search virtual tables |
| `SYS-04` | Google Play Billing Entitlement Engine | Stage 4 | NOT STARTED | Play Billing Client | `user_entitlements` |
