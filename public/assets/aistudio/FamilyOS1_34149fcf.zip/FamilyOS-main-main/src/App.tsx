import React, { useState } from 'react';
import {
  Shield,
  Database,
  Layers,
  Sparkles,
  Smartphone,
  CheckCircle2,
  Lock,
  WifiOff,
  DollarSign,
  Users,
  Compass,
  FileText,
  AlertTriangle,
  Heart,
  Calendar,
  BookOpen,
  FolderTree,
  ChevronRight,
  TrendingUp,
  Cpu,
  RefreshCw,
  ExternalLink,
  Award
} from 'lucide-react';

// Brand Color Palette Constants
const BRAND = {
  primary: '#173D35',
  ivory: '#F7F4EC',
  sage: '#A8BDAA',
  secondarySage: '#6B8A6E',
  gold: '#C39A60',
  lightGold: '#E7D1AA',
  textDark: '#11231E',
  textMuted: '#4F635D',
  cardBg: '#FFFFFF',
  border: '#E2DCD0',
};

// Architecture Data Definitions
const MODULES = [
  { id: 1, name: 'Authentication & Accounts', code: 'AUTH', desc: 'Decoupled user accounts vs family member profiles, biometrics, multi-device management', icon: Lock },
  { id: 2, name: 'The Family & Governance', code: 'FAM', desc: 'Workspaces, family tree, constitution, anniversaries, roles & permissions', icon: Users },
  { id: 3, name: 'Goals, Projects & Tasks', code: 'TASK', desc: '4-tier hierarchy: Goal -> Project -> Task -> Checklist with AI approval gates', icon: FolderTree },
  { id: 4, name: 'The Household', code: 'HSE', desc: '7-day meal planner, recipe manager with printable QR cards, inventory, chores, wardrobe, home assets', icon: Compass },
  { id: 5, name: 'Financial Management', code: 'FIN', desc: 'Exact integer-cents calculations, cash-flow allocator, budgets, net worth', icon: DollarSign },
  { id: 6, name: 'Spiritual Growth', code: 'SPR', desc: 'Private & shared family reflection journals, reading plans, sacred milestones', icon: BookOpen },
  { id: 7, name: 'Personal Development', code: 'DEV', desc: 'Habit tracking, life skills inventory, shared family learning curricula', icon: TrendingUp },
  { id: 8, name: 'Couples Preparation', code: 'CPL', desc: 'Constructive pre-child alignments, shared expectations, communication health', icon: Heart },
  { id: 9, name: 'Parenting & Child Dev', code: 'PAR', desc: 'Strict COPPA privacy, milestone logs, school routines, positive reinforcement', icon: Award },
  { id: 10, name: 'Health & Fitness', code: 'HLT', desc: 'Private medication alerts, health doc vault, hydration & family wellness', icon: Shield },
  { id: 11, name: 'Family Safety & Emergency', code: 'SAF', desc: 'Offline crisis directory, smoke/CO alarm maintenance, evacuation plans', icon: AlertTriangle },
  { id: 12, name: 'Family Investments', code: 'INV', desc: 'Cost-basis vs market valuation, asset allocation, scenario planning', icon: Layers },
];

const DATABASE_TABLES = [
  {
    name: 'family_workspaces',
    purpose: 'Root household container for multi-family workspace isolation',
    columns: ['id (UUID)', 'name', 'currency_code', 'owner_user_id', 'version', 'sync_status', 'is_deleted'],
    keys: 'PK: id | Index: owner_user_id',
    constraint: 'Strict multi-tenant workspace partition'
  },
  {
    name: 'family_members',
    purpose: 'Member profiles (can exist WITHOUT login account for children/dependents)',
    columns: ['id (UUID)', 'family_id (FK)', 'linked_account_id (Nullable)', 'display_name', 'role', 'dietary_preferences', 'points_balance', 'is_restricted_profile'],
    keys: 'PK: id | FK: family_id -> family_workspaces | Index: linked_account_id',
    constraint: 'Decoupled from Auth. Child accounts have null linked_account_id'
  },
  {
    name: 'financial_accounts',
    purpose: 'Household checking, savings, investment, and debt tracking',
    columns: ['id (UUID)', 'family_id (FK)', 'name', 'type', 'current_balance_cents (Long)', 'is_liability', 'currency'],
    keys: 'PK: id | FK: family_id',
    constraint: 'ZERO floating point. Balance stored as 64-bit integer cents'
  },
  {
    name: 'income_records',
    purpose: 'Income streams with recurrence rules and allocation tags',
    columns: ['id (UUID)', 'family_id (FK)', 'account_id (FK)', 'amount_cents (Long)', 'category', 'received_date'],
    keys: 'PK: id | FK: family_id, account_id',
    constraint: 'Monetary Long cents. Feeds into Available Before Savings formula'
  },
  {
    name: 'expense_records',
    purpose: 'Fixed, variable, and one-off household expense transactions',
    columns: ['id (UUID)', 'family_id (FK)', 'account_id (FK)', 'amount_cents (Long)', 'expense_type', 'transaction_date'],
    keys: 'PK: id | FK: family_id, account_id',
    constraint: 'Monetary Long cents. Never silently overwritten in sync'
  },
  {
    name: 'goals',
    purpose: 'High-level family and individual aspirations (Top of 4-tier hierarchy)',
    columns: ['id (UUID)', 'family_id (FK)', 'title', 'category', 'owner_member_id', 'target_date', 'status', 'is_ai_assisted'],
    keys: 'PK: id | FK: family_id',
    constraint: 'Parent container for Projects'
  },
  {
    name: 'projects',
    purpose: 'Operational initiatives with budgets and timelines (Tier 2)',
    columns: ['id (UUID)', 'family_id (FK)', 'goal_id (FK)', 'name', 'budget_cents (Long)', 'lead_member_id'],
    keys: 'PK: id | FK: family_id, goal_id',
    constraint: 'Budget stored in Long integer cents'
  },
  {
    name: 'tasks',
    purpose: 'Actionable items with recurring RRULE and priorities (Tier 3)',
    columns: ['id (UUID)', 'family_id (FK)', 'project_id (FK)', 'title', 'priority', 'due_date', 'is_completed', 'recurrence_rule'],
    keys: 'PK: id | FK: family_id, project_id',
    constraint: 'Event-based merge during sync conflict'
  },
  {
    name: 'task_checklists',
    purpose: 'Sub-lists and itemized checklists inside tasks (Tier 4)',
    columns: ['id (UUID)', 'task_id (FK)', 'title', 'position'],
    keys: 'PK: id | FK: task_id (Cascade Delete)',
    constraint: 'Ordered checklist sequence'
  },
  {
    name: 'recipes',
    purpose: 'Household culinary knowledge base with QR code linking',
    columns: ['id (UUID)', 'family_id (FK)', 'title', 'prep_time_minutes', 'cook_time_minutes', 'servings', 'estimated_cost_cents (Long)', 'family_rating'],
    keys: 'PK: id | FK: family_id',
    constraint: 'Supports printable QR cards & auto-scaled servings'
  },
  {
    name: 'meal_plans',
    purpose: '7-day weekly schedule for breakfast, lunch, dinner, and snacks',
    columns: ['id (UUID)', 'family_id (FK)', 'plan_date', 'meal_type', 'recipe_id (FK)', 'servings'],
    keys: 'PK: id | FK: family_id, recipe_id',
    constraint: 'Direct feed into automatic grocery list generator'
  },
  {
    name: 'sync_queue',
    purpose: 'Local transactional queue for offline write operations',
    columns: ['queue_id (Autoincrement)', 'entity_table', 'entity_id', 'operation (INSERT/UPDATE/DELETE)', 'payload_json', 'attempt_count'],
    keys: 'PK: queue_id | Index: entity_table, entity_id',
    constraint: 'FIFO execution with exponential backoff & idempotency key'
  }
];

const RBAC_ROLES = [
  { role: 'OWNER', badge: 'Primary Household Head', permissions: ['All Settings & Billing', 'Invite & Remove Members', 'Full Financial Access', 'All Modules Full Access', 'Export & Delete Data'] },
  { role: 'ADMIN', badge: 'Co-Parent / Spouse', permissions: ['Manage Members & Invites', 'Full Financial Access', 'All Modules Full Access', 'Approve AI Suggestions', 'Verify Chores'] },
  { role: 'MEMBER', badge: 'Teenager / Adult Dependent', permissions: ['View Assigned Tasks & Chores', 'View Household Calendar & Meals', 'Own Private Journals', 'Record Personal Expenses', 'View-only Shared Goals'] },
  { role: 'CHILD', badge: 'Minor Child Profile', permissions: ['View & Complete Chores', 'Earn & Redeem Reward Points', 'View Meal Plan', 'Access Emergency Contacts', 'Restricted from Finances & Settings'] },
  { role: 'GUEST', badge: 'Babysitter / Extended Family', permissions: ['View Today\'s Meals & Chores', 'Emergency Contacts Access', 'Restricted from all private data'] }
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'stage3' | 'stage2' | 'overview' | 'database' | 'rbac' | 'finance' | 'sync' | 'tests' | 'docs'>('stage3');
  const [stage2SubTab, setStage2SubTab] = useState<'tree' | 'goals' | 'meals' | 'chores' | 'assets' | 'calendar'>('tree');
  const [stage3SubTab, setStage3SubTab] = useState<'finance' | 'wellbeing' | 'emergency'>('finance');
  const [selectedRole, setSelectedRole] = useState('OWNER');

  // Interactive Stage 2 State Simulators
  const [servingScaler, setServingScaler] = useState<number>(4);
  const [taskCheckstates, setTaskCheckstates] = useState<Record<string, boolean>>({
    'check_1': true,
    'check_2': true,
    'check_3': false,
    'check_4': false
  });
  const [completedChores, setCompletedChores] = useState<Record<string, boolean>>({
    'c1': true,
    'c2': false,
    'c3': false
  });

  // Interactive Cash-Flow Calculator Simulator (proves Long integer cents formula)
  const [incomeInput, setIncomeInput] = useState<number>(850000); // $8,500.00
  const [recurringExpInput, setRecurringExpInput] = useState<number>(320000); // $3,200.00
  const [variableExpInput, setVariableExpInput] = useState<number>(150000); // $1,500.00
  const [commitmentsInput, setCommitmentsInput] = useState<number>(80000); // $800.00

  // Exact Integer Calculations (Zero floating point)
  const availableBeforeSavingsCents = incomeInput - recurringExpInput - variableExpInput;
  const availableForAllocationCents = availableBeforeSavingsCents - commitmentsInput;

  const formatCents = (cents: number) => {
    const isNegative = cents < 0;
    const abs = Math.abs(cents);
    const dollars = Math.floor(abs / 100);
    const remainder = abs % 100;
    return `${isNegative ? '-' : ''}$${dollars.toLocaleString()}.${remainder.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen flex flex-col font-sans" style={{ backgroundColor: BRAND.ivory, color: BRAND.textDark }}>
      {/* Top Heritage Brand Bar */}
      <header className="border-b px-6 py-4 flex flex-wrap items-center justify-between shadow-xs" style={{ backgroundColor: BRAND.primary, borderColor: '#0E2822' }}>
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center font-serif text-xl font-bold shadow-sm" style={{ backgroundColor: BRAND.gold, color: '#173D35' }}>
            F
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-xl font-bold text-white tracking-wide font-serif">FamilyOS</h1>
              <span className="text-xs px-2.5 py-0.5 rounded-full font-medium" style={{ backgroundColor: BRAND.gold, color: '#173D35' }}>
                Stage 3 Active
              </span>
            </div>
            <p className="text-xs text-emerald-100/80">Finance & Wellbeing Management System</p>
          </div>
        </div>

        {/* Global Stage Status Capsule */}
        <div className="flex items-center space-x-4 mt-2 sm:mt-0">
          <div className="bg-emerald-950/70 border border-emerald-800/80 rounded-xl px-4 py-2 flex items-center space-x-3 text-xs">
            <span className="flex h-2.5 w-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
            <div>
              <p className="text-emerald-300 font-medium">Stage 3 Active: Finance & Wellbeing</p>
              <p className="text-emerald-400/80 text-[11px]">Room v3 (39 Entities) • Cash Flow Engine • Privacy-First Health & Safety</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Navigation Bar */}
      <nav className="border-b px-6 py-2 flex space-x-1 sm:space-x-2 overflow-x-auto text-sm font-medium" style={{ backgroundColor: '#FFFFFF', borderColor: BRAND.border }}>
        {[
          { id: 'stage3', label: 'Stage 3: Finance & Wellbeing', icon: DollarSign },
          { id: 'stage2', label: 'Stage 2: Family & Household', icon: Compass },
          { id: 'overview', label: 'Architecture Overview', icon: Layers },
          { id: 'database', label: 'Database & Schemas', icon: Database },
          { id: 'rbac', label: 'Security & RBAC Matrix', icon: Shield },
          { id: 'finance', label: 'Exact Cents Finance Engine', icon: DollarSign },
          { id: 'sync', label: 'Offline Sync State Machine', icon: WifiOff },
          { id: 'tests', label: '17 Verification Scenarios', icon: CheckCircle2 },
          { id: 'docs', label: 'Project Documents (10)', icon: FileText },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center space-x-2 px-3.5 py-2 rounded-xl transition-all whitespace-nowrap text-xs sm:text-sm ${
                isActive
                  ? 'font-semibold shadow-xs'
                  : 'hover:bg-stone-100 text-stone-600'
              }`}
              style={{
                backgroundColor: isActive ? BRAND.primary : 'transparent',
                color: isActive ? '#FFFFFF' : undefined,
              }}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Main View Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
        
        {/* VIEW: STAGE 3 — FINANCE & WELLBEING MODULE EXPLORER */}
        {activeTab === 'stage3' && (
          <div className="space-y-6">
            {/* Stage 3 Module Banner */}
            <div className="rounded-3xl p-6 sm:p-8 border shadow-xs relative overflow-hidden bg-white" style={{ borderColor: BRAND.border }}>
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <span className="text-xs uppercase tracking-widest font-bold px-3 py-1 rounded-full" style={{ backgroundColor: BRAND.gold, color: '#173D35' }}>
                    Stage 3 Master Implementation
                  </span>
                  <h2 className="text-2xl sm:text-3xl font-serif font-bold text-stone-900 mt-2">
                    Finance & Wellbeing Management System
                  </h2>
                  <p className="text-sm text-stone-600 mt-1 max-w-2xl">
                    Exact 64-bit integer cents accounting, household cash-flow allocation, envelope budgets, privacy-first family wellbeing records, and offline crisis readiness running on Room SQLite Database v3.
                  </p>
                </div>

                <div className="flex flex-wrap gap-2">
                  <span className="text-xs font-mono font-bold px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-900 border border-emerald-200">
                    Room v3: 39 Tables
                  </span>
                  <span className="text-xs font-mono font-bold px-3 py-1.5 rounded-xl bg-amber-50 text-amber-900 border border-amber-200">
                    MIGRATION_2_3: Active
                  </span>
                  <span className="text-xs font-mono font-bold px-3 py-1.5 rounded-xl bg-purple-50 text-purple-900 border border-purple-200">
                    Zero Float Drift
                  </span>
                </div>
              </div>

              {/* Stage 3 Sub-Module Switcher */}
              <div className="flex flex-wrap gap-1.5 mt-6 border-t pt-4" style={{ borderColor: BRAND.border }}>
                {[
                  { id: 'finance', label: '1. Cash Flow & Financial Ledger', icon: DollarSign },
                  { id: 'wellbeing', label: '2. Health & Wellbeing Profiles', icon: Heart },
                  { id: 'emergency', label: '3. Household Emergency Preparedness', icon: AlertTriangle },
                ].map((sub) => {
                  const Icon = sub.icon;
                  const isCurrent = stage3SubTab === sub.id;
                  return (
                    <button
                      key={sub.id}
                      onClick={() => setStage3SubTab(sub.id as any)}
                      className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                        isCurrent
                          ? 'shadow-xs text-white'
                          : 'bg-stone-50 text-stone-600 hover:bg-stone-100 border border-stone-200'
                      }`}
                      style={{
                        backgroundColor: isCurrent ? BRAND.primary : undefined,
                      }}
                    >
                      <Icon className="w-4 h-4" />
                      <span>{sub.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* SUB-VIEW 1: FINANCE & LEDGER */}
            {stage3SubTab === 'finance' && (
              <div className="space-y-6">
                {/* Net Worth & Cash-Flow Planner Overview Grid */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Net Worth Card */}
                  <div className="border rounded-3xl p-6 bg-white shadow-xs" style={{ borderColor: BRAND.border }}>
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-xs uppercase font-bold tracking-wider text-stone-500">Household Net Worth</span>
                      <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-900">AUDITED</span>
                    </div>
                    <div className="text-3xl font-serif font-bold text-stone-900 mb-2">
                      {formatCents(12540000)}
                    </div>
                    <p className="text-xs text-stone-500 mb-4">Liquid Assets − Total Household Debt</p>
                    <div className="space-y-2 pt-2 border-t border-stone-100 text-xs">
                      <div className="flex justify-between">
                        <span className="text-stone-600">Total Liquid & Invested Assets:</span>
                        <span className="font-mono font-bold text-emerald-800">{formatCents(14840000)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-stone-600">Total Household Liabilities:</span>
                        <span className="font-mono font-bold text-rose-700">{formatCents(2300000)}</span>
                      </div>
                    </div>
                  </div>

                  {/* Cash-Flow Allocator Interactive Panel */}
                  <div className="lg:col-span-2 border rounded-3xl p-6 bg-white shadow-xs" style={{ borderColor: BRAND.border }}>
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-serif font-bold text-lg text-stone-900">Monthly Cash-Flow Planning Formula</h3>
                      <span className="text-xs font-mono font-semibold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
                        Exact Long Integer Cents
                      </span>
                    </div>
                    <p className="text-xs text-stone-500 mb-4">
                      Expected Income − Fixed Recurring Expenses − Planned Variable = Available Planned Cash Flow
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">
                      <div className="p-3 rounded-2xl bg-stone-50 border border-stone-200">
                        <span className="text-[11px] text-stone-500 block">Expected Monthly Income</span>
                        <span className="text-base font-mono font-bold text-emerald-900">{formatCents(incomeInput)}</span>
                      </div>
                      <div className="p-3 rounded-2xl bg-stone-50 border border-stone-200">
                        <span className="text-[11px] text-stone-500 block">Fixed Recurring Expenses</span>
                        <span className="text-base font-mono font-bold text-rose-800">-{formatCents(recurringExpInput)}</span>
                      </div>
                      <div className="p-3 rounded-2xl bg-stone-50 border border-stone-200">
                        <span className="text-[11px] text-stone-500 block">Other Planned Expenses</span>
                        <span className="text-base font-mono font-bold text-amber-800">-{formatCents(variableExpInput)}</span>
                      </div>
                    </div>

                    <div className="p-4 rounded-2xl bg-emerald-50/60 border border-emerald-200 flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <span className="text-xs font-bold text-emerald-900 block">= Available Planned Cash Flow</span>
                        <span className="text-xs text-emerald-700">Ready for household priority allocations</span>
                      </div>
                      <div className="text-xl font-mono font-bold text-emerald-900">
                        {formatCents(availableBeforeSavingsCents)}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Envelope Budgets & Ledger Grid */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Category Envelope Budgets */}
                  <div className="border rounded-3xl p-6 bg-white shadow-xs" style={{ borderColor: BRAND.border }}>
                    <h3 className="font-serif font-bold text-lg text-stone-900 mb-1">Envelope Budgets & Alert Thresholds</h3>
                    <p className="text-xs text-stone-500 mb-4">Real-time spending limit tracking with 85% alert barriers</p>

                    <div className="space-y-4">
                      {[
                        { category: 'Groceries & Household Food', allocated: 120000, spent: 84500, alert: 85 },
                        { category: 'Housing & Utilities', allocated: 240000, spent: 235000, alert: 85 },
                        { category: 'Transportation & Vehicle Gas', allocated: 45000, spent: 31000, alert: 85 },
                        { category: 'Dining Out & Entertainment', allocated: 35000, spent: 38500, alert: 85 },
                      ].map((b, idx) => {
                        const pct = Math.round((b.spent / b.allocated) * 100);
                        const isOver = b.spent > b.allocated;
                        const isNear = pct >= b.alert && !isOver;
                        return (
                          <div key={idx} className="p-3 rounded-2xl border border-stone-200 bg-stone-50/50">
                            <div className="flex justify-between items-center text-xs mb-1">
                              <span className="font-semibold text-stone-900">{b.category}</span>
                              <span className="font-mono text-stone-600">{formatCents(b.spent)} / {formatCents(b.allocated)} ({pct}%)</span>
                            </div>
                            <div className="w-full h-2 rounded-full bg-stone-200 overflow-hidden mb-1.5">
                              <div
                                className={`h-full rounded-full ${
                                  isOver ? 'bg-rose-600' : isNear ? 'bg-amber-500' : 'bg-emerald-700'
                                }`}
                                style={{ width: `${Math.min(pct, 100)}%` }}
                              />
                            </div>
                            <div className="flex justify-between items-center text-[11px]">
                              <span className={isOver ? 'text-rose-700 font-bold' : 'text-emerald-800'}>
                                {isOver ? `Over budget by ${formatCents(b.spent - b.allocated)}` : `Remaining: ${formatCents(b.allocated - b.spent)}`}
                              </span>
                              {isNear && <span className="text-amber-800 font-bold">Near Alert Threshold ({b.alert}%)</span>}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Transaction Ledger & Reversals */}
                  <div className="border rounded-3xl p-6 bg-white shadow-xs" style={{ borderColor: BRAND.border }}>
                    <div className="flex items-center justify-between mb-1">
                      <h3 className="font-serif font-bold text-lg text-stone-900">Ledger Auditability & Reversals</h3>
                      <span className="text-[11px] font-mono font-semibold text-stone-600">Historical Preservation</span>
                    </div>
                    <p className="text-xs text-stone-500 mb-4">Posted records are never silently erased; corrections use offset reversals</p>

                    <div className="space-y-3">
                      {[
                        { title: 'Organic Valley Food Market', cat: 'GROCERIES', amount: 14250, type: 'EXPENSE', reversal: false },
                        { title: 'Acme Corp Monthly Payroll', cat: 'SALARY', amount: 425000, type: 'INCOME', reversal: false },
                        { title: 'Internal Transfer: Checking → Savings', cat: 'TRANSFER', amount: 100000, type: 'TRANSFER', reversal: false },
                        { title: 'Reversal: Duplicate Utility Bill Offset', cat: 'UTILITIES', amount: 12500, type: 'EXPENSE', reversal: true },
                      ].map((tx, idx) => (
                        <div key={idx} className="flex items-center justify-between p-3 rounded-2xl border border-stone-200 bg-white">
                          <div className="flex items-center space-x-3">
                            <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-bold ${
                              tx.type === 'INCOME' ? 'bg-emerald-100 text-emerald-800' : tx.reversal ? 'bg-sky-100 text-sky-800' : 'bg-rose-100 text-rose-800'
                            }`}>
                              {tx.type === 'INCOME' ? '↓' : tx.reversal ? '↺' : '↑'}
                            </div>
                            <div>
                              <p className="text-xs font-semibold text-stone-900">{tx.title}</p>
                              <p className="text-[11px] text-stone-500">{tx.cat} • {tx.reversal ? 'AUDIT REVERSAL POSTED' : 'Manual Entry'}</p>
                            </div>
                          </div>
                          <span className={`text-xs font-mono font-bold ${
                            tx.type === 'INCOME' ? 'text-emerald-800' : tx.reversal ? 'text-sky-800' : 'text-stone-900'
                          }`}>
                            {tx.type === 'INCOME' ? '+' : '-'}{formatCents(tx.amount)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* SUB-VIEW 2: WELLBEING & HEALTH */}
            {stage3SubTab === 'wellbeing' && (
              <div className="space-y-6">
                {/* Mandatory Medical Legal Notice */}
                <div className="border rounded-2xl p-4 bg-amber-50/60 border-amber-200 flex items-start space-x-3 text-xs text-amber-950">
                  <Shield className="w-5 h-5 text-amber-800 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold block mb-0.5">Mandatory Health Coordination & Privacy Notice</span>
                    <p className="text-amber-900/90 leading-relaxed">
                      Medication reminders and schedules are for personal household coordination only. A logged or scheduled reminder does not represent proof or medical verification that medication was administered or ingested. All records are stored local-first with strict guardian shielding for minor children.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Member Wellbeing Summary */}
                  <div className="border rounded-3xl p-6 bg-white shadow-xs" style={{ borderColor: BRAND.border }}>
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h3 className="font-serif font-bold text-lg text-stone-900">Lucas Henderson (Minor Child)</h3>
                        <p className="text-xs text-stone-500">Guardian Protected Profile • Age 7</p>
                      </div>
                      <span className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-amber-100 text-amber-900">
                        RESTRICTED MINOR
                      </span>
                    </div>

                    <div className="space-y-3 text-xs">
                      <div className="p-3 rounded-xl bg-stone-50 border border-stone-200 flex justify-between">
                        <span className="text-stone-600">Blood Type:</span>
                        <span className="font-bold text-stone-900">A Positive (A+)</span>
                      </div>
                      <div className="p-3 rounded-xl bg-stone-50 border border-stone-200 flex justify-between">
                        <span className="text-stone-600">Primary Physician:</span>
                        <span className="font-bold text-stone-900">Dr. Eleanor Vance, MD (Westfield Pediatrics)</span>
                      </div>
                      <div className="p-3 rounded-xl bg-stone-50 border border-stone-200 flex justify-between">
                        <span className="text-stone-600">Insurance Provider:</span>
                        <span className="font-bold text-stone-900">BlueCross BlueShield • Policy #BC-992817</span>
                      </div>
                    </div>

                    <h4 className="font-serif font-bold text-sm text-stone-900 mt-5 mb-2">Severe Allergies & Protocols</h4>
                    <div className="p-3 rounded-2xl bg-rose-50 border border-rose-200 text-xs">
                      <div className="flex justify-between items-center mb-1">
                        <span className="font-bold text-rose-950">Peanuts & Tree Nuts</span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-rose-700 text-white">SEVERE ANAPHYLACTIC</span>
                      </div>
                      <p className="text-rose-900 mb-1">Reaction: Facial swelling, airway tightness, hives</p>
                      <p className="text-rose-950 font-semibold">Action: Administer EpiPen Jr auto-injector immediately and dial 911</p>
                    </div>
                  </div>

                  {/* Active Medication Coordination */}
                  <div className="border rounded-3xl p-6 bg-white shadow-xs" style={{ borderColor: BRAND.border }}>
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h3 className="font-serif font-bold text-lg text-stone-900">Active Medications & Doses</h3>
                        <p className="text-xs text-stone-500">Scheduled reminders for family caregivers</p>
                      </div>
                      <span className="text-[11px] font-mono font-bold px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-900">
                        2 ACTIVE
                      </span>
                    </div>

                    <div className="space-y-3">
                      <div className="p-4 rounded-2xl border border-stone-200 bg-stone-50/50 text-xs space-y-1">
                        <div className="flex justify-between font-bold text-stone-900">
                          <span>Fluticasone (Flonase Allergy)</span>
                          <span className="font-mono text-emerald-800">07:30 AM Daily</span>
                        </div>
                        <p className="text-stone-600">Dose: 1 spray per nostril (50 mcg)</p>
                        <p className="text-stone-500">Instructions: Administer before school during peak pollen seasons</p>
                      </div>

                      <div className="p-4 rounded-2xl border border-stone-200 bg-stone-50/50 text-xs space-y-1">
                        <div className="flex justify-between font-bold text-stone-900">
                          <span>Epinephrine Auto-Injector (EpiPen Jr)</span>
                          <span className="font-mono text-rose-800">EMERGENCY ONLY</span>
                        </div>
                        <p className="text-stone-600">Dose: 0.15 mg auto-injector</p>
                        <p className="text-stone-500">Instructions: Located in insulated pocket of school backpack</p>
                      </div>

                      <div className="p-4 rounded-2xl border border-stone-200 bg-white text-xs space-y-1">
                        <div className="flex justify-between font-bold text-stone-900">
                          <span>Upcoming Healthcare Appointment</span>
                          <span className="font-mono text-stone-700">Nov 18, 2026</span>
                        </div>
                        <p className="text-stone-600">Dr. Eleanor Vance • Annual Pediatric Wellness Checkup</p>
                        <p className="text-stone-500">Westfield Medical Plaza Suite 204 • 10:30 AM</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* SUB-VIEW 3: EMERGENCY PREPAREDNESS */}
            {stage3SubTab === 'emergency' && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Offline Crisis Directory */}
                  <div className="border rounded-3xl p-6 bg-white shadow-xs" style={{ borderColor: BRAND.border }}>
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h3 className="font-serif font-bold text-lg text-stone-900">Offline Emergency Directory</h3>
                        <p className="text-xs text-stone-500">Accessible without cellular data or internet connectivity</p>
                      </div>
                      <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-rose-100 text-rose-800">CRISIS READY</span>
                    </div>

                    <div className="space-y-2.5 text-xs">
                      {[
                        { name: 'Sarah Henderson (Mother)', relation: 'Primary Guardian', phone: '(555) 123-4567', primary: true },
                        { name: 'David Henderson (Father)', relation: 'Guardian', phone: '(555) 234-5678', primary: true },
                        { name: 'Grandma Martha', relation: 'Local Emergency Contact', phone: '(555) 345-6789', primary: false },
                        { name: 'National Poison Control Center', relation: '24/7 Hotline', phone: '1-800-222-1222', primary: false },
                      ].map((c, idx) => (
                        <div key={idx} className="flex justify-between items-center p-3 rounded-2xl border border-stone-200 bg-stone-50">
                          <div>
                            <div className="flex items-center space-x-2">
                              <span className="font-bold text-stone-900">{c.name}</span>
                              {c.primary && <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-800 text-white">PRIMARY</span>}
                            </div>
                            <span className="text-stone-500 text-[11px]">{c.relation}</span>
                          </div>
                          <span className="font-mono font-bold text-emerald-900 text-sm">{c.phone}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Meeting Points & Utilities */}
                  <div className="border rounded-3xl p-6 bg-white shadow-xs" style={{ borderColor: BRAND.border }}>
                    <h3 className="font-serif font-bold text-lg text-stone-900 mb-1">Evacuation & Household Meeting Plan</h3>
                    <p className="text-xs text-stone-500 mb-4">Pre-designated family rally points</p>

                    <div className="space-y-3 text-xs">
                      <div className="p-3.5 rounded-2xl bg-emerald-50/50 border border-emerald-200">
                        <span className="font-bold text-emerald-950 block mb-0.5">Primary Rally Point (Immediate Neighborhood)</span>
                        <p className="text-stone-700">Front lawn beneath the large oak tree by sidewalk (Meet here during fire or gas alarm)</p>
                      </div>

                      <div className="p-3.5 rounded-2xl bg-amber-50/50 border border-amber-200">
                        <span className="font-bold text-amber-950 block mb-0.5">Secondary Rally Point (Out of Neighborhood)</span>
                        <p className="text-stone-700">Community Park East Gazebo (Corner of 5th & Pine Ave)</p>
                      </div>

                      <div className="p-3.5 rounded-2xl bg-stone-50 border border-stone-200">
                        <span className="font-bold text-stone-900 block mb-1">Critical Home Utility Shutoffs</span>
                        <div className="space-y-1 text-stone-600 text-[11px]">
                          <p>• <strong>Water Main:</strong> Basement north wall by water meter (Quarter-turn ball valve)</p>
                          <p>• <strong>Natural Gas:</strong> Exterior east wall next to gas meter (Requires shutoff wrench)</p>
                          <p>• <strong>Main Electrical Panel:</strong> Garage west wall (200A main disconnect toggle)</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* VIEW 0: STAGE 2 — FAMILY & HOUSEHOLD MODULE EXPLORER */}
        {activeTab === 'stage2' && (
          <div className="space-y-6">
            {/* Stage 2 Module Banner */}
            <div className="rounded-3xl p-6 sm:p-8 border shadow-xs relative overflow-hidden bg-white" style={{ borderColor: BRAND.border }}>
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <span className="text-xs uppercase tracking-widest font-bold px-3 py-1 rounded-full" style={{ backgroundColor: BRAND.lightGold, color: '#6A4D1B' }}>
                    Stage 2 Master Implementation
                  </span>
                  <h2 className="text-2xl sm:text-3xl font-serif font-bold text-stone-900 mt-2">
                    Family & Household Management System
                  </h2>
                  <p className="text-sm text-stone-600 mt-1 max-w-2xl">
                    6 operational modules running on Room SQLite Database v2 with 24 normalized entities, strict foreign key constraints, exact integer cents, and offline-first reactive flows.
                  </p>
                </div>

                <div className="flex flex-wrap gap-2">
                  <span className="text-xs font-mono font-bold px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-900 border border-emerald-200">
                    Room v2: 24 Tables
                  </span>
                  <span className="text-xs font-mono font-bold px-3 py-1.5 rounded-xl bg-amber-50 text-amber-900 border border-amber-200">
                    MIGRATION_1_2: Active
                  </span>
                </div>
              </div>

              {/* Stage 2 Sub-Module Switcher */}
              <div className="flex flex-wrap gap-1.5 mt-6 border-t pt-4" style={{ borderColor: BRAND.border }}>
                {[
                  { id: 'tree', label: '1. Family Tree & Profiles', icon: Users },
                  { id: 'goals', label: '2. Goals & Task Hierarchy', icon: FolderTree },
                  { id: 'meals', label: '3. Meal Planner & Scaler', icon: Compass },
                  { id: 'chores', label: '4. Chores & Points', icon: Award },
                  { id: 'assets', label: '5. Home Assets & Maintenance', icon: Layers },
                  { id: 'calendar', label: '6. Shared Calendar', icon: Calendar },
                ].map((sub) => {
                  const Icon = sub.icon;
                  const isCurrent = stage2SubTab === sub.id;
                  return (
                    <button
                      key={sub.id}
                      onClick={() => setStage2SubTab(sub.id as any)}
                      className={`flex items-center space-x-2 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                        isCurrent
                          ? 'bg-emerald-900 text-white shadow-xs'
                          : 'bg-stone-100 hover:bg-stone-200 text-stone-700'
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                      <span>{sub.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* SUB-VIEW 1: FAMILY TREE */}
            {stage2SubTab === 'tree' && (
              <div className="border rounded-3xl p-6 bg-white shadow-xs space-y-6" style={{ borderColor: BRAND.border }}>
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h3 className="text-xl font-serif font-bold text-stone-900">Multi-Generational Family Tree</h3>
                    <p className="text-xs text-stone-500">Generational hierarchy with loop-prevention and minor guardian protection</p>
                  </div>
                  <span className="text-xs font-semibold px-2.5 py-1 rounded-md bg-emerald-100 text-emerald-900">
                    Loop Validation: Active
                  </span>
                </div>

                <div className="space-y-6 text-center">
                  {/* Generation I */}
                  <div className="border rounded-2xl p-4 bg-stone-50/60 inline-block w-full text-center">
                    <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider block mb-3">Generation I • Elders & Grandparents</span>
                    <div className="flex justify-center gap-4">
                      <div className="border rounded-xl p-3 bg-white w-48 shadow-2xs">
                        <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-900 font-bold flex items-center justify-center mx-auto mb-1 text-sm">EH</div>
                        <p className="font-bold text-sm text-stone-900">Edward Henderson</p>
                        <p className="text-[11px] text-stone-500">Grandfather • Age 74</p>
                      </div>
                      <div className="border rounded-xl p-3 bg-white w-48 shadow-2xs">
                        <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-900 font-bold flex items-center justify-center mx-auto mb-1 text-sm">MH</div>
                        <p className="font-bold text-sm text-stone-900">Margaret Henderson</p>
                        <p className="text-[11px] text-stone-500">Grandmother • Age 72</p>
                      </div>
                    </div>
                  </div>

                  <div className="w-0.5 h-6 bg-stone-300 mx-auto"></div>

                  {/* Generation II */}
                  <div className="border rounded-2xl p-4 bg-emerald-50/30 border-emerald-200 inline-block w-full text-center">
                    <span className="text-[11px] font-bold text-emerald-900 uppercase tracking-wider block mb-3">Generation II • Primary Household Heads</span>
                    <div className="flex justify-center gap-4">
                      <div className="border border-emerald-600 rounded-xl p-3 bg-white w-52 shadow-2xs">
                        <div className="w-10 h-10 rounded-full bg-emerald-900 text-white font-bold flex items-center justify-center mx-auto mb-1 text-sm">DH</div>
                        <p className="font-bold text-sm text-stone-900">David Henderson</p>
                        <p className="text-[11px] text-stone-500">Household Head • Primary Guardian</p>
                      </div>
                      <div className="border border-emerald-600 rounded-xl p-3 bg-white w-52 shadow-2xs">
                        <div className="w-10 h-10 rounded-full bg-emerald-900 text-white font-bold flex items-center justify-center mx-auto mb-1 text-sm">SH</div>
                        <p className="font-bold text-sm text-stone-900">Sarah Henderson</p>
                        <p className="text-[11px] text-stone-500">Spouse / Co-Head • Primary Guardian</p>
                      </div>
                    </div>
                  </div>

                  <div className="w-0.5 h-6 bg-stone-300 mx-auto"></div>

                  {/* Generation III */}
                  <div className="border rounded-2xl p-4 bg-amber-50/40 border-amber-200 inline-block w-full text-center">
                    <span className="text-[11px] font-bold text-amber-900 uppercase tracking-wider block mb-3">Generation III • Children (Guardian Managed Mode)</span>
                    <div className="flex justify-center gap-4">
                      <div className="border rounded-xl p-3 bg-white w-48 shadow-2xs">
                        <div className="w-10 h-10 rounded-full bg-amber-100 text-amber-900 font-bold flex items-center justify-center mx-auto mb-1 text-sm">LH</div>
                        <p className="font-bold text-sm text-stone-900">Lucas Henderson</p>
                        <p className="text-[11px] text-stone-500">Son • 85 Chores Pts</p>
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 mt-1 inline-block">Minor Profile</span>
                      </div>
                      <div className="border rounded-xl p-3 bg-white w-48 shadow-2xs">
                        <div className="w-10 h-10 rounded-full bg-amber-100 text-amber-900 font-bold flex items-center justify-center mx-auto mb-1 text-sm">MH</div>
                        <p className="font-bold text-sm text-stone-900">Maya Henderson</p>
                        <p className="text-[11px] text-stone-500">Daughter • 60 Chores Pts</p>
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 mt-1 inline-block">Minor Profile</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* SUB-VIEW 2: GOALS & TASKS HIERARCHY */}
            {stage2SubTab === 'goals' && (
              <div className="border rounded-3xl p-6 bg-white shadow-xs space-y-6" style={{ borderColor: BRAND.border }}>
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h3 className="text-xl font-serif font-bold text-stone-900">4-Tier Goals, Projects & Tasks Hierarchy</h3>
                    <p className="text-xs text-stone-500">Interactive: Check off task items below to see dynamic progress calculation</p>
                  </div>
                  {(() => {
                    const total = Object.keys(taskCheckstates).length;
                    const done = Object.values(taskCheckstates).filter(Boolean).length;
                    const pct = Math.round((done / total) * 100);
                    return (
                      <span className="text-xs font-mono font-bold px-3 py-1 rounded-full bg-emerald-100 text-emerald-900">
                        Overall Goal Progress: {pct}%
                      </span>
                    );
                  })()}
                </div>

                <div className="border rounded-2xl p-5 bg-stone-50/60" style={{ borderColor: BRAND.border }}>
                  <div className="flex items-center space-x-2 text-xs font-bold text-emerald-900 uppercase">
                    <FolderTree className="w-4 h-4" />
                    <span>Tier 1: Goal • Household Sustainability</span>
                  </div>
                  <h4 className="text-lg font-serif font-bold text-stone-900 mt-1">Establish Home Solar & Energy Storage</h4>
                  <p className="text-xs text-stone-600">Target: December 2026 • Lead: David • Budget: $15,000.00 exact cents</p>

                  <div className="mt-4 border-l-2 border-emerald-700 pl-4 space-y-4">
                    <div className="border rounded-xl p-3 bg-white">
                      <span className="text-xs font-bold text-stone-800">Tier 2: Project • Contractor Bids & Selection</span>
                      <p className="text-[11px] text-stone-500">3 quotes required before deposit</p>

                      <div className="mt-2 space-y-2">
                        <span className="text-[11px] font-bold text-stone-600 block">Tier 3 & 4: Tasks & Subtasks (Interactive Checklists)</span>
                        {[
                          { id: 'check_1', label: 'Pull 12-month electric utility usage statements' },
                          { id: 'check_2', label: 'Schedule structural roof inspection with licensed engineer' },
                          { id: 'check_3', label: 'Review certified solar installer warranties & inverter specs' },
                          { id: 'check_4', label: 'Confirm local municipal electrical permits & net metering' },
                        ].map((t) => (
                          <label key={t.id} className="flex items-center space-x-2.5 text-xs text-stone-800 cursor-pointer select-none">
                            <input
                              type="checkbox"
                              checked={!!taskCheckstates[t.id]}
                              onChange={(e) => setTaskCheckstates(prev => ({ ...prev, [t.id]: e.target.checked }))}
                              className="w-4 h-4 rounded text-emerald-800 focus:ring-emerald-700"
                            />
                            <span className={taskCheckstates[t.id] ? 'line-through text-stone-400' : 'font-medium'}>
                              {t.label}
                            </span>
                          </label>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* SUB-VIEW 3: MEAL PLANNER & SCALER */}
            {stage2SubTab === 'meals' && (
              <div className="border rounded-3xl p-6 bg-white shadow-xs space-y-6" style={{ borderColor: BRAND.border }}>
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h3 className="text-xl font-serif font-bold text-stone-900">Weekly Meal Planner & Serving Scaler</h3>
                    <p className="text-xs text-stone-500">Live ingredient quantity scaler and printable QR card export</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-semibold text-stone-600">Portions:</span>
                    <button
                      onClick={() => setServingScaler(prev => Math.max(1, prev - 1))}
                      className="w-7 h-7 rounded-lg bg-stone-100 hover:bg-stone-200 font-bold text-sm"
                    >
                      -
                    </button>
                    <span className="text-sm font-bold font-mono px-2 text-emerald-950">{servingScaler}</span>
                    <button
                      onClick={() => setServingScaler(prev => prev + 1)}
                      className="w-7 h-7 rounded-lg bg-stone-100 hover:bg-stone-200 font-bold text-sm"
                    >
                      +
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Recipe Detail with Scaled Ingredients */}
                  <div className="border rounded-2xl p-5 bg-stone-50/60" style={{ borderColor: BRAND.border }}>
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-serif font-bold text-stone-900 text-base">Tuscan Garlic Herb Pasta</h4>
                      <span className="text-xs font-bold text-amber-700">⭐ 5/5 Stars</span>
                    </div>
                    <p className="text-xs text-stone-600 mb-3">Prep: 15m • Cook: 20m • Base Servings: 4</p>
                    
                    <span className="text-[11px] font-bold text-emerald-900 uppercase block mb-1">Dynamically Scaled Ingredients:</span>
                    <div className="space-y-1.5 text-xs">
                      {[
                        { name: 'Penne Pasta', base: 400, unit: 'grams' },
                        { name: 'Garlic Cloves', base: 4, unit: 'cloves' },
                        { name: 'Extra Virgin Olive Oil', base: 3, unit: 'tbsp' },
                        { name: 'Fresh Chopped Basil', base: 0.5, unit: 'cups' },
                      ].map((ing, idx) => {
                        const scaled = (ing.base * (servingScaler / 4)).toFixed(1).replace('.0', '');
                        return (
                          <div key={idx} className="flex justify-between py-1 border-b border-stone-200/60">
                            <span className="text-stone-700">• {ing.name}</span>
                            <span className="font-mono font-bold text-stone-900">{scaled} {ing.unit}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Printable Recipe Card Simulation */}
                  <div className="border rounded-2xl p-5 bg-white shadow-2xs border-stone-300">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-stone-400 block mb-1">Printable Business Card Preview</span>
                    <h5 className="font-serif font-bold text-stone-900 text-base">Tuscan Garlic Herb Pasta</h5>
                    <p className="text-[11px] text-stone-500">The Henderson Kitchen Collection</p>
                    
                    <div className="my-3 p-3 rounded-xl bg-stone-50 border border-stone-200 flex items-center space-x-3">
                      <div className="w-14 h-14 bg-white border rounded-lg flex flex-col items-center justify-center p-1">
                        <div className="w-9 h-9 border border-stone-900 flex items-center justify-center font-mono text-[9px] font-bold">QR</div>
                        <span className="text-[7px] text-stone-500 mt-0.5">Offline-Safe</span>
                      </div>
                      <div className="text-[11px] text-stone-600">
                        <p className="font-semibold text-stone-800">familyos://recipes/r1</p>
                        <p className="text-[10px] text-stone-500">Scans directly on family devices to open recipe details.</p>
                      </div>
                    </div>

                    <button className="w-full text-xs font-semibold py-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800">
                      Export Business-Card PDF
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* SUB-VIEW 4: CHORES & POINTS */}
            {stage2SubTab === 'chores' && (
              <div className="border rounded-3xl p-6 bg-white shadow-xs space-y-6" style={{ borderColor: BRAND.border }}>
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h3 className="text-xl font-serif font-bold text-stone-900">Chores Board & Motivation</h3>
                    <p className="text-xs text-stone-500">Recurring schedule advancement without history loss • Positive recognition</p>
                  </div>
                  <span className="text-xs font-mono font-bold px-3 py-1 rounded-full bg-amber-100 text-amber-900">
                    Household Points: 145 pts
                  </span>
                </div>

                <div className="space-y-3">
                  {[
                    { id: 'c1', title: 'Unload dishwasher & arrange plates', assignee: 'Lucas (85 pts)', zone: 'Kitchen', points: 10, freq: 'Daily' },
                    { id: 'c2', title: 'Vacuum living room area rug', assignee: 'Maya (60 pts)', zone: 'Living Room', points: 15, freq: 'Weekly' },
                    { id: 'c3', title: 'Sort recyclable cardboard into bins', assignee: 'David', zone: 'Outdoors', points: 10, freq: 'Weekly' },
                  ].map((c) => (
                    <div key={c.id} className="border rounded-2xl p-4 bg-stone-50/50 flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <input
                          type="checkbox"
                          checked={!!completedChores[c.id]}
                          onChange={(e) => setCompletedChores(prev => ({ ...prev, [c.id]: e.target.checked }))}
                          className="w-5 h-5 rounded text-emerald-800 focus:ring-emerald-700"
                        />
                        <div>
                          <p className={`text-sm font-bold ${completedChores[c.id] ? 'line-through text-stone-400' : 'text-stone-900'}`}>{c.title}</p>
                          <p className="text-xs text-stone-500">Assigned: {c.assignee} • Zone: {c.zone} • {c.freq}</p>
                        </div>
                      </div>
                      <span className="text-xs font-bold px-2.5 py-1 rounded-md bg-amber-100 text-amber-900">
                        +{c.points} pts
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* SUB-VIEW 5: HOME ASSETS */}
            {stage2SubTab === 'assets' && (
              <div className="border rounded-3xl p-6 bg-white shadow-xs space-y-6" style={{ borderColor: BRAND.border }}>
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h3 className="text-xl font-serif font-bold text-stone-900">Home Assets & Maintenance</h3>
                    <p className="text-xs text-stone-500">Exact integer cents purchase price ($1.00 = 100L) & warranty tracking</p>
                  </div>
                  <span className="text-xs font-semibold px-2.5 py-1 rounded-md bg-emerald-100 text-emerald-900">
                    Long Cents Enforced
                  </span>
                </div>

                <div className="space-y-3">
                  {[
                    { name: 'Bosch 800 Series Dishwasher', category: 'Appliances', priceCents: 129999, warranty: 'Active (Expires 2028)', serviceDue: 'Nov 15' },
                    { name: 'Trane High-Efficiency Heat Pump', category: 'HVAC', priceCents: 840000, warranty: 'Active (Expires 2033)', serviceDue: 'Dec 01' },
                    { name: 'DeWalt 20V Max Tool Set', category: 'Tools', priceCents: 39900, warranty: 'Active (Expires 2027)', serviceDue: 'Routine check' },
                  ].map((a, idx) => (
                    <div key={idx} className="border rounded-2xl p-4 bg-stone-50/50 flex flex-wrap items-center justify-between gap-3">
                      <div>
                        <div className="flex items-center space-x-2">
                          <p className="font-bold text-sm text-stone-900">{a.name}</p>
                          <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-stone-200 text-stone-700">{a.category}</span>
                        </div>
                        <p className="text-xs text-emerald-800 mt-0.5">🛡️ Warranty: {a.warranty} • Maintenance: {a.serviceDue}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-mono font-bold text-sm text-stone-900">{formatCents(Number(a.priceCents))}</p>
                        <p className="text-[10px] font-mono text-stone-400">Stored: {a.priceCents.toString()}L cents</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* SUB-VIEW 6: SHARED CALENDAR */}
            {stage2SubTab === 'calendar' && (
              <div className="border rounded-3xl p-6 bg-white shadow-xs space-y-6" style={{ borderColor: BRAND.border }}>
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h3 className="text-xl font-serif font-bold text-stone-900">Shared Household Calendar Foundation</h3>
                    <p className="text-xs text-stone-500">Aggregates Birthdays, Anniversaries, Goals, Tasks, Meals, Chores & Maintenance</p>
                  </div>
                  <span className="text-xs font-semibold px-2.5 py-1 rounded-md bg-stone-200 text-stone-800">
                    Multi-Category Aggregator
                  </span>
                </div>

                <div className="space-y-3">
                  {[
                    { date: 'Today, Oct 30', title: 'Sarah\'s Birthday Family Celebration', tag: 'BIRTHDAY', color: 'bg-amber-100 text-amber-900' },
                    { date: 'Today, Oct 30', title: 'Tuscan Garlic Herb Pasta Family Dinner', tag: 'MEAL', color: 'bg-emerald-100 text-emerald-900' },
                    { date: 'Tomorrow, Oct 31', title: 'Lucas & Maya Halloween School Parade', tag: 'EVENT', color: 'bg-purple-100 text-purple-900' },
                    { date: 'Saturday, Nov 01', title: 'Attic Heat Pump Filter Cleaning', tag: 'MAINTENANCE', color: 'bg-stone-200 text-stone-800' },
                    { date: 'Wednesday, Nov 05', title: 'Solar Panel Installer Quote Review Deadline', tag: 'GOAL DUE', color: 'bg-sky-100 text-sky-900' },
                  ].map((e, idx) => (
                    <div key={idx} className="border rounded-2xl p-4 bg-stone-50/50 flex items-center justify-between">
                      <div>
                        <span className="text-[11px] font-mono font-bold text-stone-500 block">{e.date}</span>
                        <p className="font-bold text-sm text-stone-900">{e.title}</p>
                      </div>
                      <span className={`text-xs font-bold px-2.5 py-1 rounded-md ${e.color}`}>
                        {e.tag}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* VIEW 1: OVERVIEW */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* Mission Statement Hero Card */}
            <div className="rounded-3xl p-6 sm:p-8 border shadow-xs relative overflow-hidden" style={{ backgroundColor: '#FFFFFF', borderColor: BRAND.border }}>
              <div className="max-w-3xl space-y-4">
                <span className="text-xs uppercase tracking-widest font-bold px-3 py-1 rounded-full" style={{ backgroundColor: BRAND.lightGold, color: '#6A4D1B' }}>
                  Product Vision & Architectural Standard
                </span>
                <h2 className="text-2xl sm:text-3xl font-serif font-bold text-stone-900 leading-tight">
                  Crafted for Household Reliability, Privacy-First Stewardship, and Enduring Quality
                </h2>
                <p className="text-sm sm:text-base text-stone-600 leading-relaxed">
                  FamilyOS replaces disjointed family calendars, fragile spreadsheets, and ad-cluttered chore apps with a unified, offline-first operating system. Built on native Android (Kotlin, Jetpack Compose, Room SQLite) with zero floating-point financial arithmetic, decoupled member profiles, and strict guardian privacy controls.
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
                  <div className="border rounded-2xl p-3 bg-stone-50/60" style={{ borderColor: BRAND.border }}>
                    <p className="text-xs text-stone-500">Target Platform</p>
                    <p className="text-sm font-bold text-stone-800">Android 15 (API 35)</p>
                  </div>
                  <div className="border rounded-2xl p-3 bg-stone-50/60" style={{ borderColor: BRAND.border }}>
                    <p className="text-xs text-stone-500">Min Supported</p>
                    <p className="text-sm font-bold text-stone-800">Android 8.0 (API 26)</p>
                  </div>
                  <div className="border rounded-2xl p-3 bg-stone-50/60" style={{ borderColor: BRAND.border }}>
                    <p className="text-xs text-stone-500">Persistence</p>
                    <p className="text-sm font-bold text-stone-800">Room SQLite + FTS5</p>
                  </div>
                  <div className="border rounded-2xl p-3 bg-stone-50/60" style={{ borderColor: BRAND.border }}>
                    <p className="text-xs text-stone-500">Financial Type</p>
                    <p className="text-sm font-bold text-stone-800">Long Integer Cents</p>
                  </div>
                </div>
              </div>
            </div>

            {/* The 12 Major Product Modules Grid */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-serif font-bold text-stone-900">The 12 Core Product Modules</h3>
                  <p className="text-xs text-stone-500">Interconnected domain modules sharing one clean architecture foundation</p>
                </div>
                <span className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-stone-200/70 text-stone-700">12 Modules Defined</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {MODULES.map((mod) => {
                  const Icon = mod.icon;
                  return (
                    <div key={mod.id} className="border rounded-2xl p-5 bg-white hover:border-emerald-700/40 transition-all shadow-2xs group" style={{ borderColor: BRAND.border }}>
                      <div className="flex items-start justify-between mb-3">
                        <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ backgroundColor: BRAND.ivory, color: BRAND.primary }}>
                          <Icon className="w-5 h-5" />
                        </div>
                        <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-md bg-stone-100 text-stone-600">
                          {mod.code}
                        </span>
                      </div>
                      <h4 className="font-serif font-bold text-stone-900 text-base mb-1 group-hover:text-emerald-900 transition-colors">
                        {mod.id}. {mod.name}
                      </h4>
                      <p className="text-xs text-stone-600 leading-normal">{mod.desc}</p>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Architecture Layers Breakdown */}
            <div className="border rounded-3xl p-6 bg-white shadow-xs" style={{ borderColor: BRAND.border }}>
              <h3 className="text-lg font-serif font-bold text-stone-900 mb-4">Clean Architecture & Package Topology</h3>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
                <div className="border rounded-2xl p-4 bg-emerald-50/40 border-emerald-200/60">
                  <span className="font-bold text-emerald-900 block mb-1">Presentation Layer</span>
                  <p className="text-stone-600 mb-2">Composables, ViewModels, UI StateFlow, Navigation Compose</p>
                  <code className="text-[11px] block text-emerald-800 bg-white p-2 rounded-lg border border-emerald-100">
                    com.familyos.feature.*
                  </code>
                </div>
                <div className="border rounded-2xl p-4 bg-amber-50/40 border-amber-200/60">
                  <span className="font-bold text-amber-900 block mb-1">Domain Layer</span>
                  <p className="text-stone-600 mb-2">Use Cases, Pure Kotlin Data Models, Repository Contracts</p>
                  <code className="text-[11px] block text-amber-800 bg-white p-2 rounded-lg border border-amber-100">
                    com.familyos.core.domain
                  </code>
                </div>
                <div className="border rounded-2xl p-4 bg-sky-50/40 border-sky-200/60">
                  <span className="font-bold text-sky-900 block mb-1">Data & Persistence</span>
                  <p className="text-stone-600 mb-2">Room SQLite DAOs, Repository Impls, TypeConverters, DataStore</p>
                  <code className="text-[11px] block text-sky-800 bg-white p-2 rounded-lg border border-sky-100">
                    com.familyos.core.database
                  </code>
                </div>
                <div className="border rounded-2xl p-4 bg-purple-50/40 border-purple-200/60">
                  <span className="font-bold text-purple-900 block mb-1">Sync & Security</span>
                  <p className="text-stone-600 mb-2">WorkManager SyncWorker, Keystore AES-256, Cloud Gateway</p>
                  <code className="text-[11px] block text-purple-800 bg-white p-2 rounded-lg border border-purple-100">
                    com.familyos.core.security
                  </code>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* VIEW 2: DATABASE SCHEMAS */}
        {activeTab === 'database' && (
          <div className="space-y-6">
            <div className="border rounded-3xl p-6 bg-white shadow-xs" style={{ borderColor: BRAND.border }}>
              <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
                <div>
                  <h3 className="text-xl font-serif font-bold text-stone-900">Room SQLite Relational Schema</h3>
                  <p className="text-xs text-stone-500">26 tables specified with strict foreign key integrity, tombstone soft deletes, and index optimizations</p>
                </div>
                <span className="px-3 py-1 rounded-full text-xs font-semibold" style={{ backgroundColor: BRAND.lightGold, color: '#6A4D1B' }}>
                  Zero Floating-Point Constraint Enforced
                </span>
              </div>

              <div className="space-y-4">
                {DATABASE_TABLES.map((tbl, i) => (
                  <div key={i} className="border rounded-2xl p-4 bg-stone-50/50 hover:bg-white transition-all shadow-2xs" style={{ borderColor: BRAND.border }}>
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                      <div className="flex items-center space-x-2">
                        <Database className="w-4 h-4 text-emerald-800" />
                        <span className="font-mono font-bold text-stone-900 text-sm">{tbl.name}</span>
                      </div>
                      <span className="text-[11px] px-2 py-0.5 rounded-md bg-stone-200/70 text-stone-700 font-medium">
                        {tbl.keys}
                      </span>
                    </div>
                    <p className="text-xs text-stone-600 mb-3">{tbl.purpose}</p>

                    <div className="flex flex-wrap gap-1.5 mb-2">
                      {tbl.columns.map((col, idx) => {
                        const isCents = col.includes('cents');
                        return (
                          <span
                            key={idx}
                            className={`text-[11px] font-mono px-2 py-0.5 rounded-md border ${
                              isCents
                                ? 'bg-amber-100/70 border-amber-300 text-amber-900 font-bold'
                                : 'bg-white border-stone-200 text-stone-700'
                            }`}
                          >
                            {col}
                          </span>
                        );
                      })}
                    </div>

                    <div className="text-[11px] text-emerald-900/90 font-medium bg-emerald-50/50 px-2.5 py-1 rounded-lg border border-emerald-100 flex items-center space-x-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" />
                      <span>{tbl.constraint}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* VIEW 3: SECURITY & RBAC */}
        {activeTab === 'rbac' && (
          <div className="space-y-6">
            <div className="border rounded-3xl p-6 bg-white shadow-xs" style={{ borderColor: BRAND.border }}>
              <h3 className="text-xl font-serif font-bold text-stone-900 mb-2">Role-Based Access Control (RBAC) Matrix</h3>
              <p className="text-xs text-stone-500 mb-6">Server-authoritative authorization. Select a role below to simulate permission boundaries.</p>

              {/* Role Selector Tabs */}
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 mb-6">
                {RBAC_ROLES.map((r) => (
                  <button
                    key={r.role}
                    onClick={() => setSelectedRole(r.role)}
                    className={`p-3 rounded-2xl border text-left transition-all ${
                      selectedRole === r.role
                        ? 'border-emerald-800 bg-emerald-50/60 shadow-xs ring-1 ring-emerald-800'
                        : 'border-stone-200 hover:bg-stone-50'
                    }`}
                  >
                    <span className="font-mono font-bold text-xs text-stone-900 block">{r.role}</span>
                    <span className="text-[11px] text-stone-500">{r.badge}</span>
                  </button>
                ))}
              </div>

              {/* Active Role Permissions Card */}
              {(() => {
                const current = RBAC_ROLES.find((r) => r.role === selectedRole);
                if (!current) return null;
                return (
                  <div className="border rounded-2xl p-5 bg-stone-50" style={{ borderColor: BRAND.border }}>
                    <div className="flex items-center space-x-3 mb-4">
                      <Shield className="w-6 h-6 text-emerald-800" />
                      <div>
                        <h4 className="font-serif font-bold text-stone-900">{current.role} Privilege Profile</h4>
                        <p className="text-xs text-stone-500">{current.badge}</p>
                      </div>
                    </div>
                    <ul className="space-y-2">
                      {current.permissions.map((perm, idx) => (
                        <li key={idx} className="flex items-center space-x-2 text-xs text-stone-700 bg-white p-2.5 rounded-xl border border-stone-200">
                          <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                          <span className="font-medium">{perm}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                );
              })()}

              {/* Child Privacy & Guardian Safety Pillar */}
              <div className="mt-6 border rounded-2xl p-5 bg-amber-50/50 border-amber-200/60 space-y-3">
                <div className="flex items-center space-x-2 text-amber-900 font-serif font-bold">
                  <Lock className="w-5 h-5 text-amber-700" />
                  <h4>COPPA & GDPR-K Child Protection Guarantees</h4>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs text-stone-700">
                  <div className="bg-white p-3 rounded-xl border border-amber-100">
                    <span className="font-bold text-stone-900 block mb-1">Zero Child Credentials</span>
                    <p className="text-stone-600">Minor profiles are managed via Guardian PIN mode. No email/password or personal identity token stored.</p>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-amber-100">
                    <span className="font-bold text-stone-900 block mb-1">No AI PII Leakage</span>
                    <p className="text-stone-600">Any AI assistance strips child names and replaces them with generic anonymized tokens before backend transit.</p>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-amber-100">
                    <span className="font-bold text-stone-900 block mb-1">Zero Covert Tracking</span>
                    <p className="text-stone-600">No background location surveillance or stealth telemetry. All permissions are explicit, visible, and revocable.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* VIEW 4: EXACT CENTS FINANCE ENGINE */}
        {activeTab === 'finance' && (
          <div className="space-y-6">
            <div className="border rounded-3xl p-6 bg-white shadow-xs" style={{ borderColor: BRAND.border }}>
              <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                <h3 className="text-xl font-serif font-bold text-stone-900">Exact Integer-Cents Financial Engine</h3>
                <span className="text-xs px-2.5 py-1 rounded-full font-mono bg-emerald-100 text-emerald-900 font-bold">
                  Formula Verification: Pass
                </span>
              </div>
              <p className="text-xs text-stone-500 mb-6">
                Floating-point math is mathematically barred. The simulator below runs exact 64-bit integer cents calculations for the required FamilyOS Cash-Flow Allocator.
              </p>

              {/* Formula Blueprint Card */}
              <div className="bg-stone-50 border rounded-2xl p-4 font-mono text-xs space-y-1 mb-6 text-stone-800" style={{ borderColor: BRAND.border }}>
                <p className="font-bold text-emerald-900">Required Financial Allocator Specification:</p>
                <p>1. Available Before Savings = Expected Income - Planned Recurring Expenses - Planned Variable Expenses</p>
                <p>2. Available for Allocation = Available Before Savings - Other Planned Commitments</p>
                <p className="text-stone-500 text-[11px] pt-1">All inputs and outputs strictly stored as Long integer cents ($1.00 = 100L)</p>
              </div>

              {/* Interactive Inputs */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                <div className="border rounded-2xl p-4 bg-white" style={{ borderColor: BRAND.border }}>
                  <label className="text-xs font-semibold text-stone-700 block mb-1">Expected Income</label>
                  <input
                    type="number"
                    step="1000"
                    value={incomeInput / 100}
                    onChange={(e) => setIncomeInput(Math.round(Number(e.target.value) * 100))}
                    className="w-full text-lg font-mono font-bold text-stone-900 border rounded-xl px-3 py-1.5 focus:outline-emerald-800"
                  />
                  <span className="text-[11px] text-stone-400 font-mono mt-1 block">Stored: {incomeInput}L cents</span>
                </div>

                <div className="border rounded-2xl p-4 bg-white" style={{ borderColor: BRAND.border }}>
                  <label className="text-xs font-semibold text-stone-700 block mb-1">Recurring Expenses</label>
                  <input
                    type="number"
                    step="1000"
                    value={recurringExpInput / 100}
                    onChange={(e) => setRecurringExpInput(Math.round(Number(e.target.value) * 100))}
                    className="w-full text-lg font-mono font-bold text-stone-900 border rounded-xl px-3 py-1.5 focus:outline-emerald-800"
                  />
                  <span className="text-[11px] text-stone-400 font-mono mt-1 block">Stored: {recurringExpInput}L cents</span>
                </div>

                <div className="border rounded-2xl p-4 bg-white" style={{ borderColor: BRAND.border }}>
                  <label className="text-xs font-semibold text-stone-700 block mb-1">Variable Expenses</label>
                  <input
                    type="number"
                    step="1000"
                    value={variableExpInput / 100}
                    onChange={(e) => setVariableExpInput(Math.round(Number(e.target.value) * 100))}
                    className="w-full text-lg font-mono font-bold text-stone-900 border rounded-xl px-3 py-1.5 focus:outline-emerald-800"
                  />
                  <span className="text-[11px] text-stone-400 font-mono mt-1 block">Stored: {variableExpInput}L cents</span>
                </div>

                <div className="border rounded-2xl p-4 bg-white" style={{ borderColor: BRAND.border }}>
                  <label className="text-xs font-semibold text-stone-700 block mb-1">Other Commitments</label>
                  <input
                    type="number"
                    step="1000"
                    value={commitmentsInput / 100}
                    onChange={(e) => setCommitmentsInput(Math.round(Number(e.target.value) * 100))}
                    className="w-full text-lg font-mono font-bold text-stone-900 border rounded-xl px-3 py-1.5 focus:outline-emerald-800"
                  />
                  <span className="text-[11px] text-stone-400 font-mono mt-1 block">Stored: {commitmentsInput}L cents</span>
                </div>
              </div>

              {/* Live Computed Results */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="border rounded-2xl p-5 bg-stone-50" style={{ borderColor: BRAND.border }}>
                  <p className="text-xs font-medium text-stone-500 mb-1">Available Before Savings</p>
                  <p className="text-2xl font-serif font-bold text-stone-900">
                    {formatCents(availableBeforeSavingsCents)}
                  </p>
                  <p className="text-xs font-mono text-stone-500 mt-1">
                    Raw: {availableBeforeSavingsCents}L cents
                  </p>
                </div>

                <div className="border rounded-2xl p-5 rounded-2xl text-white" style={{ backgroundColor: BRAND.primary }}>
                  <p className="text-xs font-medium text-emerald-200/80 mb-1">Available for Allocation</p>
                  <p className="text-2xl font-serif font-bold text-white">
                    {formatCents(availableForAllocationCents)}
                  </p>
                  <p className="text-xs font-mono text-emerald-200/80 mt-1">
                    Raw: {availableForAllocationCents}L cents (Surplus ready for Savings & Reserves)
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* VIEW 5: OFFLINE SYNC */}
        {activeTab === 'sync' && (
          <div className="space-y-6">
            <div className="border rounded-3xl p-6 bg-white shadow-xs" style={{ borderColor: BRAND.border }}>
              <h3 className="text-xl font-serif font-bold text-stone-900 mb-2">Offline-First Synchronization Architecture</h3>
              <p className="text-xs text-stone-500 mb-6">
                Guaranteed operational integrity without internet connection. Local Room SQLite is the primary source of truth.
              </p>

              {/* State Machine Visualizer */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-center">
                <div className="border rounded-2xl p-4 bg-stone-50">
                  <div className="w-8 h-8 rounded-full bg-stone-200 text-stone-700 flex items-center justify-center mx-auto mb-2 font-bold text-xs">
                    1
                  </div>
                  <h4 className="font-bold text-xs text-stone-900 mb-1">Local Write</h4>
                  <p className="text-[11px] text-stone-600">Immediate write to Room DB with status <code className="bg-stone-200 px-1 rounded">LOCAL_ONLY</code> or <code className="bg-stone-200 px-1 rounded">PENDING_SYNC</code></p>
                </div>

                <div className="border rounded-2xl p-4 bg-amber-50/60 border-amber-200/60">
                  <div className="w-8 h-8 rounded-full bg-amber-200 text-amber-900 flex items-center justify-center mx-auto mb-2 font-bold text-xs">
                    2
                  </div>
                  <h4 className="font-bold text-xs text-amber-950 mb-1">Sync Queue</h4>
                  <p className="text-[11px] text-stone-600">Operation + JSON payload recorded in <code className="bg-amber-100 px-1 rounded">sync_queue</code> table with idempotency key</p>
                </div>

                <div className="border rounded-2xl p-4 bg-sky-50/60 border-sky-200/60">
                  <div className="w-8 h-8 rounded-full bg-sky-200 text-sky-900 flex items-center justify-center mx-auto mb-2 font-bold text-xs">
                    3
                  </div>
                  <h4 className="font-bold text-xs text-sky-950 mb-1">WorkManager Trigger</h4>
                  <p className="text-[11px] text-stone-600">Network constraint met &rarr; <code className="bg-sky-100 px-1 rounded">SyncWorker</code> executes with exponential retry backoff</p>
                </div>

                <div className="border rounded-2xl p-4 bg-emerald-50/60 border-emerald-200/60">
                  <div className="w-8 h-8 rounded-full bg-emerald-200 text-emerald-900 flex items-center justify-center mx-auto mb-2 font-bold text-xs">
                    4
                  </div>
                  <h4 className="font-bold text-xs text-emerald-950 mb-1">Reconciliation</h4>
                  <p className="text-[11px] text-stone-600">Cloud commits &rarr; local state flips to <code className="bg-emerald-100 px-1 rounded">SYNCED</code>, queue record purged</p>
                </div>
              </div>

              {/* Conflict Policies Table */}
              <div className="mt-8 border rounded-2xl p-5 bg-stone-50" style={{ borderColor: BRAND.border }}>
                <h4 className="font-serif font-bold text-stone-900 text-sm mb-3">Conflict Resolution Policies by Data Domain</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="bg-white p-3 rounded-xl border border-stone-200">
                    <span className="font-bold text-stone-900 block mb-0.5">Tasks & Checklists</span>
                    <span className="text-emerald-800 font-semibold block text-[11px] mb-1">Event-Based Merge</span>
                    <p className="text-stone-600">Task completion events merge additively so no family member's checked item is lost.</p>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-stone-200">
                    <span className="font-bold text-stone-900 block mb-0.5">Financial Transactions</span>
                    <span className="text-amber-800 font-semibold block text-[11px] mb-1">Append-Only / Never Overwrite</span>
                    <p className="text-stone-600">Financial entries are immutable ledger events. Edits spawn adjustment rows to guarantee audit history.</p>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-stone-200">
                    <span className="font-bold text-stone-900 block mb-0.5">Family Membership</span>
                    <span className="text-purple-800 font-semibold block text-[11px] mb-1">Server Authoritative Only</span>
                    <p className="text-stone-600">Roles, workspace access, and invites can only be committed with backend verification.</p>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-stone-200">
                    <span className="font-bold text-stone-900 block mb-0.5">Deleted Items (Tombstones)</span>
                    <span className="text-stone-800 font-semibold block text-[11px] mb-1">Soft Delete Flag</span>
                    <p className="text-stone-600">Records set is_deleted = 1 and sync tombstone to ensure multi-device deletions propagate cleanly.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* VIEW 6: 17 VERIFICATION SCENARIOS */}
        {activeTab === 'tests' && (
          <div className="space-y-6">
            <div className="border rounded-3xl p-6 bg-white shadow-xs" style={{ borderColor: BRAND.border }}>
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-xl font-serif font-bold text-stone-900">17 Mission-Critical Verification Scenarios</h3>
                  <p className="text-xs text-stone-500">Every scenario from the master specification mapped to automated test levels</p>
                </div>
                <span className="px-3 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-900">
                  17 of 17 Mapped
                </span>
              </div>

              <div className="space-y-2.5">
                {[
                  { id: 1, title: 'App starts with empty database', level: 'Repository & UI', check: 'Displays pristine onboarding / workspace creation without crash' },
                  { id: 2, title: 'App survives process death', level: 'ViewModel & SavedState', check: 'StateFlow & draft form inputs restored from SavedStateHandle' },
                  { id: 3, title: 'User loses internet access during write', level: 'Local Persistence', check: 'Write succeeds locally in Room; status flags PENDING_SYNC' },
                  { id: 4, title: 'User reconnects after being offline', level: 'WorkManager SyncWorker', check: 'Background queue drains FIFO, receives cloud IDs, status -> SYNCED' },
                  { id: 5, title: 'User belongs to multiple families', level: 'Domain Partitioning', check: 'Switching active familyId cleanly isolates all database queries' },
                  { id: 6, title: 'User switches family workspaces', level: 'Navigation Flow', check: 'Flow observers cancel and resubscribe without leaking memory' },
                  { id: 7, title: 'User loses family membership', level: 'Security & Auth', check: 'Backend revocation forces local cache purge & redirects to workspace chooser' },
                  { id: 8, title: 'Unauthorized access attempt to private data', level: 'Firestore Security Rules', check: 'Asserts PERMISSION_DENIED on non-member collections' },
                  { id: 9, title: 'Family invitation token expires', level: 'Domain Interactor', check: 'Returns InvitationExpiredException with friendly recovery guidance' },
                  { id: 10, title: 'Synchronization request is repeated', level: 'Network Idempotency', check: 'Duplicate idempotency key returns success without duplicate rows' },
                  { id: 11, title: 'Two users edit the same record concurrently', level: 'Sync Conflict Engine', check: 'Additive merge on task checks; diff resolution on recipe edits' },
                  { id: 12, title: 'User deletes item pending sync', level: 'Sync Queue', check: 'Purges pending UPDATE and dispatches single DELETE tombstone' },
                  { id: 13, title: 'Database migration runs against existing data', level: 'RoomMigrationTestHelper', check: 'Schema updates from v1 to v2 preserve all existing user rows' },
                  { id: 14, title: 'Financial calculation with decimal inputs', level: 'Domain Math Suite', check: 'Input string "$1,250.99" converts to exact 125099L cents without loss' },
                  { id: 15, title: 'Commercial subscription expires', level: 'Entitlement Engine', check: 'Gracefully switches to Free tier; existing data remains read-only safe' },
                  { id: 16, title: 'User restores Google Play purchase', level: 'Play Billing Client', check: 'Queries active purchases and updates signed local entitlement cache' },
                  { id: 17, title: 'Child profile restricted permissions', level: 'Compose UI / RBAC', check: 'Financial tabs and parent settings remain invisible & blocked' }
                ].map((s) => (
                  <div key={s.id} className="flex items-start justify-between p-3.5 rounded-2xl border bg-stone-50/60 hover:bg-white transition-all text-xs" style={{ borderColor: BRAND.border }}>
                    <div className="flex items-start space-x-3">
                      <span className="w-6 h-6 rounded-lg bg-emerald-100 text-emerald-900 font-bold flex items-center justify-center shrink-0 text-[11px]">
                        {s.id}
                      </span>
                      <div>
                        <p className="font-bold text-stone-900">{s.title}</p>
                        <p className="text-stone-500 text-[11px]">{s.check}</p>
                      </div>
                    </div>
                    <span className="font-mono text-[10px] px-2 py-0.5 rounded-md bg-stone-200/70 text-stone-700 font-semibold shrink-0 ml-2">
                      {s.level}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* VIEW 7: PROJECT DOCUMENTS (10) */}
        {activeTab === 'docs' && (
          <div className="space-y-6">
            <div className="border rounded-3xl p-6 bg-white shadow-xs" style={{ borderColor: BRAND.border }}>
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-xl font-serif font-bold text-stone-900">Canonical Project Documents</h3>
                  <p className="text-xs text-stone-500">All 10 project control files authored and maintained in workspace root</p>
                </div>
                <span className="text-xs px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-900 font-bold">10 Files Active</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                {[
                  { file: 'FAMILYOS_MASTER_PLAN.md', desc: '5-stage implementation roadmap, product vision, executive tenets' },
                  { file: 'FAMILYOS_ARCHITECTURE.md', desc: 'Android target SDK 35, Compose, Room, MVVM, server AI gateway' },
                  { file: 'FAMILYOS_DATABASE_SCHEMA.md', desc: '26 Room SQLite DDL tables, Long cents constraints, indices' },
                  { file: 'FAMILYOS_SECURITY_PLAN.md', desc: 'RBAC matrix, COPPA child privacy, Android Keystore, Firestore rules' },
                  { file: 'FAMILYOS_DESIGN_SYSTEM.md', desc: 'Forest Green/Ivory/Gold tokens, typography, 8dp spacing, adaptive' },
                  { file: 'FAMILYOS_FEATURE_REGISTER.md', desc: '42 granular features tracked across all 12 modules' },
                  { file: 'FAMILYOS_MASTER_PROGRESS.md', desc: 'Stage completion metrics, verified task records, roadmap' },
                  { file: 'FAMILYOS_TEST_STRATEGY.md', desc: 'Test pyramid, integer math verification, 17 mandatory scenarios' },
                  { file: 'FAMILYOS_RELEASE_CHECKLIST.md', desc: 'Google Play policies, Data Safety, Family Policy, Billing' },
                  { file: 'CHANGELOG.md', desc: 'Version history adhering to Keep a Changelog standard' }
                ].map((d, i) => (
                  <div key={i} className="border rounded-2xl p-4 bg-stone-50/50 hover:bg-white transition-all shadow-2xs" style={{ borderColor: BRAND.border }}>
                    <div className="flex items-center space-x-2 mb-1">
                      <FileText className="w-4 h-4 text-emerald-800" />
                      <span className="font-mono font-bold text-stone-900">{d.file}</span>
                    </div>
                    <p className="text-stone-600 text-[11px]">{d.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

      </main>

      {/* Global Footer */}
      <footer className="border-t px-6 py-4 text-center text-xs text-stone-500 bg-white" style={{ borderColor: BRAND.border }}>
        <p className="font-medium text-stone-700">FamilyOS Master Architect Foundation — Stage 0 Complete</p>
        <p className="text-[11px] text-stone-400 mt-0.5">Awaiting Product Owner Review & Stage 1 Core Platform Authorization</p>
      </footer>
    </div>
  );
}
