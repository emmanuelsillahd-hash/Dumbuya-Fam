package com.familyos.feature.family

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.familyos.core.designsystem.*
import com.familyos.core.domain.FamilyMember
import com.familyos.core.domain.FamilyRelationship
import com.familyos.core.domain.RelationshipType

/**
 * Stage 2: Family Profiles & Family Tree Screen
 * Supports interactive tree visualization, generation layers,
 * an accessible list alternative, and guardian-restricted member profiles.
 */
@Composable
fun FamilyTreeScreen(
    members: List<FamilyMember> = defaultSampleMembers,
    relationships: List<FamilyRelationship> = defaultSampleRelationships,
    onAddMember: () -> Unit = {},
    onAddRelationship: () -> Unit = {}
) {
    var viewMode by remember { mutableStateOf<"TREE" | "LIST">("TREE") }
    var selectedMember by remember { mutableStateOf<FamilyMember?>(members.firstOrNull()) }
    var showMemberDetailsDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(FamilyOSSpacing.md)
    ) {
        // Section Header with View Mode Toggle
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Family & Generations",
                    style = MaterialTheme.typography.headlineLarge,
                    color = FamilyOSColors.TextPrimary
                )
                Text(
                    text = "${members.size} members recorded • Guardian protected",
                    style = MaterialTheme.typography.bodySmall,
                    color = FamilyOSColors.TextSecondary
                )
            }

            // View Mode Switcher
            Row(
                modifier = Modifier
                    .clip(FamilyOSShapes.medium)
                    .background(FamilyOSColors.SageLight)
                    .padding(4.dp)
            ) {
                IconButton(
                    onClick = { viewMode = "TREE" },
                    modifier = Modifier
                        .size(36.dp)
                        .background(if (viewMode == "TREE") Color.White else Color.Transparent, FamilyOSShapes.small)
                ) {
                    Icon(
                        imageVector = Icons.Default.AccountTree,
                        contentDescription = "Tree View",
                        tint = if (viewMode == "TREE") FamilyOSColors.PrimaryForestGreen else FamilyOSColors.TextSecondary
                    )
                }
                IconButton(
                    onClick = { viewMode = "LIST" },
                    modifier = Modifier
                        .size(36.dp)
                        .background(if (viewMode == "LIST") Color.White else Color.Transparent, FamilyOSShapes.small)
                ) {
                    Icon(
                        imageVector = Icons.Default.FormatListBulleted,
                        contentDescription = "List View",
                        tint = if (viewMode == "LIST") FamilyOSColors.PrimaryForestGreen else FamilyOSColors.TextSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(FamilyOSSpacing.md))

        // Visual Tree or Accessible List
        if (viewMode == "TREE") {
            FamilyVisualTreeView(
                members = members,
                selectedMember = selectedMember,
                onSelectMember = {
                    selectedMember = it
                    showMemberDetailsDialog = true
                },
                modifier = Modifier.weight(1f)
            )
        } else {
            FamilyAccessibleListView(
                members = members,
                relationships = relationships,
                onSelectMember = {
                    selectedMember = it
                    showMemberDetailsDialog = true
                },
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(FamilyOSSpacing.sm))

        // Action Buttons Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(FamilyOSSpacing.sm)
        ) {
            FamilyOSPrimaryButton(
                text = "Add Family Member",
                icon = Icons.Default.PersonAdd,
                onClick = onAddMember,
                modifier = Modifier.weight(1f)
            )
            FamilyOSSecondaryButton(
                text = "Add Relationship",
                onClick = onAddRelationship,
                modifier = Modifier.weight(1f)
            )
        }
    }

    // Member Details Dialog
    if (showMemberDetailsDialog && selectedMember != null) {
        val member = selectedMember!!
        FamilyOSConfirmationDialog(
            title = member.displayName,
            message = "Role: ${member.relationshipToPrimary}\n" +
                    "Profile Type: ${if (member.isRestrictedProfile) "Minor Child (Guardian Managed)" else "Adult Member"}\n" +
                    "Reward Points: ${member.pointsBalance} pts\n" +
                    "Dietary: ${if (member.dietaryPreferences.isEmpty()) "Standard" else member.dietaryPreferences.joinToString()}",
            confirmText = "Edit Profile",
            dismissText = "Close",
            onConfirm = { showMemberDetailsDialog = false },
            onDismiss = { showMemberDetailsDialog = false }
        )
    }
}

@Composable
private fun FamilyVisualTreeView(
    members: List<FamilyMember>,
    selectedMember: FamilyMember?,
    onSelectMember: (FamilyMember) -> Unit,
    modifier: Modifier = Modifier
) {
    // Partition members into generational tiers
    val grandparents = members.filter { it.relationshipToPrimary == "GRANDPARENT" }
    val parents = members.filter { it.relationshipToPrimary in listOf("SELF", "SPOUSE", "PARENT") }
    val children = members.filter { it.relationshipToPrimary in listOf("CHILD", "MEMBER") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .clip(FamilyOSShapes.large)
            .background(Color.White)
            .border(1.dp, FamilyOSColors.BorderSubtle, FamilyOSShapes.large)
            .padding(FamilyOSSpacing.md)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Generation 1: Grandparents
        if (grandparents.isNotEmpty()) {
            TreeGenerationTier(
                tierLabel = "GENERATION I • ELDERS",
                members = grandparents,
                selectedMember = selectedMember,
                onSelectMember = onSelectMember
            )
            TreeConnectingLine()
        }

        // Generation 2: Parents / Primary Household Heads
        TreeGenerationTier(
            tierLabel = "GENERATION II • HOUSEHOLD HEADS",
            members = parents.ifEmpty { members.take(2) },
            selectedMember = selectedMember,
            onSelectMember = onSelectMember
        )

        TreeConnectingLine()

        // Generation 3: Children / Dependents
        TreeGenerationTier(
            tierLabel = "GENERATION III • CHILDREN & YOUTH",
            members = children.ifEmpty { members.drop(2) },
            selectedMember = selectedMember,
            onSelectMember = onSelectMember
        )
    }
}

@Composable
private fun TreeGenerationTier(
    tierLabel: String,
    members: List<FamilyMember>,
    selectedMember: FamilyMember?,
    onSelectMember: (FamilyMember) -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = tierLabel,
            style = MaterialTheme.typography.labelSmall,
            color = FamilyOSColors.SecondarySage,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = FamilyOSSpacing.xs)
        )
        Row(
            horizontalArrangement = Arrangement.spacedBy(FamilyOSSpacing.md),
            verticalAlignment = Alignment.CenterVertically
        ) {
            members.forEach { member ->
                val isSelected = member.id == selectedMember?.id
                Surface(
                    onClick = { onSelectMember(member) },
                    shape = FamilyOSShapes.medium,
                    color = if (isSelected) FamilyOSColors.SageLight else FamilyOSColors.WarmIvoryLight,
                    border = androidx.compose.foundation.BorderStroke(
                        if (isSelected) 2.dp else 1.dp,
                        if (isSelected) FamilyOSColors.PrimaryForestGreen else FamilyOSColors.BorderSubtle
                    ),
                    modifier = Modifier.width(140.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(FamilyOSSpacing.sm),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        FamilyOSAvatar(name = member.displayName, size = 48.dp)
                        Spacer(modifier = Modifier.height(FamilyOSSpacing.xs))
                        Text(
                            text = member.displayName,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = member.relationshipToPrimary,
                            style = MaterialTheme.typography.bodySmall,
                            color = FamilyOSColors.TextSecondary
                        )
                        if (member.isRestrictedProfile) {
                            Spacer(modifier = Modifier.height(4.dp))
                            FamilyOSStatusBadge(text = "Minor", color = FamilyOSColors.SecondarySage)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TreeConnectingLine() {
    Box(
        modifier = Modifier
            .padding(vertical = FamilyOSSpacing.xs)
            .width(2.dp)
            .height(24.dp)
            .background(FamilyOSColors.BorderStrong)
    )
}

@Composable
private fun FamilyAccessibleListView(
    members: List<FamilyMember>,
    relationships: List<FamilyRelationship>,
    onSelectMember: (FamilyMember) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(FamilyOSSpacing.sm)
    ) {
        items(members) { member ->
            FamilyOSCard(
                onClick = { onSelectMember(member) }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FamilyOSAvatar(name = member.displayName, size = 44.dp)
                    Spacer(modifier = Modifier.width(FamilyOSSpacing.md))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = member.displayName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Relationship: ${member.relationshipToPrimary} • Points: ${member.pointsBalance}",
                            style = MaterialTheme.typography.bodySmall,
                            color = FamilyOSColors.TextSecondary
                        )
                    }
                    if (member.isRestrictedProfile) {
                        FamilyOSStatusBadge(text = "Guardian Mode", color = FamilyOSColors.SoftGold)
                    }
                }
            }
        }
    }
}

// Default Sample Records for Visual Rendering
private val defaultSampleMembers = listOf(
    FamilyMember("m1", "fam1", "David Henderson", "SELF", null, null, listOf("Low Sodium"), emptyList(), false, 120),
    FamilyMember("m2", "fam1", "Sarah Henderson", "SPOUSE", null, null, emptyList(), listOf("Peanuts"), false, 140),
    FamilyMember("m3", "fam1", "Lucas Henderson", "CHILD", null, null, emptyList(), emptyList(), true, 85),
    FamilyMember("m4", "fam1", "Maya Henderson", "CHILD", null, null, emptyList(), emptyList(), true, 60)
)

private val defaultSampleRelationships = listOf(
    FamilyRelationship("r1", "fam1", "m1", "m2", RelationshipType.SPOUSE_PARTNER, "Married 2012"),
    FamilyRelationship("r2", "fam1", "m1", "m3", RelationshipType.PARENT_CHILD, "Father to Lucas"),
    FamilyRelationship("r3", "fam1", "m2", "m3", RelationshipType.PARENT_CHILD, "Mother to Lucas"),
    FamilyRelationship("r4", "fam1", "m1", "m4", RelationshipType.PARENT_CHILD, "Father to Maya")
)
