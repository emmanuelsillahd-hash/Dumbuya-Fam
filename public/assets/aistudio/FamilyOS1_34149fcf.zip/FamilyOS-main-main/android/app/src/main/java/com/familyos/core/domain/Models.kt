package com.familyos.core.domain

/**
 * Pure Kotlin Domain Models
 * Completely decoupled from Android framework and Room annotations.
 */

enum class AuthProvider {
    FIREBASE_GOOGLE,
    FIREBASE_EMAIL,
    LOCAL_DEVICE_MEMBER
}

enum class FamilyRole {
    OWNER,
    ADMIN,
    MEMBER,
    GUEST
}

enum class AccountStatus {
    ACTIVE,
    SUSPENDED,
    PENDING_DELETION
}

data class UserAccount(
    val id: String,
    val authenticationProvider: AuthProvider,
    val providerUserId: String,
    val email: String,
    val displayName: String?,
    val profilePictureUri: String?,
    val preferredLanguage: String,
    val accountStatus: AccountStatus,
    val createdAt: Long,
    val updatedAt: Long
)

data class FamilyWorkspace(
    val id: String,
    val name: String,
    val description: String?,
    val logoUrl: String?,
    val currencyCode: String,
    val ownerUserId: String,
    val isDeleted: Boolean
)

data class FamilyMember(
    val id: String,
    val familyId: String,
    val displayName: String,
    val relationshipToPrimary: String,
    val birthDate: Long?,
    val avatarUrl: String?,
    val dietaryPreferences: List<String>,
    val allergies: List<String>,
    val isRestrictedProfile: Boolean,
    val pointsBalance: Int
)

data class FamilyMembership(
    val id: String,
    val familyId: String,
    val userAccountId: String,
    val memberProfileId: String,
    val role: FamilyRole,
    val status: String,
    val joinedAt: Long
)

data class GuardianRelationship(
    val id: String,
    val familyId: String,
    val guardianMemberId: String,
    val minorMemberId: String,
    val relationshipType: String,
    val isEmergencyContact: Boolean,
    val canManageHealthRecords: Boolean
)

data class SyncOperation(
    val operationId: String,
    val idempotencyKey: String,
    val familyId: String,
    val entityType: String,
    val entityId: String,
    val operationType: String,
    val payloadJson: String
)
