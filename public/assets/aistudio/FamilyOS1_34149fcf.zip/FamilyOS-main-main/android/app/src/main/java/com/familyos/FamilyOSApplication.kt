package com.familyos

import android.app.Application
import com.familyos.core.database.FamilyOSDatabase

/**
 * Main Application class for FamilyOS
 * Pre-warms the Room SQLite database instance upon cold startup.
 */
class FamilyOSApplication : Application() {

    lateinit var database: FamilyOSDatabase
        private set

    override fun onCreate() {
        super.onCreate()
        database = FamilyOSDatabase.getInstance(this)
    }
}
