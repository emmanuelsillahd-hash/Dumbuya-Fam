package com.familyos.core.domain

/**
 * Domain-level Role-Based Access Control (RBAC) and Family Guardian Security Policy.
 * Enforces role boundaries and minor child protection across all repositories and domain services.
 */
object FamilySecurityPolicy {

    enum class SecurityOperation {
        READ,
        CREATE,
        UPDATE,
        DELETE,
        EXPORT,
        BACKGROUND_SYNC
    }

    /**
     * Determines whether the given role can access the household financial ledger,
     * budgets, bank connections, and expense records.
     */
    fun canAccessFinancialLedger(role: FamilyRole): Boolean {
        return role == FamilyRole.OWNER || role == FamilyRole.ADMIN
    }

    /**
     * Granular authorization check for financial operations (Read, Create, Update, Delete, Export, Sync).
     * Enforces:
     * - Only OWNER and ADMIN roles are authorized.
     * - An authenticated account (hasAccount = true) is strictly required; unlinked or placeholder profiles cannot act.
     * - MEMBER and GUEST roles are rejected across all financial operations.
     */
    fun isFinancialOperationAuthorized(
        role: FamilyRole,
        operation: SecurityOperation,
        hasAccount: Boolean
    ): Boolean {
        if (!hasAccount) return false
        val isPrivileged = role == FamilyRole.OWNER || role == FamilyRole.ADMIN
        return when (operation) {
            SecurityOperation.READ,
            SecurityOperation.CREATE,
            SecurityOperation.UPDATE,
            SecurityOperation.DELETE,
            SecurityOperation.EXPORT,
            SecurityOperation.BACKGROUND_SYNC -> isPrivileged
        }
    }

    /**
     * Granular authorization check for sensitive minor and health profile data.
     * Enforces:
     * - Authenticated account requirement.
     * - Guardian authorization for minor wards.
     * - Strict isolation from non-guardian MEMBERs and GUESTs.
     */
    fun isSensitiveDataOperationAuthorized(
        actorRole: FamilyRole,
        actorMemberId: String,
        targetMemberId: String,
        isGuardian: Boolean,
        operation: SecurityOperation,
        hasAccount: Boolean
    ): Boolean {
        if (!hasAccount) return false
        if (actorRole == FamilyRole.GUEST) return false

        // Self-access
        if (actorMemberId == targetMemberId) {
            return when (operation) {
                SecurityOperation.READ,
                SecurityOperation.CREATE,
                SecurityOperation.UPDATE,
                SecurityOperation.EXPORT,
                SecurityOperation.BACKGROUND_SYNC -> true
                SecurityOperation.DELETE -> false // Sensitive health/minor records cannot be self-deleted
            }
        }

        // Administrative authority (OWNER / ADMIN)
        if (actorRole == FamilyRole.OWNER || actorRole == FamilyRole.ADMIN) {
            return true
        }

        // Verified legal guardian
        if (isGuardian) {
            return true
        }

        return false
    }

    /**
     * Authorizes background synchronization for a workspace.
     */
    fun canPerformBackgroundSync(
        role: FamilyRole,
        callerFamilyId: String,
        resourceFamilyId: String,
        hasAccount: Boolean
    ): Boolean {
        if (!hasAccount) return false
        if (role == FamilyRole.GUEST) return false
        return isWorkspaceAuthorized(callerFamilyId, resourceFamilyId)
    }

    /**
     * Determines whether the given role can manage (create, edit, archive) family member profiles.
     */
    fun canManageFamilyMembers(role: FamilyRole): Boolean {
        return role == FamilyRole.OWNER || role == FamilyRole.ADMIN
    }

    /**
     * Determines whether an actor can view or edit sensitive details of a restricted minor profile.
     * Requires the actor to be an OWNER/ADMIN, or a verified legal guardian/parent.
     */
    fun canManageMinorProfile(
        actorRole: FamilyRole,
        actorMemberId: String,
        targetMemberId: String,
        isGuardian: Boolean
    ): Boolean {
        // Own profile self-inspection if not restricted
        if (actorMemberId == targetMemberId) return true

        // Workspace OWNER or ADMIN have administrative stewardship
        if (actorRole == FamilyRole.OWNER || actorRole == FamilyRole.ADMIN) return true

        // Verified legal guardian / parent has access
        return isGuardian
    }

    /**
     * Determines whether a profile has restricted child access (blocks finances, settings, full member audit).
     */
    fun isRestrictedAccess(isRestrictedProfile: Boolean, role: FamilyRole): Boolean {
        if (isRestrictedProfile) return true
        return role == FamilyRole.GUEST
    }

    /**
     * Determines whether a member can create or modify family goals and projects.
     */
    fun canManageGoalsAndProjects(role: FamilyRole): Boolean {
        return role == FamilyRole.OWNER || role == FamilyRole.ADMIN
    }

    /**
     * Determines whether a member can complete a specific task.
     * Allowed if the task is assigned to the member, or if the actor is OWNER/ADMIN.
     */
    fun canCompleteTask(
        actorRole: FamilyRole,
        actorMemberId: String,
        assignedMemberId: String?
    ): Boolean {
        if (actorRole == FamilyRole.OWNER || actorRole == FamilyRole.ADMIN) return true
        if (assignedMemberId != null && assignedMemberId == actorMemberId) return true
        return assignedMemberId == null // Unassigned tasks can be completed by any household member
    }

    /**
     * Determines whether a member can complete an assigned chore.
     * All household members (including children) can complete chores assigned to them or unassigned chores.
     */
    fun canCompleteChore(
        actorMemberId: String,
        assignedMemberId: String?
    ): Boolean {
        return assignedMemberId == null || assignedMemberId == actorMemberId
    }

    /**
     * Validates that an operation within a family workspace matches the caller's active familyId.
     */
    fun isWorkspaceAuthorized(callerFamilyId: String, resourceFamilyId: String): Boolean {
        return callerFamilyId.isNotBlank() && callerFamilyId == resourceFamilyId
    }
}
