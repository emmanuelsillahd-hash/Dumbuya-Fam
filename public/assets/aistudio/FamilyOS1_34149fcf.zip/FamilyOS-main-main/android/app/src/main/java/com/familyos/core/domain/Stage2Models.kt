package com.familyos.core.domain

/**
 * Stage 2 Pure Kotlin Domain Models
 * Completely decoupled from Android and Room framework types.
 */

// 1. Relationships
enum class RelationshipType {
    PARENT_CHILD,
    SPOUSE_PARTNER,
    SIBLING,
    GRANDPARENT_GRANDCHILD,
    OTHER
}

data class FamilyRelationship(
    val id: String,
    val familyId: String,
    val person1MemberId: String,
    val person2MemberId: String,
    val relationshipType: RelationshipType,
    val notes: String?
)

// 2. Goals, Projects & Tasks
enum class GoalCategory {
    FINANCIAL,
    HOUSEHOLD,
    EDUCATION,
    HEALTH,
    LIFESTYLE,
    OTHER
}

enum class Priority {
    LOW,
    MEDIUM,
    HIGH,
    URGENT
}

data class FamilyGoal(
    val id: String,
    val familyId: String,
    val title: String,
    val description: String?,
    val category: GoalCategory,
    val targetDate: Long?,
    val priority: Priority,
    val ownerMemberId: String?,
    val status: String,
    val progressPercentage: Int = 0
)

data class Project(
    val id: String,
    val familyId: String,
    val goalId: String?,
    val name: String,
    val description: String?,
    val budgetCents: Long, // Exact Long integer cents
    val targetDate: Long?,
    val status: String,
    val leadMemberId: String?
)

data class Task(
    val id: String,
    val familyId: String,
    val projectId: String?,
    val parentTaskId: String?,
    val title: String,
    val notes: String?,
    val assignedMemberId: String?,
    val priority: Priority,
    val dueDate: Long?,
    val isCompleted: Boolean,
    val completedAt: Long?,
    val completedByMemberId: String?,
    val recurrenceRule: String?,
    val checklistItems: List<TaskChecklistItem> = emptyList()
)

data class TaskChecklistItem(
    val id: String,
    val taskId: String,
    val title: String,
    val isDone: Boolean,
    val position: Int
)

// 3. Recipes & Ingredients
enum class RecipeDifficulty {
    EASY,
    MEDIUM,
    HARD
}

data class Recipe(
    val id: String,
    val familyId: String,
    val title: String,
    val description: String?,
    val imageUri: String?,
    val prepTimeMinutes: Int,
    val cookTimeMinutes: Int,
    val servings: Int,
    val difficulty: RecipeDifficulty,
    val category: String,
    val dietaryNotes: String?,
    val familyRating: Int,
    val isFavorite: Boolean,
    val source: String?,
    val storageInstructions: String?,
    val ingredients: List<RecipeIngredient> = emptyList(),
    val instructions: List<RecipeInstruction> = emptyList()
)

data class RecipeIngredient(
    val id: String,
    val recipeId: String,
    val itemName: String,
    val quantity: Double,
    val unit: String,
    val notes: String?
) {
    /**
     * Scale ingredient quantity based on target servings vs original servings.
     */
    fun scaleForServings(originalServings: Int, targetServings: Int): RecipeIngredient {
        if (originalServings <= 0 || targetServings <= 0) return this
        val ratio = targetServings.toDouble() / originalServings.toDouble()
        return copy(quantity = (quantity * ratio * 100.0).toLong() / 100.0) // 2 decimal precision
    }
}

data class RecipeInstruction(
    val id: String,
    val recipeId: String,
    val stepNumber: Int,
    val instructionText: String
)

// 4. Meal Planner & Groceries
enum class MealType {
    BREAKFAST,
    LUNCH,
    DINNER,
    SNACK
}

data class MealPlanEntry(
    val id: String,
    val familyId: String,
    val planDate: Long,
    val mealType: MealType,
    val recipeId: String?,
    val customMealTitle: String?,
    val servings: Int,
    val notes: String?
)

data class GroceryListItem(
    val id: String,
    val familyId: String,
    val itemName: String,
    val category: String,
    val quantity: Double,
    val unit: String,
    val isPurchased: Boolean,
    val sourceRecipeId: String?
)

// 5. Chores & Routines
enum class ChoreFrequency {
    DAILY,
    WEEKLY,
    MONTHLY,
    CUSTOM
}

data class Chore(
    val id: String,
    val familyId: String,
    val title: String,
    val description: String?,
    val assignedMemberId: String?,
    val zone: String,
    val frequency: ChoreFrequency,
    val rewardPoints: Int,
    val nextDueDate: Long,
    val requiresVerification: Boolean,
    val isCompleted: Boolean
)

data class ChoreCompletionHistory(
    val id: String,
    val choreId: String,
    val completedByMemberId: String,
    val completedAt: Long,
    val pointsEarned: Int
)

// 6. Home Assets & Maintenance
enum class AssetCategory {
    APPLIANCES,
    FURNITURE,
    ELECTRONICS,
    VEHICLES,
    TOOLS,
    HVAC,
    PLUMBING,
    OTHER
}

data class HomeAsset(
    val id: String,
    val familyId: String,
    val name: String,
    val category: AssetCategory,
    val description: String?,
    val purchaseDate: Long?,
    val purchasePriceCents: Long, // Exact Long integer cents ($1.00 = 100L)
    val warrantyExpiryDate: Long?,
    val serialNumber: String?,
    val location: String?,
    val nextMaintenanceDate: Long?
)

data class AssetMaintenance(
    val id: String,
    val assetId: String,
    val title: String,
    val costCents: Long,
    val performedDate: Long,
    val notes: String?,
    val serviceProvider: String?
)

data class HouseholdWishlist(
    val id: String,
    val familyId: String,
    val itemName: String,
    val estimatedCostCents: Long,
    val priority: Priority,
    val category: String,
    val url: String?
)

// 7. Shared Calendar
enum class CalendarEventCategory {
    BIRTHDAY,
    ANNIVERSARY,
    GOAL_DUE,
    TASK_DUE,
    MEAL,
    CHORE,
    MAINTENANCE,
    FAMILY_EVENT
}

data class CalendarEvent(
    val id: String,
    val familyId: String,
    val title: String,
    val eventDate: Long,
    val eventTimeMillis: Long?,
    val category: CalendarEventCategory,
    val sourceEntityId: String?,
    val description: String?
)
