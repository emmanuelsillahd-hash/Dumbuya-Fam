package com.familyos.feature.calendar

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.familyos.core.designsystem.*
import com.familyos.core.domain.CalendarEvent
import com.familyos.core.domain.CalendarEventCategory

/**
 * Stage 2: Shared Household Calendar Screen
 * Unified timeline aggregating Birthdays, Anniversaries, Goals, Tasks, Meals, Chores & Maintenance.
 */
@Composable
fun CalendarScreen(
    events: List<CalendarEvent> = sampleCalendarEvents,
    onAddEvent: () -> Unit = {}
) {
    var selectedCategory by remember { mutableStateOf<String>("ALL") }
    var selectedViewMode by remember { mutableStateOf<"DAY" | "WEEK" | "MONTH">("WEEK") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(FamilyOSSpacing.md)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Household Calendar",
                    style = MaterialTheme.typography.headlineLarge,
                    color = FamilyOSColors.TextPrimary
                )
                Text(
                    text = "Aggregated household schedule & milestone timeline",
                    style = MaterialTheme.typography.bodySmall,
                    color = FamilyOSColors.TextSecondary
                )
            }

            FamilyOSPrimaryButton(
                text = "Add Event",
                icon = Icons.Default.Event,
                onClick = onAddEvent
            )
        }

        Spacer(modifier = Modifier.height(FamilyOSSpacing.sm))

        // View Mode Toggle (Day / Week / Month)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(FamilyOSColors.SageLight, FamilyOSShapes.medium)
                .padding(4.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            listOf("DAY", "WEEK", "MONTH").forEach { mode ->
                val isSelected = selectedViewMode == mode
                TextButton(
                    onClick = { selectedViewMode = mode as any },
                    shape = FamilyOSShapes.small,
                    colors = ButtonDefaults.textButtonColors(
                        containerColor = if (isSelected) Color.White else Color.Transparent,
                        contentColor = if (isSelected) FamilyOSColors.PrimaryForestGreen else FamilyOSColors.TextSecondary
                    ),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(text = mode, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
                }
            }
        }

        Spacer(modifier = Modifier.height(FamilyOSSpacing.sm))

        // Category Filter Chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(FamilyOSSpacing.xs)
        ) {
            listOf("ALL", "BIRTHDAY", "MEAL", "CHORE", "MAINTENANCE", "GOAL_DUE").forEach { cat ->
                val isSelected = selectedCategory == cat
                FilterChip(
                    selected = isSelected,
                    onClick = { selectedCategory = cat },
                    label = { Text(cat.replace("_", " ")) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = FamilyOSColors.SageLight,
                        selectedLabelColor = FamilyOSColors.PrimaryForestGreen
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(FamilyOSSpacing.md))

        // Events Stream
        val filteredEvents = if (selectedCategory == "ALL") events else events.filter { it.category.name == selectedCategory }

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(FamilyOSSpacing.sm)
        ) {
            items(filteredEvents) { event ->
                val badgeColor = when (event.category) {
                    CalendarEventCategory.BIRTHDAY -> FamilyOSColors.SoftGold
                    CalendarEventCategory.MEAL -> FamilyOSColors.SecondarySage
                    CalendarEventCategory.CHORE -> FamilyOSColors.SageGreen
                    CalendarEventCategory.MAINTENANCE -> FamilyOSColors.Warning
                    CalendarEventCategory.GOAL_DUE -> FamilyOSColors.PrimaryForestGreen
                    else -> FamilyOSColors.SecondarySage
                }

                FamilyOSCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            modifier = Modifier.width(64.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "OCT",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = FamilyOSColors.SecondarySage
                            )
                            Text(
                                text = "30",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = FamilyOSColors.TextPrimary
                            )
                        }

                        Spacer(modifier = Modifier.width(FamilyOSSpacing.md))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = event.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(FamilyOSSpacing.xs))
                                FamilyOSStatusBadge(text = event.category.name.replace("_", " "), color = badgeColor)
                            }
                            if (event.description != null) {
                                Text(
                                    text = event.description,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = FamilyOSColors.TextSecondary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private val sampleCalendarEvents = listOf(
    CalendarEvent("e1", "fam1", "Sarah's Birthday Celebration", System.currentTimeMillis(), null, CalendarEventCategory.BIRTHDAY, null, "Family dinner & gift exchange"),
    CalendarEvent("e2", "fam1", "Tuscan Pasta Family Dinner", System.currentTimeMillis() + 36000000L, null, CalendarEventCategory.MEAL, "r1", "4 servings planned"),
    CalendarEvent("e3", "fam1", "Attic Heat Pump Filter Inspection", System.currentTimeMillis() + 86400000L, null, CalendarEventCategory.MAINTENANCE, "a2", "Bi-monthly filter wash"),
    CalendarEvent("e4", "fam1", "Solar Panel Contractor Bids Deadline", System.currentTimeMillis() + 2 * 86400000L, null, CalendarEventCategory.GOAL_DUE, "g1", "Finalize proposal reviews")
)
