package com.familyos

import com.familyos.core.sync.ConflictPolicy
import com.familyos.core.sync.SyncRepositoryImpl
import org.junit.Assert.assertEquals
import org.junit.Test
import java.util.UUID

class SyncPolicyAndIdempotencyTest {

    @Test
    fun testConflictPolicyResolution() {
        // Tasks must resolve via event-based merge
        assertEquals(ConflictPolicy.EVENT_BASED_MERGE, SyncRepositoryImpl.resolveConflictPolicy("TASK"))
        assertEquals(ConflictPolicy.EVENT_BASED_MERGE, SyncRepositoryImpl.resolveConflictPolicy("CHECKLIST_ITEM"))

        // Financial records must NEVER be silently overwritten (Append-only ledger)
        assertEquals(ConflictPolicy.APPEND_ONLY_LEDGER, SyncRepositoryImpl.resolveConflictPolicy("INCOME"))
        assertEquals(ConflictPolicy.APPEND_ONLY_LEDGER, SyncRepositoryImpl.resolveConflictPolicy("EXPENSE"))
        assertEquals(ConflictPolicy.APPEND_ONLY_LEDGER, SyncRepositoryImpl.resolveConflictPolicy("FINANCIAL_ACCOUNT"))

        // Memberships must be server-authoritative
        assertEquals(ConflictPolicy.SERVER_AUTHORITATIVE, SyncRepositoryImpl.resolveConflictPolicy("FAMILY_MEMBERSHIP"))

        // General entities soft-delete tombstones
        assertEquals(ConflictPolicy.TOMBSTONE_SOFT_DELETE, SyncRepositoryImpl.resolveConflictPolicy("RECIPE"))
    }

    @Test
    fun testIdempotencyKeyGeneration() {
        val entityType = "EXPENSE"
        val entityId = UUID.randomUUID().toString()
        val operation = "INSERT"

        val idempotencyKey = "$entityType:$entityId:$operation"
        val duplicateKey = "$entityType:$entityId:$operation"

        // Identical parameters generate exact matching idempotency keys for deduplication
        assertEquals(idempotencyKey, duplicateKey)
    }
}
