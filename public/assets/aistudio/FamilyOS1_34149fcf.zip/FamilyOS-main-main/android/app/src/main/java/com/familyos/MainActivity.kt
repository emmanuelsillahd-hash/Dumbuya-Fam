package com.familyos

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.familyos.core.designsystem.FamilyOSEmptyState
import com.familyos.core.designsystem.FamilyOSTheme
import com.familyos.core.navigation.DeepLinkResult
import com.familyos.core.navigation.FamilyOSAppShell
import com.familyos.core.navigation.FamilyOSDestination
import com.familyos.core.navigation.RecipeDeepLinkParser
import com.familyos.feature.assets.HomeAssetsScreen
import com.familyos.feature.calendar.CalendarScreen
import com.familyos.feature.chores.ChoresScreen
import com.familyos.feature.dashboard.DashboardScreen
import com.familyos.feature.family.FamilyTreeScreen
import com.familyos.feature.goals.GoalsScreen
import com.familyos.feature.meals.MealPlannerScreen
import com.familyos.feature.recipes.RecipeLibraryScreen
import com.familyos.feature.finance.FinanceScreen
import com.familyos.feature.wellbeing.WellbeingScreen
import com.familyos.feature.safety.EmergencyScreen

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val initialDeepLink = parseDeepLink(intent)

        setContent {
            FamilyOSTheme {
                // If a recipe deep link arrived, default to HOUSEHOLD (Meal & Recipe hub)
                var currentDestination by remember {
                    mutableStateOf(
                        if (initialDeepLink is DeepLinkResult.RecipeDetail) {
                            FamilyOSDestination.HOUSEHOLD
                        } else {
                            FamilyOSDestination.OVERVIEW
                        }
                    )
                }

                FamilyOSAppShell(
                    currentDestination = currentDestination,
                    onNavigate = { destination ->
                        currentDestination = destination
                    },
                    activeFamilyName = "The Henderson Household",
                    syncStatusLabel = "Stage 2 • Family & Household Live"
                ) {
                    when (currentDestination) {
                        FamilyOSDestination.OVERVIEW -> {
                            DashboardScreen(
                                onQuickAction = { action ->
                                    when (action) {
                                        "PLAN_MEAL" -> currentDestination = FamilyOSDestination.HOUSEHOLD
                                        "ASSIGN_CHORE" -> currentDestination = FamilyOSDestination.HOUSEHOLD
                                        "LOG_EXPENSE" -> currentDestination = FamilyOSDestination.FINANCE
                                        "ADD_MEMBER" -> currentDestination = FamilyOSDestination.FAMILY
                                        "VIEW_CALENDAR" -> currentDestination = FamilyOSDestination.CALENDAR
                                    }
                                }
                            )
                        }
                        FamilyOSDestination.FAMILY -> {
                            FamilyTreeScreen(
                                onAddMember = { /* Opens Add Member Sheet */ },
                                onAddRelationship = { /* Opens Add Relationship Sheet */ }
                            )
                        }
                        FamilyOSDestination.GOALS_PROJECTS -> {
                            GoalsScreen(
                                onAddGoal = { /* Opens Goal Creation Sheet */ },
                                onAddTask = { /* Opens Task Creation Sheet */ }
                            )
                        }
                        FamilyOSDestination.HOUSEHOLD -> {
                            MealPlannerScreen(
                                onAddMeal = { /* Add Meal Plan */ },
                                onGenerateGroceryList = { /* Generate Groceries */ }
                            )
                        }
                        FamilyOSDestination.FINANCE -> {
                            FinanceScreen()
                        }
                        FamilyOSDestination.HEALTH_FITNESS -> {
                            WellbeingScreen()
                        }
                        FamilyOSDestination.FAMILY_SAFETY -> {
                            EmergencyScreen()
                        }
                        FamilyOSDestination.CALENDAR -> {
                            CalendarScreen(
                                onAddEvent = { /* Add Event Sheet */ }
                            )
                        }
                        else -> {
                            // Stage 4 / 5 Future Module Foundation Placeholders
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(24.dp)
                            ) {
                                FamilyOSEmptyState(
                                    title = "${currentDestination.title} Module",
                                    description = "Database schemas, repositories and permission rules have been formalized. Full UI workflows activate in their designated development stage.",
                                    actionText = "Return to Overview",
                                    onActionClick = { currentDestination = FamilyOSDestination.OVERVIEW },
                                    icon = currentDestination.icon
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        parseDeepLink(intent)
    }

    private fun parseDeepLink(intent: Intent?): DeepLinkResult {
        val uriString = intent?.dataString
        return RecipeDeepLinkParser.parse(uriString)
    }
}
