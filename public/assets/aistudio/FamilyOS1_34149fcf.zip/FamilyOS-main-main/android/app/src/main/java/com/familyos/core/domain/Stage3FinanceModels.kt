package com.familyos.core.domain

/**
 * Pure Kotlin Stage 3 Domain Models for FamilyOS Finance Module
 *
 * CRITICAL RULE: All monetary values are strictly Long integer cents ($1.00 = 100L).
 * Floating-point types (Double, Float) are strictly forbidden in calculations.
 */

enum class AccountType {
    CHECKING,
    SAVINGS,
    CREDIT_CARD,
    INVESTMENT,
    CASH,
    LOAN
}

enum class TransactionType {
    INCOME,
    EXPENSE,
    TRANSFER
}

enum class RecurrenceInterval {
    WEEKLY,
    BIWEEKLY,
    MONTHLY,
    YEARLY
}

data class FinancialAccount(
    val id: String,
    val familyId: String,
    val name: String,
    val accountType: AccountType,
    val currentBalanceCents: Long, // Signed Long cents (liabilities are negative)
    val isLiability: Boolean,
    val currency: String = "USD",
    val institution: String? = null,
    val isArchived: Boolean = false,
    val createdAt: Long,
    val updatedAt: Long
)

data class FinancialTransaction(
    val id: String,
    val familyId: String,
    val accountId: String,
    val destinationAccountId: String? = null, // Set on internal transfer
    val title: String,
    val amountCents: Long, // Positive Long cents
    val transactionType: TransactionType,
    val category: String,
    val transactionDate: Long,
    val isCleared: Boolean = true,
    val isReversal: Boolean = false,
    val reversalOfId: String? = null,
    val notes: String? = null,
    val paidByMemberId: String? = null,
    val createdAt: Long
)

data class RecurringTransactionTemplate(
    val id: String,
    val familyId: String,
    val accountId: String,
    val title: String,
    val amountCents: Long,
    val transactionType: TransactionType,
    val category: String,
    val recurrenceInterval: RecurrenceInterval,
    val nextDueDate: Long,
    val isActive: Boolean = true,
    val createdAt: Long
)

data class EnvelopeBudget(
    val id: String,
    val familyId: String,
    val category: String,
    val allocatedCents: Long,
    val spentCents: Long = 0L,
    val monthEpoch: Long,
    val alertThresholdPercentage: Int = 85
) {
    val remainingCents: Long
        get() = allocatedCents - spentCents

    val isOverBudget: Boolean
        get() = spentCents > allocatedCents

    val isNearLimit: Boolean
        get() = allocatedCents > 0L && ((spentCents * 100L) / allocatedCents) >= alertThresholdPercentage
}

data class SavingsGoal(
    val id: String,
    val familyId: String,
    val linkedAccountId: String? = null,
    val title: String,
    val targetCents: Long,
    val currentCents: Long = 0L,
    val plannedMonthlyContributionCents: Long = 0L,
    val targetDate: Long? = null,
    val isCompleted: Boolean = false
) {
    val remainingCents: Long
        get() = (targetCents - currentCents).coerceAtLeast(0L)

    val progressPercentage: Int
        get() = if (targetCents <= 0L) 100 else (((currentCents * 100L) / targetCents).coerceIn(0L, 100L)).toInt()
}

data class BillSubscription(
    val id: String,
    val familyId: String,
    val preferredAccountId: String? = null,
    val payee: String,
    val amountCents: Long,
    val billingCycle: String,
    val dueDate: Long,
    val isSubscription: Boolean = false,
    val isAutoPay: Boolean = false,
    val reminderDaysBefore: Int = 3
)

/**
 * Strict Household Cash-Flow Planning Model
 *
 * Formula:
 * Expected Income
 * − Recurring Expenses
 * − Other Planned Expenses
 * = Available Planned Cash Flow
 */
data class CashFlowPlan(
    val expectedIncomeCents: Long,
    val recurringExpensesCents: Long,
    val otherPlannedExpensesCents: Long,
    // Planned allocations (does not trigger real fund transfer)
    val plannedSavingsCents: Long = 0L,
    val plannedEmergencyReserveCents: Long = 0L,
    val plannedPriorityObjectivesCents: Long = 0L
) {
    val availablePlannedCashFlowCents: Long
        get() = expectedIncomeCents - recurringExpensesCents - otherPlannedExpensesCents

    val totalAllocatedCents: Long
        get() = plannedSavingsCents + plannedEmergencyReserveCents + plannedPriorityObjectivesCents

    val unallocatedCashFlowCents: Long
        get() = availablePlannedCashFlowCents - totalAllocatedCents
}

data class NetWorthSummary(
    val totalAssetsCents: Long,
    val totalLiabilitiesCents: Long // Positive magnitude of debt
) {
    val netWorthCents: Long
        get() = totalAssetsCents - totalLiabilitiesCents
}
