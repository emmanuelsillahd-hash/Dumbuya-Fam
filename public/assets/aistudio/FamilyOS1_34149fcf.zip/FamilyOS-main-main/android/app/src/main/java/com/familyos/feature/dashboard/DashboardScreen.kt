package com.familyos.feature.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.familyos.core.designsystem.*

/**
 * Initial FamilyOS Dashboard Screen (Stage 1 Core Foundation)
 * Responsive, information-rich, warm, and calm.
 */
@Composable
fun DashboardScreen(
    familyName: String = "The Henderson Family",
    greeting: String = "Good morning, David",
    memberNames: List<String> = listOf("David", "Sarah", "Lucas", "Maya"),
    onQuickAction: (String) -> Unit = {}
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(FamilyOSSpacing.md)
    ) {
        // 1 & 2. Welcome Greeting & Active Family Identity Hero Card
        FamilyOSCard(
            backgroundColor = FamilyOSColors.WarmIvoryLight,
            modifier = Modifier.padding(bottom = FamilyOSSpacing.md)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = greeting,
                        style = MaterialTheme.typography.headlineLarge,
                        color = FamilyOSColors.TextPrimary
                    )
                    Spacer(modifier = Modifier.height(FamilyOSSpacing.xxs))
                    Text(
                        text = familyName,
                        style = MaterialTheme.typography.titleMedium,
                        color = FamilyOSColors.SecondarySage
                    )
                }

                FamilyOSStatusBadge(text = "Primary Home", color = FamilyOSColors.SecondarySage)
            }

            Spacer(modifier = Modifier.height(FamilyOSSpacing.md))
            Divider(color = FamilyOSColors.BorderSubtle)
            Spacer(modifier = Modifier.height(FamilyOSSpacing.sm))

            // 3. Family Member Avatars
            Text(
                text = "FAMILY MEMBERS",
                style = MaterialTheme.typography.labelSmall,
                color = FamilyOSColors.TextSecondary,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(FamilyOSSpacing.xs))
            Row(
                horizontalArrangement = Arrangement.spacedBy(FamilyOSSpacing.sm),
                verticalAlignment = Alignment.CenterVertically
            ) {
                memberNames.forEach { name ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        FamilyOSAvatar(name = name, size = 44.dp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = name,
                            style = MaterialTheme.typography.labelSmall,
                            color = FamilyOSColors.TextPrimary
                        )
                    }
                }
                // Add Member Action
                IconButton(
                    onClick = { onQuickAction("ADD_MEMBER") },
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(FamilyOSColors.SageLight)
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add Member",
                        tint = FamilyOSColors.PrimaryForestGreen
                    )
                }
            }
        }

        // 5. Quick Actions Row
        FamilyOSSectionHeader(title = "Quick Actions")
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = FamilyOSSpacing.md),
            horizontalArrangement = Arrangement.spacedBy(FamilyOSSpacing.sm)
        ) {
            QuickActionButton("Plan Meal", Icons.Default.Restaurant, Modifier.weight(1f)) {
                onQuickAction("PLAN_MEAL")
            }
            QuickActionButton("Assign Chore", Icons.Default.Checklist, Modifier.weight(1f)) {
                onQuickAction("ASSIGN_CHORE")
            }
            QuickActionButton("Log Expense", Icons.Default.ReceiptLong, Modifier.weight(1f)) {
                onQuickAction("LOG_EXPENSE")
            }
        }

        // 4 & 6. Today's Overview & Upcoming Events
        FamilyOSSectionHeader(title = "Today's Household Schedule", subtitle = "Thursday, October 30")
        FamilyOSCard(modifier = Modifier.padding(bottom = FamilyOSSpacing.md)) {
            ScheduleRow(
                time = "07:30 AM",
                title = "School Drop-off Routine",
                subtitle = "Lucas & Maya • Assigned to Sarah",
                category = "ROUTINE"
            )
            Divider(color = FamilyOSColors.BorderSubtle, modifier = Modifier.padding(vertical = FamilyOSSpacing.xs))
            ScheduleRow(
                time = "06:30 PM",
                title = "Family Dinner: Tuscan Pasta",
                subtitle = "Home cooked • 4 servings planned",
                category = "MEAL"
            )
            Divider(color = FamilyOSColors.BorderSubtle, modifier = Modifier.padding(vertical = FamilyOSSpacing.xs))
            ScheduleRow(
                time = "08:00 PM",
                title = "Weekly Family Check-in & Reading",
                subtitle = "Living room • 20 mins",
                category = "TRADITION"
            )
        }

        // 7. Pending Tasks & Chores
        FamilyOSSectionHeader(
            title = "Household Responsibilities",
            subtitle = "Active for today",
            actionText = "View All",
            onActionClick = { onQuickAction("VIEW_TASKS") }
        )
        FamilyOSCard(modifier = Modifier.padding(bottom = FamilyOSSpacing.md)) {
            TaskRow(title = "Dishwasher unloading & reset", assignee = "Lucas", points = 10, isDone = true)
            Divider(color = FamilyOSColors.BorderSubtle, modifier = Modifier.padding(vertical = FamilyOSSpacing.xs))
            TaskRow(title = "Pantry inventory check", assignee = "David", points = 15, isDone = false)
            Divider(color = FamilyOSColors.BorderSubtle, modifier = Modifier.padding(vertical = FamilyOSSpacing.xs))
            TaskRow(title = "Walk Bailey (Dog)", assignee = "Maya", points = 10, isDone = false)
        }

        // 9 & 10. Financial & Goals Placeholders (Clearly labeled Development Foundations)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = FamilyOSSpacing.md),
            horizontalArrangement = Arrangement.spacedBy(FamilyOSSpacing.md)
        ) {
            FamilyOSCard(modifier = Modifier.weight(1f)) {
                Text(
                    text = "FINANCIAL ALLOCATOR",
                    style = MaterialTheme.typography.labelSmall,
                    color = FamilyOSColors.SecondarySage,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(FamilyOSSpacing.xs))
                Text(
                    text = "Cash-Flow Engine",
                    style = MaterialTheme.typography.titleLarge
                )
                Spacer(modifier = Modifier.height(FamilyOSSpacing.xxs))
                Text(
                    text = "Exact integer cents foundation configured. Accounts & budget linking activates in Stage 3.",
                    style = MaterialTheme.typography.bodySmall,
                    color = FamilyOSColors.TextSecondary
                )
            }

            FamilyOSCard(modifier = Modifier.weight(1f)) {
                Text(
                    text = "GOALS & PROJECTS",
                    style = MaterialTheme.typography.labelSmall,
                    color = FamilyOSColors.SecondarySage,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(FamilyOSSpacing.xs))
                Text(
                    text = "4-Tier Hierarchy",
                    style = MaterialTheme.typography.titleLarge
                )
                Spacer(modifier = Modifier.height(FamilyOSSpacing.xxs))
                Text(
                    text = "Goal -> Project -> Task -> Checklist hierarchy prepared for Stage 2.",
                    style = MaterialTheme.typography.bodySmall,
                    color = FamilyOSColors.TextSecondary
                )
            }
        }

        // 11. Recent Family Activity Log
        FamilyOSSectionHeader(title = "Recent Household Activity")
        FamilyOSCard {
            ActivityRow("Sarah completed Tuscany Pasta Recipe rating (5 stars)", "2 hours ago")
            Divider(color = FamilyOSColors.BorderSubtle, modifier = Modifier.padding(vertical = FamilyOSSpacing.xs))
            ActivityRow("Lucas earned 10 reward points for morning chores", "4 hours ago")
            Divider(color = FamilyOSColors.BorderSubtle, modifier = Modifier.padding(vertical = FamilyOSSpacing.xs))
            ActivityRow("David updated Family Emergency Contact Directory", "Yesterday")
        }
    }
}

@Composable
private fun QuickActionButton(
    label: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = FamilyOSShapes.medium,
        color = FamilyOSColors.SurfaceCard,
        border = androidx.compose.foundation.BorderStroke(1.dp, FamilyOSColors.BorderSubtle),
        modifier = modifier.defaultMinSize(minHeight = FamilyOSSpacing.minTouchTarget)
    ) {
        Column(
            modifier = Modifier.padding(FamilyOSSpacing.sm),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = FamilyOSColors.PrimaryForestGreen,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.height(FamilyOSSpacing.xxs))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = FamilyOSColors.TextPrimary,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
private fun ScheduleRow(
    time: String,
    title: String,
    subtitle: String,
    category: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = time,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = FamilyOSColors.PrimaryForestGreen,
            modifier = Modifier.width(72.dp)
        )
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = FamilyOSColors.TextSecondary)
        }
        FamilyOSStatusBadge(text = category, color = FamilyOSColors.SageGreen)
    }
}

@Composable
private fun TaskRow(
    title: String,
    assignee: String,
    points: Int,
    isDone: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = if (isDone) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
            contentDescription = null,
            tint = if (isDone) FamilyOSColors.Success else FamilyOSColors.BorderStrong,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(FamilyOSSpacing.sm))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = "Assigned to $assignee",
                style = MaterialTheme.typography.bodySmall,
                color = FamilyOSColors.TextSecondary
            )
        }
        FamilyOSStatusBadge(text = "+$points pts", color = FamilyOSColors.SoftGold)
    }
}

@Composable
private fun ActivityRow(description: String, timestamp: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = description,
            style = MaterialTheme.typography.bodySmall,
            color = FamilyOSColors.TextPrimary,
            modifier = Modifier.weight(1f)
        )
        Text(
            text = timestamp,
            style = MaterialTheme.typography.labelSmall,
            color = FamilyOSColors.TextTertiary
        )
    }
}
