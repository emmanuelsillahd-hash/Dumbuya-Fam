package com.familyos.feature.goals

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.familyos.core.designsystem.*
import com.familyos.core.domain.*

/**
 * Stage 2: Goals, Projects & Tasks Hierarchy Screen
 * Supports 4-tier hierarchy: Goal -> Project -> Task -> Subtask -> Checklists
 */
@Composable
fun GoalsScreen(
    goals: List<FamilyGoal> = sampleGoals,
    projects: List<Project> = sampleProjects,
    tasks: List<Task> = sampleTasks,
    onAddGoal: () -> Unit = {},
    onAddTask: () -> Unit = {},
    onToggleTaskComplete: (String, Boolean) -> Unit = { _, _ -> }
) {
    var selectedFilter by remember { mutableStateOf("ALL") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(FamilyOSSpacing.md)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Goals & Productivity",
                    style = MaterialTheme.typography.headlineLarge,
                    color = FamilyOSColors.TextPrimary
                )
                Text(
                    text = "4-Tier Connected Hierarchy: Goal → Project → Task → Checklist",
                    style = MaterialTheme.typography.bodySmall,
                    color = FamilyOSColors.TextSecondary
                )
            }

            FamilyOSPrimaryButton(
                text = "New Goal",
                icon = Icons.Default.Add,
                onClick = onAddGoal
            )
        }

        Spacer(modifier = Modifier.height(FamilyOSSpacing.md))

        // Filter Chips Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(FamilyOSSpacing.xs)
        ) {
            listOf("ALL", "ACTIVE", "PROJECTS", "TASKS").forEach { filter ->
                val isSelected = selectedFilter == filter
                FilterChip(
                    selected = isSelected,
                    onClick = { selectedFilter = filter },
                    label = { Text(filter) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = FamilyOSColors.SageLight,
                        selectedLabelColor = FamilyOSColors.PrimaryForestGreen
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(FamilyOSSpacing.md))

        // Goals & Connected Projects List
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(FamilyOSSpacing.md)
        ) {
            items(goals) { goal ->
                val linkedProjects = projects.filter { it.goalId == goal.id }
                
                FamilyOSCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                FamilyOSStatusBadge(text = goal.category.name, color = FamilyOSColors.SecondarySage)
                                Spacer(modifier = Modifier.width(FamilyOSSpacing.xs))
                                FamilyOSStatusBadge(text = goal.priority.name, color = FamilyOSColors.SoftGold)
                            }
                            Spacer(modifier = Modifier.height(FamilyOSSpacing.xs))
                            Text(
                                text = goal.title,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                            if (goal.description != null) {
                                Text(
                                    text = goal.description,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = FamilyOSColors.TextSecondary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(FamilyOSSpacing.sm))
                    FamilyOSProgressIndicator(progress = 0.65f)
                    Spacer(modifier = Modifier.height(FamilyOSSpacing.sm))

                    // Linked Projects
                    if (linkedProjects.isNotEmpty()) {
                        Text(
                            text = "PROJECTS & TASKS IN THIS GOAL",
                            style = MaterialTheme.typography.labelSmall,
                            color = FamilyOSColors.SecondarySage,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(FamilyOSSpacing.xs))
                        linkedProjects.forEach { project ->
                            val projectTasks = tasks.filter { it.projectId == project.id }
                            Surface(
                                shape = FamilyOSShapes.small,
                                color = FamilyOSColors.WarmIvoryLight,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                            ) {
                                Column(modifier = Modifier.padding(FamilyOSSpacing.sm)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "📁 ${project.name}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "${projectTasks.count { it.isCompleted }}/${projectTasks.size} tasks done",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = FamilyOSColors.TextSecondary
                                        )
                                    }

                                    // Itemized Tasks
                                    projectTasks.forEach { task ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(top = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            IconButton(
                                                onClick = { onToggleTaskComplete(task.id, !task.isCompleted) },
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(
                                                    imageVector = if (task.isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                                    contentDescription = null,
                                                    tint = if (task.isCompleted) FamilyOSColors.Success else FamilyOSColors.BorderStrong,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(FamilyOSSpacing.xs))
                                            Text(
                                                text = task.title,
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = if (task.isCompleted) FamilyOSColors.TextTertiary else FamilyOSColors.TextPrimary
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private val sampleGoals = listOf(
    FamilyGoal(
        id = "g1",
        familyId = "fam1",
        title = "Establish Home Solar & Energy Storage",
        description = "Reduce household carbon footprint and lower monthly utility costs",
        category = GoalCategory.HOUSEHOLD,
        targetDate = System.currentTimeMillis() + 90L * 86_400_000L,
        priority = Priority.HIGH,
        ownerMemberId = "m1",
        status = "ACTIVE"
    ),
    FamilyGoal(
        id = "g2",
        familyId = "fam1",
        title = "Summer Family Heritage & Nature Expedition",
        description = "Annual camping, hiking, and multi-generational family retreat",
        category = GoalCategory.LIFESTYLE,
        targetDate = System.currentTimeMillis() + 120L * 86_400_000L,
        priority = Priority.MEDIUM,
        ownerMemberId = "m2",
        status = "ACTIVE"
    )
)

private val sampleProjects = listOf(
    Project(
        id = "p1",
        familyId = "fam1",
        goalId = "g1",
        name = "Solar Panel Contractor Bids & Selection",
        description = "Gather 3 licensed installer quotes and inspect roof structural integrity",
        budgetCents = 1500000L, // $15,000.00
        targetDate = System.currentTimeMillis() + 30L * 86_400_000L,
        status = "ACTIVE",
        leadMemberId = "m1"
    )
)

private val sampleTasks = listOf(
    Task(
        id = "t1",
        familyId = "fam1",
        projectId = "p1",
        parentTaskId = null,
        title = "Review electric utility bills for 12-month peak kilowatt usage",
        notes = "David pulling statements",
        assignedMemberId = "m1",
        priority = Priority.HIGH,
        dueDate = System.currentTimeMillis() + 5L * 86_400_000L,
        isCompleted = true,
        completedAt = System.currentTimeMillis(),
        completedByMemberId = "m1",
        recurrenceRule = null
    ),
    Task(
        id = "t2",
        familyId = "fam1",
        projectId = "p1",
        parentTaskId = null,
        title = "Schedule on-site attic and roof insulation audit",
        notes = "Installer visiting Thursday morning",
        assignedMemberId = "m2",
        priority = Priority.HIGH,
        dueDate = System.currentTimeMillis() + 10L * 86_400_000L,
        isCompleted = false,
        completedAt = null,
        completedByMemberId = null,
        recurrenceRule = null
    )
)
