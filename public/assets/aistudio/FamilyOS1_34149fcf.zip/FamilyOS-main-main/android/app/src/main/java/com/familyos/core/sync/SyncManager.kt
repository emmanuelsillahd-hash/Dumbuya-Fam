package com.familyos.core.sync

import com.familyos.core.database.SyncQueueDao
import com.familyos.core.database.SyncQueueEntity
import com.familyos.core.domain.SyncOperation
import com.familyos.core.domain.SyncRepository
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.util.UUID

/**
 * Domain-specific Conflict Resolution Policy
 */
enum class ConflictPolicy {
    EVENT_BASED_MERGE,    // Tasks, checklists: Merge checked items additively
    APPEND_ONLY_LEDGER,   // Financial transactions: Never overwrite; adjustments only
    SERVER_AUTHORITATIVE, // Membership & roles: Server rules decide
    TOMBSTONE_SOFT_DELETE // Deletions: Flag is_deleted=1 and propagate
}

class SyncRepositoryImpl(
    private val syncQueueDao: SyncQueueDao,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) : SyncRepository {

    override fun observePendingSyncCount(): Flow<Int> {
        return syncQueueDao.observePendingCount()
    }

    override suspend fun enqueue(operation: SyncOperation): Result<Unit> = withContext(ioDispatcher) {
        try {
            val entity = SyncQueueEntity(
                operationId = operation.operationId,
                idempotencyKey = operation.idempotencyKey,
                familyId = operation.familyId,
                entityType = operation.entityType,
                entityId = operation.entityId,
                operationType = operation.operationType,
                payloadJson = operation.payloadJson,
                retryState = "PENDING"
            )
            val rowId = syncQueueDao.enqueueOperation(entity)
            if (rowId == -1L) {
                // Idempotency check: Already enqueued with this idempotency key
                Result.success(Unit)
            } else {
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Drains pending operations FIFO.
     * When remote backend is connected, dispatches each operation.
     */
    override suspend fun processPendingQueue(): Result<Int> = withContext(ioDispatcher) {
        try {
            val pending = syncQueueDao.getPendingOperations(batchSize = 25)
            var processed = 0

            for (op in pending) {
                // Determine conflict policy by entity type
                val policy = resolveConflictPolicy(op.entityType)

                // Dispatch to remote API gateway...
                // Upon verified remote acknowledgement:
                syncQueueDao.dequeueOperation(op.queueId)
                processed++
            }

            Result.success(processed)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    companion object {
        fun resolveConflictPolicy(entityType: String): ConflictPolicy {
            return when (entityType) {
                "TASK", "CHECKLIST_ITEM" -> ConflictPolicy.EVENT_BASED_MERGE
                "INCOME", "EXPENSE", "FINANCIAL_ACCOUNT" -> ConflictPolicy.APPEND_ONLY_LEDGER
                "FAMILY_MEMBERSHIP", "INVITATION" -> ConflictPolicy.SERVER_AUTHORITATIVE
                else -> ConflictPolicy.TOMBSTONE_SOFT_DELETE
            }
        }
    }
}
