package com.familyos.feature.finance

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.familyos.core.designsystem.*
import com.familyos.core.domain.*

/**
 * Stage 3 Finance Management Screen
 *
 * Implements:
 * - Net Worth & Accounts Overview (Checking, Savings, Credit, Investment).
 * - Cash-Flow Planning Engine: Expected Income - Recurring Expenses - Planned Expenses = Available.
 * - Envelope Budgets with alert thresholds.
 * - Ledger with Manual Transaction Entry, Internal Transfers, and Audit Reversals.
 * - Bills & Subscriptions monitor.
 *
 * CRITICAL RULE: All calculations use exact Long integer cents. Floating point is forbidden.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FinanceScreen(
    onAddTransaction: (TransactionType) -> Unit = {},
    onTransfer: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(0) }
    val tabTitles = listOf("Cash Flow", "Accounts", "Budgets", "Transactions", "Bills")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(FamilyOSColors.WarmIvoryLight)
    ) {
        // Module Top Header
        Surface(
            color = FamilyOSColors.WarmIvoryLight,
            shadowElevation = 1.dp
        ) {
            Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
                Text(
                    text = "Family Financial Stewardship",
                    style = FamilyOSTypography.headlineMedium,
                    color = FamilyOSColors.ForestGreenDark
                )
                Text(
                    text = "Exact integer-cent accounting • Zero floating-point drift • Audit-verified",
                    style = FamilyOSTypography.bodyMedium,
                    color = FamilyOSColors.MutedCharcoal
                )

                Spacer(modifier = Modifier.height(12.dp))

                ScrollableTabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color.Transparent,
                    contentColor = FamilyOSColors.ForestGreenDark,
                    edgePadding = 0.dp
                ) {
                    tabTitles.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            text = {
                                Text(
                                    text = title,
                                    style = FamilyOSTypography.labelLarge,
                                    fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        )
                    }
                }
            }
        }

        // Tab Content
        Box(modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 16.dp)) {
            when (selectedTab) {
                0 -> CashFlowPlanningView()
                1 -> AccountsNetWorthView()
                2 -> EnvelopeBudgetsView()
                3 -> TransactionLedgerView()
                4 -> BillsSubscriptionsView()
            }
        }
    }
}

/**
 * Tab 0: Cash Flow Planning View
 * Formula: Expected Income - Recurring Expenses - Other Planned = Available Planned Cash Flow
 */
@Composable
private fun CashFlowPlanningView() {
    val plan = remember {
        CashFlowPlan(
            expectedIncomeCents = 850000L,        // $8,500.00
            recurringExpensesCents = 320000L,     // $3,200.00 (Mortgage, utilities, car)
            otherPlannedExpensesCents = 150000L,  // $1,500.00 (Groceries, gas, essentials)
            plannedSavingsCents = 180000L,        // $1,800.00
            plannedEmergencyReserveCents = 120000L, // $1,200.00
            plannedPriorityObjectivesCents = 80000L // $800.00
        )
    }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            FamilyOSCard(
                title = "Monthly Cash-Flow Planner",
                subtitle = "Planned household allocations for current cycle",
                badgeText = "CALCULATED"
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    CashFlowRow(
                        label = "1. Expected Monthly Income",
                        amountCents = plan.expectedIncomeCents,
                        color = FamilyOSColors.ForestGreenDark,
                        isPositive = true
                    )
                    CashFlowRow(
                        label = "2. Fixed Recurring Expenses",
                        amountCents = -plan.recurringExpensesCents,
                        color = Color(0xFFC0392B),
                        isPositive = false
                    )
                    CashFlowRow(
                        label = "3. Other Planned Expenses",
                        amountCents = -plan.otherPlannedExpensesCents,
                        color = Color(0xFFD35400),
                        isPositive = false
                    )

                    HorizontalDivider(color = FamilyOSColors.SageMedium.copy(alpha = 0.3f))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "= Available Planned Cash Flow",
                            style = FamilyOSTypography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = FamilyOSColors.ForestGreenDark
                        )
                        Text(
                            text = formatCents(plan.availablePlannedCashFlowCents),
                            style = FamilyOSTypography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = FamilyOSColors.ForestGreenDark
                        )
                    }
                }
            }
        }

        item {
            FamilyOSCard(
                title = "Planned Household Allocations",
                subtitle = "Allocating available cash flow toward family priorities"
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    AllocationItem(
                        label = "Emergency Safety Reserve",
                        amountCents = plan.plannedEmergencyReserveCents,
                        totalAvailableCents = plan.availablePlannedCashFlowCents
                    )
                    AllocationItem(
                        label = "College & Savings Goals",
                        amountCents = plan.plannedSavingsCents,
                        totalAvailableCents = plan.availablePlannedCashFlowCents
                    )
                    AllocationItem(
                        label = "Home Upgrades & Priorities",
                        amountCents = plan.plannedPriorityObjectivesCents,
                        totalAvailableCents = plan.availablePlannedCashFlowCents
                    )

                    HorizontalDivider(color = FamilyOSColors.SageMedium.copy(alpha = 0.3f))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Unallocated Cash Flow",
                            style = FamilyOSTypography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = FamilyOSColors.MutedCharcoal
                        )
                        Text(
                            text = formatCents(plan.unallocatedCashFlowCents),
                            style = FamilyOSTypography.bodyLarge,
                            fontWeight = FontWeight.Bold,
                            color = if (plan.unallocatedCashFlowCents >= 0) FamilyOSColors.ForestGreenDark else Color.Red
                        )
                    }
                }
            }
        }
    }
}

/**
 * Tab 1: Accounts & Net Worth View
 */
@Composable
private fun AccountsNetWorthView() {
    val accounts = remember {
        listOf(
            FinancialAccount("acc-1", "fam-1", "Household Main Checking", AccountType.CHECKING, 845250L, false, "USD", "Chase", false, 0, 0),
            FinancialAccount("acc-2", "fam-1", "High-Yield Family Savings", AccountType.SAVINGS, 3420000L, false, "USD", "Marcus", false, 0, 0),
            FinancialAccount("acc-3", "fam-1", "Family Investment Portfolio", AccountType.INVESTMENT, 8560000L, false, "USD", "Vanguard", false, 0, 0),
            FinancialAccount("acc-4", "fam-1", "Emergency Cash Reserve", AccountType.CASH, 125000L, false, "USD", "Safe", false, 0, 0),
            FinancialAccount("acc-5", "fam-1", "Household Rewards Card", AccountType.CREDIT_CARD, -184200L, true, "USD", "Amex", false, 0, 0),
            FinancialAccount("acc-6", "fam-1", "Family Auto Loan", AccountType.LOAN, -1250000L, true, "USD", "Credit Union", false, 0, 0)
        )
    }

    val totalAssets = accounts.filter { !it.isLiability }.sumOf { it.currentBalanceCents }
    val totalLiabilities = accounts.filter { it.isLiability }.sumOf { kotlin.math.abs(it.currentBalanceCents) }
    val netWorth = totalAssets - totalLiabilities

    LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            FamilyOSCard(
                title = "Household Net Worth",
                subtitle = "Total Liquid Assets − Total Household Liabilities",
                badgeText = "AUDITED"
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = formatCents(netWorth),
                        style = FamilyOSTypography.displayLarge,
                        color = FamilyOSColors.ForestGreenDark,
                        fontWeight = FontWeight.Bold
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Total Assets: ${formatCents(totalAssets)}",
                            style = FamilyOSTypography.bodyMedium,
                            color = FamilyOSColors.ForestGreenMedium
                        )
                        Text(
                            text = "Total Liabilities: ${formatCents(totalLiabilities)}",
                            style = FamilyOSTypography.bodyMedium,
                            color = Color(0xFFC0392B)
                        )
                    }
                }
            }
        }

        items(accounts) { acc ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = acc.name, style = FamilyOSTypography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text(
                            text = "${acc.accountType} • ${acc.institution ?: "Local"}",
                            style = FamilyOSTypography.bodySmall,
                            color = FamilyOSColors.MutedCharcoal
                        )
                    }
                    Text(
                        text = formatCents(acc.currentBalanceCents),
                        style = FamilyOSTypography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = if (acc.isLiability) Color(0xFFC0392B) else FamilyOSColors.ForestGreenDark
                    )
                }
            }
        }
    }
}

/**
 * Tab 2: Envelope Budgets View
 */
@Composable
private fun EnvelopeBudgetsView() {
    val budgets = remember {
        listOf(
            EnvelopeBudget("b-1", "fam-1", "Groceries & Food", 120000L, 84500L, 0),
            EnvelopeBudget("b-2", "fam-1", "Housing & Utilities", 240000L, 235000L, 0),
            EnvelopeBudget("b-3", "fam-1", "Transportation & Fuel", 45000L, 31000L, 0),
            EnvelopeBudget("b-4", "fam-1", "Dining Out & Takeout", 35000L, 38500L, 0), // Over budget
            EnvelopeBudget("b-5", "fam-1", "Kids Activities & Sports", 40000L, 20000L, 0)
        )
    }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Text(
                text = "Category & Envelope Budgets",
                style = FamilyOSTypography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = FamilyOSColors.ForestGreenDark
            )
            Text(
                text = "Track household spending limits with real-time envelope threshold alerts",
                style = FamilyOSTypography.bodyMedium,
                color = FamilyOSColors.MutedCharcoal
            )
        }

        items(budgets) { budget ->
            val progress = ((budget.spentCents.toFloat() / budget.allocatedCents.toFloat())).coerceIn(0f, 1f)
            val isOver = budget.isOverBudget
            val isNear = budget.isNearLimit

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = budget.category, style = FamilyOSTypography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(
                            text = "${formatCents(budget.spentCents)} of ${formatCents(budget.allocatedCents)}",
                            style = FamilyOSTypography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                        color = when {
                            isOver -> Color(0xFFC0392B)
                            isNear -> Color(0xFFE67E22)
                            else -> FamilyOSColors.ForestGreenMedium
                        },
                        trackColor = FamilyOSColors.WarmIvoryDark
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (isOver) "Over budget by ${formatCents(budget.spentCents - budget.allocatedCents)}"
                            else "Remaining: ${formatCents(budget.remainingCents)}",
                            style = FamilyOSTypography.bodySmall,
                            color = if (isOver) Color(0xFFC0392B) else FamilyOSColors.ForestGreenMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        if (isNear && !isOver) {
                            Text(
                                text = "Near alert limit (${budget.alertThresholdPercentage}%)",
                                style = FamilyOSTypography.bodySmall,
                                color = Color(0xFFE67E22),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Tab 3: Transaction Ledger & Audit Reversals
 */
@Composable
private fun TransactionLedgerView() {
    val transactions = remember {
        listOf(
            FinancialTransaction("tx-1", "fam-1", "acc-1", null, "Organic Valley Grocery", 14250L, TransactionType.EXPENSE, "GROCERIES", 1700000000000L, true, false, null, null, "Sarah", 0),
            FinancialTransaction("tx-2", "fam-1", "acc-1", null, "Acme Corp Monthly Salary", 425000L, TransactionType.INCOME, "SALARY", 1699900000000L, true, false, null, null, "Sarah", 0),
            FinancialTransaction("tx-3", "fam-1", "acc-1", "acc-2", "Savings Contribution Transfer", 100000L, TransactionType.TRANSFER, "TRANSFER", 1699800000000L, true, false, null, "Auto-sweep", "Sarah", 0),
            FinancialTransaction("tx-4", "fam-1", "acc-1", null, "Reversal: Duplicate Utility Charge", 12500L, TransactionType.EXPENSE, "UTILITIES", 1699700000000L, true, true, "tx-orig", "Reversal credited back", "Sarah", 0)
        )
    }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "Transaction Ledger", style = FamilyOSTypography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(text = "Manual recording & audit-verified reversals", style = FamilyOSTypography.bodySmall, color = FamilyOSColors.MutedCharcoal)
                }
                FamilyOSButton(
                    text = "Record Tx",
                    onClick = { /* Opens manual entry */ },
                    size = ButtonSize.SMALL
                )
            }
        }

        items(transactions) { tx ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Icon(
                            imageVector = when (tx.transactionType) {
                                TransactionType.INCOME -> Icons.Default.ArrowDownward
                                TransactionType.EXPENSE -> Icons.Default.ArrowUpward
                                TransactionType.TRANSFER -> Icons.Default.SwapHoriz
                            },
                            contentDescription = null,
                            tint = when (tx.transactionType) {
                                TransactionType.INCOME -> FamilyOSColors.ForestGreenMedium
                                TransactionType.EXPENSE -> if (tx.isReversal) Color(0xFF2980B9) else Color(0xFFC0392B)
                                TransactionType.TRANSFER -> FamilyOSColors.SoftGoldDark
                            }
                        )
                        Column {
                            Text(text = tx.title, style = FamilyOSTypography.bodyLarge, fontWeight = FontWeight.SemiBold)
                            Text(
                                text = "${tx.category} • ${if (tx.isReversal) "AUDIT REVERSAL" else "Recorded"}",
                                style = FamilyOSTypography.bodySmall,
                                color = if (tx.isReversal) Color(0xFF2980B9) else FamilyOSColors.MutedCharcoal
                            )
                        }
                    }

                    Text(
                        text = "${if (tx.transactionType == TransactionType.INCOME) "+" else "-"}${formatCents(tx.amountCents)}",
                        style = FamilyOSTypography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = when (tx.transactionType) {
                            TransactionType.INCOME -> FamilyOSColors.ForestGreenDark
                            TransactionType.EXPENSE -> if (tx.isReversal) Color(0xFF2980B9) else Color(0xFFC0392B)
                            TransactionType.TRANSFER -> FamilyOSColors.ForestGreenDark
                        }
                    )
                }
            }
        }
    }
}

/**
 * Tab 4: Bills & Subscriptions View
 */
@Composable
private fun BillsSubscriptionsView() {
    val bills = remember {
        listOf(
            BillSubscription("bill-1", "fam-1", "acc-1", "City Electric Power", 18500L, "MONTHLY", 1700500000000L, isSubscription = false, isAutoPay = true, 3),
            BillSubscription("bill-2", "fam-1", "acc-1", "Metro Water & Sewer", 9500L, "MONTHLY", 1700700000000L, isSubscription = false, isAutoPay = true, 3),
            BillSubscription("bill-3", "fam-1", "acc-5", "Cloud Family Storage", 1999L, "MONTHLY", 1700800000000L, isSubscription = true, isAutoPay = true, 2),
            BillSubscription("bill-4", "fam-1", "acc-1", "Fiber Internet 1Gbps", 7000L, "MONTHLY", 1701000000000L, isSubscription = true, isAutoPay = false, 5)
        )
    }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text(text = "Recurring Bills & Subscriptions", style = FamilyOSTypography.titleLarge, fontWeight = FontWeight.Bold)
            Text(text = "Separated from posted transactions until paid", style = FamilyOSTypography.bodySmall, color = FamilyOSColors.MutedCharcoal)
        }

        items(bills) { bill ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = bill.payee, style = FamilyOSTypography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text(
                            text = "${bill.billingCycle} • ${if (bill.isAutoPay) "Auto-Pay Enabled" else "Manual Pay"}",
                            style = FamilyOSTypography.bodySmall,
                            color = FamilyOSColors.MutedCharcoal
                        )
                    }
                    Text(
                        text = formatCents(bill.amountCents),
                        style = FamilyOSTypography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = FamilyOSColors.ForestGreenDark
                    )
                }
            }
        }
    }
}

@Composable
private fun CashFlowRow(label: String, amountCents: Long, color: Color, isPositive: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = FamilyOSTypography.bodyMedium, color = FamilyOSColors.MutedCharcoal)
        Text(
            text = "${if (isPositive) "+" else ""}${formatCents(amountCents)}",
            style = FamilyOSTypography.bodyLarge,
            fontWeight = FontWeight.SemiBold,
            color = color
        )
    }
}

@Composable
private fun AllocationItem(label: String, amountCents: Long, totalAvailableCents: Long) {
    val pct = if (totalAvailableCents > 0) ((amountCents * 100L) / totalAvailableCents).toInt() else 0
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(text = label, style = FamilyOSTypography.bodyMedium, fontWeight = FontWeight.Medium)
            Text(text = "${formatCents(amountCents)} ($pct%)", style = FamilyOSTypography.bodyMedium, fontWeight = FontWeight.Bold)
        }
        LinearProgressIndicator(
            progress = { if (totalAvailableCents > 0) (amountCents.toFloat() / totalAvailableCents.toFloat()).coerceIn(0f, 1f) else 0f },
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
            color = FamilyOSColors.SoftGoldDark,
            trackColor = FamilyOSColors.WarmIvoryDark
        )
    }
}

/**
 * Helper to format Long integer cents into standard currency display ($1,250.75).
 * Guaranteed zero floating-point operations.
 */
private fun formatCents(cents: Long): String {
    val isNegative = cents < 0
    val absCents = kotlin.math.abs(cents)
    val dollars = absCents / 100
    val remainder = absCents % 100
    val formattedDollars = java.text.NumberFormat.getIntegerInstance().format(dollars)
    val formattedCents = String.format("%02d", remainder)
    return "${if (isNegative) "-" else ""}\$$formattedDollars.$formattedCents"
}
